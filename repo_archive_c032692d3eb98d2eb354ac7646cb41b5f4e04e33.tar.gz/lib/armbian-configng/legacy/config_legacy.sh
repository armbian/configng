


# @description Armbian config Legacy
#
# @exitcode 0  If successful.
#
# @options none. 
function legacy::armbian_config(){

	bash armbian-config
	return 0

}
