module_options+=(
	["module_nfsd,author"]="@igorpecovnik"
	["module_nfsd,feature"]="module_nfsd"
	["module_nfsd,desc"]="Install nfsd server"
	["module_nfsd,example"]="install remove manage add status help"
	["module_nfsd,port"]=""
	["module_nfsd,status"]="Active"
	["module_nfsd,arch"]=""
)
#
# Module nfsd
#
function module_nfsd () {
	local title="nfsd"
	local condition=$(which "$title" 2>/dev/null)?

	# we will store our config in subfolder
	mkdir -p /etc/exports.d/

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_nfsd,example"]}"

	NFSD_BASE="${SOFTWARE_FOLDER}/nfsd"

	case "$1" in
		"${commands[0]}")
			apt_install_wrapper apt-get -y install nfs-common nfs-kernel-server
			# add some exports
			${module_options["module_nfsd,feature"]} ${commands[2]}
			systemctl restart nfs-server.service
		;;
		"${commands[1]}")
			apt_install_wrapper apt-get -y autopurge nfs-kernel-server
		;;
		"${commands[2]}")
			while true; do
				LIST=() IFS=$'\n' LIST=($(grep "^[^#;]" /etc/exports.d/armbian.exports))
				LIST_LENGTH=${#LIST[@]}
				if [[ "${LIST_LENGTH}" -ge 1 ]]; then
					line=$(dialog --no-items \
					--title "Select export to edit" \
					--ok-label "Add" \
					--cancel-label "Apply" \
					--extra-button \
					--extra-label "Delete" \
					--menu "" \
					$((${LIST_LENGTH} + 6)) \
					80 \
					$((${LIST_LENGTH})) \
					${LIST[@]} 3>&1 1>&2 2>&3)
					exitstatus=$?
					case "$exitstatus" in
						0)
							${module_options["module_nfsd,feature"]} ${commands[3]}
						;;
						1)
							break
						;;
						3)
							sed -i '\?^'$line'?d' /etc/exports.d/armbian.exports
						;;
					esac
				else
					${module_options["module_nfsd,feature"]} ${commands[3]}
					break
				fi
			done
			systemctl restart nfs-server.service
		;;
		"${commands[3]}")
			# choose between most common options
			LIST=()
			LIST=("ro" "Allow read only requests" On)
			LIST+=("rw" "Allow read and write requests" OFF)
			LIST+=("sync" "Immediate sync all writes" On)
			LIST+=("fsid=0" "Check man pages" OFF)
			LIST+=("no_subtree_check" "Disables subtree checking, improves reliability" On)
			LIST_LENGTH=$((${#LIST[@]}/3))
			if add_folder=$(dialog --title \
							"Which folder do you want to export?" \
							--inputbox "" \
							6 80 "/armbian" 3>&1 1>&2 2>&3); then
				if add_ip=$(dialog --title \
							"Which IP or range can access this folder?" \
							--inputbox "\nExamples: 192.168.1.1, 192.168.1.0/24" \
							8 80 "${LOCALSUBNET}" 3>&1 1>&2 2>&3); then
					if add_options=$(dialog --separate-output \
							--nocancel \
							--title "NFS volume options" \
							--checklist "" \
							$((${LIST_LENGTH} + 6)) 80 ${LIST_LENGTH} "${LIST[@]}" 3>&1 1>&2 2>&3); then
							echo "$add_folder $add_ip($(echo $add_options | tr ' ' ','))" \
							>> /etc/exports.d/armbian.exports
					fi
				fi
			fi
		;;
		"${commands[4]}")
			if systemctl is-active --quiet nfs-server.service; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[5]}")
			echo -e "\nUsage: ${module_options["module_nfsd,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_nfsd,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tmanage\t- Edit exports in $title."
			echo -e "\tadd\t- Add exports to $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_nfsd,feature"]} ${commands[5]}
		;;
	esac
}

module_options+=(
	["connect_bt_interface,author"]="@armbian"
	["connect_bt_interface,ref_link"]=""
	["connect_bt_interface,feature"]="connect_bt_interface"
	["connect_bt_interface,desc"]="Migrated procedures from Armbian config."
	["connect_bt_interface,example"]="connect_bt_interface"
	["connect_bt_interface,status"]="Active"
)
#
# connect to bluetooth device
#
function connect_bt_interface() {

	IFS=$'
'
	GLOBIGNORE='*'
	show_infobox <<< "
Discovering Bluetooth devices ... "
	BT_INTERFACES=($(hcitool scan | sed '1d'))

	local LIST=()
	for i in "${BT_INTERFACES[@]}"; do
		local a=$(echo ${i[0]//[[:blank:]]/} | sed -e 's/^\(.\{17\}\).*/\1/')
		local b=${i[0]//$a/}
		local b=$(echo $b | sed -e 's/^[ 	]*//')
		LIST+=("$a" "$b")
	done

	LIST_LENGTH=$((${#LIST[@]} / 2))
	if [ "$LIST_LENGTH" -eq 0 ]; then
		BT_ADAPTER=${WLAN_INTERFACES[0]}
		show_message <<< "
No nearby Bluetooth devices were found!"
	else
		exec 3>&1
		BT_ADAPTER=$(whiptail --title "Select interface" \
			--clear --menu "" $((6 + ${LIST_LENGTH})) 50 $LIST_LENGTH "${LIST[@]}" 2>&1 1>&3)
		exec 3>&-
		if [[ $BT_ADAPTER != "" ]]; then
			show_infobox <<< "
Connecting to $BT_ADAPTER "
			BT_EXEC=$(
				expect -c 'set prompt "#";set address '$BT_ADAPTER';spawn bluetoothctl;expect -re $prompt;send "disconnect $address
";
			sleep 1;send "remove $address
";sleep 1;expect -re $prompt;send "scan on
";sleep 8;send "scan off
";
			expect "Controller";send "trust $address
";sleep 2;send "pair $address
";sleep 2;send "connect $address
";
			send_user "
Should be paired now.
";sleep 2;send "quit
";expect eof'
			)
			echo "$BT_EXEC" > /tmp/bt-connect-debug.log
			if [[ $(echo "$BT_EXEC" | grep "Connection successful") != "" ]]; then
				show_message <<< "
Your device is ready to use!"
			else
				show_message <<< "
Error connecting. Try again!"
			fi
		fi
	fi

}


module_options+=(
	["check_ip_version,author"]="@Tearran"
	["check_ip_version,ref_link"]=""
	["check_ip_version,feature"]="check_ip_version"
	["check_ip_version,desc"]="Check if a domain is reachable via IPv4 and IPv6"
	["check_ip_version,example"]="check_ip_version google.com"
	["check_ip_version,status"]="review"
	["check_ip_version,doc_link"]=""
)
#
#
#
check_ip_version() {
	domain=${1:-armbian.com}

	if ping -c 1 $domain > /dev/null 2>&1; then
		echo "IPv4"
	elif ping6 -c 1 $domain > /dev/null 2>&1; then
		echo "IPv6"
	else
		echo "Unreachable"
	fi
}


module_options+=(
	["default_network_config,author"]="@igorpecovnik"
	["default_network_config,ref_link"]=""
	["default_network_config,feature"]="default_network_config"
	["default_network_config,desc"]="Revert network config back to Armbian defaults"
	["default_network_config,example"]="default_network_config"
	["default_network_config,status"]="review"
)
#
# Function to revert network configuration to Armbian defaults
#
function default_network_config() {

	local yamlfile=10-dhcp-all-interfaces

	# store current configs to temporal folder
	store_netplan_config

	get_user_continue "This action might disconnect you from network.\n\nAre you sure network was configured correctly?" process_input
	if [[ $? == 0 ]]; then
		# remove all configs
		rm -f /etc/netplan/*.yaml
		# disable hostapd
		systemctl stop hostapd 2> /dev/null
		systemctl disable hostapd 2> /dev/null
		# reset netplan config
		netplan set --origin-hint ${yamlfile} renderer=${NETWORK_RENDERER}
		netplan set --origin-hint ${yamlfile} ethernets.all-eth-interfaces.dhcp4=true
		netplan set --origin-hint ${yamlfile} ethernets.all-eth-interfaces.dhcp6=true
		netplan set --origin-hint ${yamlfile} ethernets.all-eth-interfaces.match.name=e*

		# exceptions
		if [[ "${NETWORK_RENDERER}" == "NetworkManager" ]]; then
			# uninstall packages
			apt_install_wrapper apt-get -y purge hostapd
			netplan apply
			nmcli con down br0
		else
			# uninstall packages
			apt_install_wrapper apt-get -y purge hostapd networkd-dispatcher
			# drop and delete bridge interface in case its there
			if [[ -n $(ip link show type bridge) ]]; then
				ip link set br0 down >/dev/null 2>&1
				brctl delbr br0 >/dev/null 2>&1
				networkctl reconfigure br0 >/dev/null 2>&1
			fi
			# remove networkd-dispatcher hook
			rm -f /etc/networkd-dispatcher/carrier.d/armbian-ap
			netplan apply
		fi
	else
		restore_netplan_config
	fi
}


module_options+=(
	["see_ping,author"]="@Tearran"
	["see_ping,ref_link"]="https://github.com/Tearran/configng/blob/main/config.ng.functions.sh#632"
	["see_ping,feature"]="see_ping"
	["see_ping,desc"]="Check the internet connection with fallback DNS"
	["see_ping,example"]="see_ping"
	["see_ping,doc_link"]=""
	["see_ping,status"]="review"
)
#
# Function to check the internet connection
#
function see_ping() {
	# List of servers to ping
	servers=("1.1.1.1" "8.8.8.8")

	# Check for internet connection
	for server in "${servers[@]}"; do
		if ping -q -c 1 -W 1 $server > /dev/null; then
			echo "Internet connection: Present"
			break
		else
			echo "Internet connection: Failed"
			sleep 1
		fi
	done

	if [[ $? -ne 0 ]]; then
		read -n -r 1 -s -p "Warning: Configuration cannot work properly without a working internet connection. \
		Press CTRL C to stop or any key to ignore and continue."
	fi

}


module_options+=(
	["toggle_ipv6,author"]="@Tearran"
	["toggle_ipv6,ref_link"]=""
	["toggle_ipv6,feature"]="toggle_ipv6"
	["toggle_ipv6,desc"]="Toggle IPv6 on or off"
	["toggle_ipv6,example"]="toggle_ipv6"
	["toggle_ipv6,status"]="review"
	["toggle_ipv6,doc_link"]=""
)
#
# Function to toggle IPv6 on or off
#
toggle_ipv6() {
	# Check if IPv6 is currently enabled
	if sysctl net.ipv6.conf.all.disable_ipv6 | grep -q 0; then
		# If IPv6 is enabled, disable it
		echo "Disabling IPv6..."
		sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1
		sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1
		sudo sysctl -w net.ipv6.conf.lo.disable_ipv6=1
		echo "IPv6 is now disabled."
		# Confirm that IPv6 is disabled
		if sysctl net.ipv6.conf.all.disable_ipv6 | grep -q 1; then
			check_ip_version google.com
		else
			check_ip_version google.com
		fi
	else
		# If IPv6 is disabled, enable it
		echo "Enabling IPv6..."
		sudo sysctl -w net.ipv6.conf.all.disable_ipv6=0
		sudo sysctl -w net.ipv6.conf.default.disable_ipv6=0
		sudo sysctl -w net.ipv6.conf.lo.disable_ipv6=0
		echo "IPv6 is now enabled."
		# Confirm that IPv6 is enabled
		if sysctl net.ipv6.conf.all.disable_ipv6 | grep -q 0; then
			check_ip_version google.com
		else
			check_ip_version google.com
		fi
	fi

	# Now call the function with a domain name

}


module_options+=(
	["default_wireless_network_config,author"]="@igorpecovnik"
	["default_wireless_network_config,ref_link"]=""
	["default_wireless_network_config,feature"]="default_wireless_network_config"
	["default_wireless_network_config,desc"]="Stop hostapd, clean config"
	["default_wireless_network_config,example"]="default_wireless_network_config"
	["default_wireless_network_config,doc_link"]=""
	["default_wireless_network_config,status"]="review"
)
function default_wireless_network_config(){

	# defaul yaml file
	local yamlfile=${1:-armbian}
	local adapter=${2:-wlan0}

	# remove wifi from netplan
	if [[ -f /etc/netplan/${yamlfile}.yaml ]]; then
		sed -i -e 'H;x;/^\(  *\)\n\1/{s/\n.*//;x;d;}' -e 's/.*//;x;/'$adapter':/{s/^\( *\).*/ \1/;x;d;}' /etc/netplan/${yamlfile}.yaml
		sed -i -e 'H;x;/^\(  *\)\n\1/{s/\n.*//;x;d;}' -e 's/.*//;x;/- '$adapter'/{s/^\( *\).*/ \1/;x;d;}' /etc/netplan/${yamlfile}.yaml
		sed -i -e 'H;x;/^\(  *\)\n\1/{s/\n.*//;x;d;}' -e 's/.*//;x;/wifis:/{s/^\( *\).*/ \1/;x;d;}' /etc/netplan/${yamlfile}.yaml
	fi

	# remove networkd-dispatcher hook
	rm -f /etc/networkd-dispatcher/carrier.d/armbian-ap
	# remove network-manager dispatcher hook
	rm -f /etc/NetworkManager/dispatcher.d/armbian-ap

	# hostapd needs more cleaning
	if systemctl is-active hostapd 1> /dev/null; then
		systemctl stop hostapd 2> /dev/null
		systemctl disable hostapd 2> /dev/null
	fi

	# apply config
	netplan apply

	# exceptions
	if [[ "${NETWORK_RENDERER}" == "NetworkManager" ]]; then
			# uninstall packages
			apt_install_wrapper apt-get -y --no-install-recommends purge hostapd
			systemctl restart NetworkManager
		else
			# uninstall packages
			apt_install_wrapper apt-get -y --no-install-recommends purge hostapd networkd-dispatcher
			brctl delif br0 $adapter 2> /dev/null
			networkctl reconfigure br0
	fi

}


module_options+=(
	["network_config,author"]="@igorpecovnik"
	["network_config,ref_link"]=""
	["network_config,feature"]="network_config"
	["network_config,desc"]="Netplan wrapper"
	["network_config,example"]="network_config"
	["network_config,doc_link"]=""
	["network_config,status"]="review"
)
#
# Function to select network adapter
#
function network_config() {

	# defaul yaml file
	local yamlfile=${1:-armbian}

	# store current configs to temporal folder
	store_netplan_config

	LIST=()
	HIDE_IP_PATTERN="^dummy0|^lo|^docker|^virbr|^br"
	for f in /sys/class/net/*; do
		interface=$(basename $f)
		if [[ $interface =~ $HIDE_IP_PATTERN ]]; then
			continue
		else
			[[ $interface == w* ]] && devicetype="wifi" || devicetype="wired"
			QUERY=$(ip -br addr show dev $interface | awk '{ print $1, " " , ($3==""?"unassigned":$3)"['$devicetype']" }')
			[[ -n $QUERY ]] && LIST+=($QUERY)
		fi
	done
	LIST_LENGTH=$((${#LIST[@]} / 2))
	adapter=$($DIALOG --title "Select interface" --menu "" $((${LIST_LENGTH} + 8)) 60 $((${LIST_LENGTH})) "${LIST[@]}" 3>&1 1>&2 2>&3)
	if [[ -n $adapter && $? == 0 ]]; then
		#
		# Wireless networking
		#
		if [[ "$adapter" == w* ]]; then

			LIST=()
			if systemctl is-active --quiet service hostapd; then
				LIST+=("stop" "Disable access point")
			else
				LIST=("sta" "Connect to access point")
				LIST+=("ap" "Become an access point")
			fi
			LIST_LENGTH=$((${#LIST[@]} / 2))
			wifimode=$($DIALOG --title "Select wifi mode" --menu "" $((${LIST_LENGTH} + 8)) 60 $((${LIST_LENGTH})) "${LIST[@]}" 3>&1 1>&2 2>&3)
			case $wifimode in
			stop)
				# disable hostapd and cleanup config
				default_wireless_network_config "${yamlfile}" "${adapter}"
			;;

			sta)
			LIST=()
				ip link set ${adapter} up
				local stationslist=$(mktemp /tmp/wifi.XXXXXX)
				for wificycles in $(seq 1 1 10); do
				LIST=()
					iw ${adapter} scan 2> /dev/null | \
					grep 'freq:\|SSID:\|signal:' \
					| sed 's/.*:"//;s/"//' \
					| xargs -n3 -d'\n' \
					| sort -k4 -nr \
					| sed "s/freq: //g" \
					| sed "s/signal: //g" \
					| sed "s/SSID: //g" \
					> $stationslist
					if [[ $? -eq 0 && $(cat "${stationslist}" | wc -l) -gt 0 ]]; then
						break
					fi
					sleep 1
				done | $DIALOG --title "" --infobox "Scanning. Please wait" 4 26
				# construct second array
				while IFS=$'\t' read -r -a wifiArray
				do
					# if SSID is not blank, add to new list
					if [[ -n "${wifiArray[2]}" ]]; then
					LIST+=("${wifiArray[2]}" "$(printf "%-30s" "${wifiArray[2]}") ${wifiArray[1]} ${wifiArray[0]} Mhz")
					fi
				done < $stationslist
				rm -f $stationslist
				if [[ ${#LIST[@]} == 0 ]]; then
					restore_netplan_config
				else
					SELECTED_SSID=$($DIALOG --notags --backtitle "" --menu "Select WiFi Network" $((${#LIST[@]}/3 + 14 )) 70 $((${#LIST[@]}/3 + 6)) "${LIST[@]}" 3>&1 1>&2 2>&3)
					if [[ -n $SELECTED_SSID ]]; then
						SELECTED_PASSWORD=$($DIALOG --title "Enter new password for $SELECTED_SSID" --passwordbox "" 7 50 3>&1 1>&2 2>&3)
						if [[ -n $SELECTED_PASSWORD ]]; then
							# connect to AP
							netplan set --origin-hint ${yamlfile} renderer=${NETWORK_RENDERER}
							netplan set --origin-hint ${yamlfile} wifis.$adapter.access-points."${SELECTED_SSID//./\\.}".password=${SELECTED_PASSWORD}
							netplan set --origin-hint ${yamlfile} wifis.$adapter.dhcp4=true
							netplan set --origin-hint ${yamlfile} wifis.$adapter.dhcp6=true
							show_message <<< "$(netplan get all)"
							$DIALOG --title " Changing network settings " --yes-button "Yes" --no-button "Cancel" --yesno \
							"This action might disconnect you from network.\n\nAre you sure network was configured correctly?" 9 50
							if [[ $? = 0 ]]; then
								netplan apply
							else
								restore_netplan_config
							fi
						fi
					fi
				fi
			;;

			ap)
				if [[ -f /etc/netplan/armbian.yaml && "$(netplan get bridges)" != "null" ]]; then
				ip link set ${adapter} up
				default_wireless_network_config "${yamlfile}" "${adapter}"
				apt_install_wrapper apt-get -y --no-install-recommends install hostapd networkd-dispatcher bridge-utils
				SELECTED_SSID=$($DIALOG --title "Enter SSID for AP" --inputbox "\nHit enter for defaults" 9 50 "armbian" 3>&1 1>&2 2>&3)
				if [[ -n "${SELECTED_SSID}" && $? == 0 ]]; then
					SELECTED_PASSWORD=$($DIALOG --title "Enter new password for $SELECTED_SSID" --passwordbox "\nDefault password: 12345678\n" 9 50 "12345678" 3>&1 1>&2 2>&3)
					if [[ -n "${SELECTED_PASSWORD}" && $? == 0 ]]; then
						# start bridged AP
						netplan set --origin-hint ${yamlfile} renderer=${NETWORK_RENDERER}
						netplan set --origin-hint ${yamlfile} ethernets.$adapter.dhcp4=no
						netplan set --origin-hint ${yamlfile} ethernets.$adapter.dhcp6=no
						netplan set --origin-hint ${yamlfile} bridges.br0.interfaces='['$adapter']'
						netplan set --origin-hint ${yamlfile} bridges.br0.dhcp4=yes
						netplan set --origin-hint ${yamlfile} bridges.br0.dhcp6=yes
						cat <<- EOF > "/etc/hostapd/hostapd.conf"
							interface=$adapter
							driver=nl80211
							ssid=$SELECTED_SSID
							hw_mode=g
							channel=7
							wmm_enabled=0
							macaddr_acl=0
							auth_algs=1
							ignore_broadcast_ssid=0
							wpa=2
							wpa_passphrase=$SELECTED_PASSWORD
							wpa_key_mgmt=WPA-PSK
							wpa_pairwise=TKIP
							rsn_pairwise=CCMP
						EOF
						netplan apply
						# Start hostapd services
						systemctl unmask hostapd 2>/dev/null
						systemctl enable hostapd 2>/dev/null
						systemctl start hostapd 2>/dev/null
						# Sometimes it fails to add to the bridge
						brctl addif br0 $adapter 2>/dev/null
						# Add hooks to hack wrong if type
						if [[ "${NETWORK_RENDERER}" == "NetworkManager" ]]; then
							mkdir -p /etc/NetworkManager/dispatcher.d
							cat <<- EOF > "/etc/NetworkManager/dispatcher.d/armbian-ap"
							#!/bin/bash
							# Added by armbian-config
							interface=\$1
							status=\$2
							case "\$status" in
								up)
									if [[ "\$interface" == "br0" ]]; then
										service hostapd restart
										brctl addif br0 $adapter
									fi
								;;
								down)
									if [[ "\$interface" == "br0" ]]; then
										brctl delif br0 $adapter
									fi
								;;
							esac
							EOF
							chmod +x /etc/NetworkManager/dispatcher.d/armbian-ap
						else
							# workarounding bug in netplan for failing to add wireless adaptor to bridge
							# this might not be needed on all versions
							mkdir -p /etc/networkd-dispatcher/carrier.d/
							cat <<- EOF > "/etc/networkd-dispatcher/carrier.d/armbian-ap"
							#!/bin/sh
							brctl addif br0 $adapter
							netplan apply
							exit 0
							EOF
							chmod +x /etc/networkd-dispatcher/carrier.d/armbian-ap
						fi
					fi
				fi
				else
				show_message <<< "AP (access point) mode is available after you set wired network to static or DHCP mode"
			fi
			;;

			*)
				echo -n "unknown"
				exit
			;;
			esac

		else

			#
			# Wired networking
			#

			# remove default configuration
			rm -f /etc/netplan/10-dhcp-all-interfaces.yaml

			LIST=("dhcp" "Auto IP assigning")
			LIST+=("static" "Set IP manually")
			[[ -f /etc/netplan/armbian.yaml ]] && LIST+=("spoof" "Spoof MAC address")
			LIST_LENGTH=$((${#LIST[@]} / 2))
			wiredmode=$($DIALOG --title "Select IP mode" --menu "" $((${LIST_LENGTH} + 8)) 60 $((${LIST_LENGTH})) "${LIST[@]}" 3>&1 1>&2 2>&3)
			wired_exit=$?
			if [[ "${wiredmode}" == "spoof" && $wired_exit == 0 ]]; then
				local mac_address=$(ip a s ${adapter} | grep link/ether | awk '{print $2}')
				mac_address=$($DIALOG --title "Enter MAC for $adapter" --inputbox "\nValid format: $mac_address" 9 40 "$mac_address" 3>&1 1>&2 2>&3)
				if [[ -n $mac_address && $? == 0 ]]; then
					netplan set --origin-hint ${yamlfile} ethernets.$adapter.macaddress=''$mac_address''
					netplan apply
				fi
			elif [[ "${wiredmode}" == "dhcp" && $wired_exit == 0 ]]; then
				[[ -f /etc/netplan/${yamlfile}.yaml ]] && sed -i -e 'H;x;/^\(  *\)\n\1/{s/\n.*//;x;d;}' -e 's/.*//;x;/bridges/{s/^\( *\).*/ \1/;x;d;}' /etc/netplan/${yamlfile}.yaml
				netplan set --origin-hint ${yamlfile} renderer=${NETWORK_RENDERER}
				netplan set --origin-hint ${yamlfile} ethernets.$adapter.dhcp4=no
				netplan set --origin-hint ${yamlfile} ethernets.$adapter.dhcp6=no
				netplan set --origin-hint ${yamlfile} bridges.br0.interfaces='['$adapter']'
				netplan set --origin-hint ${yamlfile} bridges.br0.dhcp4=yes
				netplan set --origin-hint ${yamlfile} bridges.br0.dhcp6=yes
				show_message <<< "$(netplan get all)"
				$DIALOG --title " Changing network settings " --yes-button "Yes" --no-button "Cancel" --yesno \
				"This action might disconnect you from network.\n\nAre you sure network was configured correctly?" 9 50
				if [[ $? = 0 ]]; then
					# apply NetPlan
					netplan apply
					[[ "${NETWORK_RENDERER}" == "NetworkManager" ]] && systemctl restart NetworkManager;
				else
					restore_netplan_config
				fi
			elif [[ "${wiredmode}" == "static" ]]; then
				local ips=()
				for f in /sys/class/net/*; do
					local intf=$(basename $f)
					# skip unwanted
					if [[ $intf =~ ^dummy0|^lo|^docker|^virbr ]]; then
						continue
					else
						local tmp=$(ip -4 addr show dev $intf | grep -v "$intf:avahi" | awk '/inet/ {print $2}' | uniq)
						[[ -n $tmp ]] && ips+=("$tmp")
					fi
				done
				#address=${ips[@]}
				address=${ips[0]} # use only 1st one
				[[ -z "${address}" ]] && address="1.2.3.4/5"
				# clean values from config
				[[ -f /etc/netplan/${yamlfile}.yaml ]] && sed -i -e 'H;x;/^\(  *\)\n\1/{s/\n.*//;x;d;}' -e 's/.*//;x;/bridges/{s/^\( *\).*/ \1/;x;d;}' /etc/netplan/${yamlfile}.yaml
				address=$($DIALOG --title "Enter IP for $adapter" --inputbox "\nValid format: $address" 9 40 "$address" 3>&1 1>&2 2>&3)
				if [[ -n $address && $? == 0 ]]; then
					defaultroute=$(ip route show default | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]" | head -1 | xargs)
					defaultroute=$($DIALOG --title "Enter IP for default route" --inputbox "\nValid format: $defaultroute" 9 40 "$defaultroute" 3>&1 1>&2 2>&3)
					if [[ -n $defaultroute && $? == 0 ]]; then
						nameservers="9.9.9.9,1.1.1.1"
						nameservers=$($DIALOG --title "Enter DNS server" --inputbox "\nValid format: $nameservers" 9 40 "$nameservers" 3>&1 1>&2 2>&3)
					else
						restore_netplan_config
					fi
					if [[ -n $nameservers && $? == 0 ]]; then
						netplan set --origin-hint ${yamlfile} renderer=${NETWORK_RENDERER}
						netplan set --origin-hint ${yamlfile} ethernets.$adapter.dhcp4=no
						netplan set --origin-hint ${yamlfile} ethernets.$adapter.dhcp6=no
						netplan set --origin-hint ${yamlfile} bridges.br0.interfaces='['$adapter']'
						netplan set --origin-hint ${yamlfile} bridges.br0.addresses='['$address']'
						netplan set --origin-hint ${yamlfile} bridges.br0.routes='[{"to":"0.0.0.0/0", "via": "'$defaultroute'","metric":200}]'
						netplan set --origin-hint ${yamlfile} bridges.br0.nameservers.addresses='['$nameservers']'
					else
						restore_netplan_config
					fi
					if [[ $? == 0 ]]; then
						show_message <<< "$(netplan get all)"
						$DIALOG --title " Changing network settings " --yes-button "Yes" --no-button "Cancel" --yesno \
						"This action might disconnect you from network.\n\nAre you sure network was configured correctly?" 9 50
						if [[ $? = 0 ]]; then
							# apply NetPlan
							netplan apply
							[[ "${NETWORK_RENDERER}" == "NetworkManager" ]] && systemctl restart NetworkManager;
						else
							restore_netplan_config
						fi
					fi
				else
					restore_netplan_config
				fi
			else
				restore_netplan_config
			fi
		fi
	else
		restore_netplan_config
	fi
}


module_options+=(
	["qr_code,author"]="@igorpecovnik"
	["qr_code,ref_link"]=""
	["qr_code,feature"]="qr_code"
	["qr_code,desc"]="Show or generate QR code for Google OTP"
	["qr_code,example"]="qr_code generate"
	["qr_code,status"]="Active"
)
#
# check dpkg status of $1 -- currently only 'not installed at all' case caught
#
function qr_code() {

	clear
	if [[ "$1" == "generate" ]]; then
		google-authenticator -t -d -f -r 3 -R 30 -W -q
		cp /root/.google_authenticator /etc/skel
		update_skel
	fi
	export TOP_SECRET=$(head -1 /root/.google_authenticator)
	qrencode -m 2 -d 9 -8 -t ANSI256 "otpauth://totp/test?secret=$TOP_SECRET"
	echo -e '
Scan QR code with your OTP application on mobile phone
'
	read -n 1 -s -r -p "Press any key to continue"

}


