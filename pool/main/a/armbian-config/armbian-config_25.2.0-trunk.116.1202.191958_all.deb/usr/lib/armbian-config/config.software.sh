module_options+=(
	["install_plexmediaserver,author"]="@schwar3kat"
	["install_plexmediaserver,ref_link"]=""
	["install_plexmediaserver,feature"]="install_plexmediaserver"
	["install_plexmediaserver,desc"]="Install plexmediaserver from repo using apt"
	["install_plexmediaserver,example"]="install_plexmediaserver"
	["install_plexmediaserver,status"]="Active"
)
#
# Install plexmediaserver using apt
#
install_plexmediaserver() {
	if [ ! -f /etc/apt/sources.list.d/plexmediaserver.list ]; then
		echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/plexmediaserver.gpg] https://downloads.plex.tv/repo/deb public main" | sudo tee /etc/apt/sources.list.d/plexmediaserver.list > /dev/null 2>&1
	else
		sed -i "/downloads.plex.tv/s/^#//g" /etc/apt/sources.list.d/plexmediaserver.list > /dev/null 2>&1
	fi
	# Note: for compatibility with existing source file in some builds format must be gpg not asc
	# and location must be /usr/share/keyrings
	wget -qO- https://downloads.plex.tv/plex-keys/PlexSign.key | gpg --dearmor | sudo tee /usr/share/keyrings/plexmediaserver.gpg > /dev/null 2>&1
	apt_install_wrapper apt-get update
	apt_install_wrapper apt-get -y install plexmediaserver
	$DIALOG --msgbox "To test that Plex Media Server  has installed successfully\nIn a web browser go to http://localhost:32400/web or\nhttp://127.0.0.1:32400/web on this computer." 9 70
}


module_options+=(
	["module_readarr,author"]="@armbian"
	["module_readarr,feature"]="module_readarr"
	["module_readarr,desc"]="Install readarr container"
	["module_readarr,example"]="install remove status help"
	["module_readarr,port"]="8787"
	["module_readarr,status"]="Active"
	["module_readarr,arch"]="x86-64,arm64"
)
#
# Module readarr
#
function module_readarr () {
	local title="readarr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/readarr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/readarr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_readarr,example"]}"

	READARR_BASE="${SOFTWARE_FOLDER}/readarr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$READARR_BASE" ]] || mkdir -p "$READARR_BASE" || { echo "Couldn't create storage directory: $READARR_BASE"; exit 1; }
			docker run -d \
			--name=readarr \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ=Etc/UTC \
			-p 8787:8787 \
			-v "${READARR_BASE}/config:/config" \
			-v "${READARR_BASE}/books:/books" `#optional` \
			-v "${READARR_BASE}/client:/downloads" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/readarr:develop
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' readarr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs readarr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${READARR_BASE}" && "${READARR_BASE}" != "/" ]] && rm -rf "${READARR_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_readarr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_readarr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_readarr,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_bazarr,author"]="@igorpecovnik"
	["module_bazarr,feature"]="module_bazarr"
	["module_bazarr,desc"]="Install bazarr container"
	["module_bazarr,example"]="install remove status help"
	["module_bazarr,port"]="6767"
	["module_bazarr,status"]="Active"
	["module_bazarr,arch"]="x86-64,arm64"
)
#
# Module Bazarr
#
function module_bazarr () {
	local title="bazarr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/bazarr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/bazarr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_bazarr,example"]}"

	BAZARR_BASE="${SOFTWARE_FOLDER}/bazarr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$BAZARR_BASE" ]] || mkdir -p "$BAZARR_BASE" || { echo "Couldn't create storage directory: $BAZARR_BASE"; exit 1; }
			docker run -d \
			--name=bazarr \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ=Etc/UTC \
			-p 6767:6767 \
			-v "${BAZARR_BASE}/config:/config" \
			-v "${BAZARR_BASE}/movies:/movies" `#optional` \
			-v "${BAZARR_BASE}/tv:/tv" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/bazarr:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' bazarr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs bazarr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${BAZARR_BASE}" && "${BAZARR_BASE}" != "/" ]] && rm -rf "${BAZARR_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_bazarr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_bazarr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_bazarr,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_jellyseerr,author"]="@armbian"
	["module_jellyseerr,feature"]="module_jellyseerr"
	["module_jellyseerr,desc"]="Install jellyseerr container"
	["module_jellyseerr,example"]="install remove purge status help"
	["module_jellyseerr,port"]="5055"
	["module_jellyseerr,status"]="Active"
	["module_jellyseerr,arch"]="x86-64,arm64"
)
#
# Module jellyseerr
#
function module_jellyseerr () {
	local title="jellyseerr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/jellyseerr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/jellyseerr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_jellyseerr,example"]}"

	JELLYSEERR_BASE="${SOFTWARE_FOLDER}/jellyseerr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$JELLYSEERR_BASE" ]] || mkdir -p "$JELLYSEERR_BASE" || { echo "Couldn't create storage directory: $JELLYSEERR_BASE"; exit 1; }
			docker run -d \
			--name jellyseerr \
			-e LOG_LEVEL=debug \
			-e TZ="$(cat /etc/timezone)" \
			-e PORT=5055 `#optional` \
			-p 5055:5055 \
			-v "${jellyseerr_BASE}/config:/app/config" \
			--restart unless-stopped \
			fallenbagel/jellyseerr
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' jellyseerr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs jellyseerr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
		;;
		"${commands[2]}")
			[[ -n "${JELLYSEERR_BASE}" && "${JELLYSEERR_BASE}" != "/" ]] && rm -rf "${JELLYSEERR_BASE}"
		;;
		"${commands[3]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[4]}")
			echo -e "\nUsage: ${module_options["module_jellyseerr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_jellyseerr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_jellyseerr,feature"]} ${commands[4]}
		;;
	esac
}

declare -A module_options
module_options+=(
	["module_qbittorrent,author"]="@armbian"
	["module_qbittorrent,feature"]="module_qbittorrent"
	["module_qbittorrent,desc"]="Install qbittorrent container"
	["module_qbittorrent,example"]="install remove status help"
	["module_qbittorrent,port"]="8090 6881"
	["module_qbittorrent,status"]="Active"
	["module_qbittorrent,arch"]="x86-64,arm64"
)
#
# Module qbittorrent
#
function module_qbittorrent () {

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/qbittorrent?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/qbittorrent?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_qbittorrent,example"]}"

	QBITTORRENT_BASE="${SOFTWARE_FOLDER}/qbittorrent"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$QBITTORRENT_BASE" ]] || mkdir -p "$QBITTORRENT_BASE" || { echo "Couldn't create storage directory: $QBITTORRENT_BASE"; exit 1; }
			docker run -d \
			--name=qbittorrent \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-e WEBUI_PORT=8090 \
			-e TORRENTING_PORT=6881 \
			-p 8090:8090 \
			-p 6881:6881 \
			-p 6881:6881/udp \
			-v "${QBITTORRENT_BASE}/config:/config" \
			-v "${QBITTORRENT_BASE}/downloads:/downloads" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/qbittorrent:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' qbittorrent >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs qbittorrent\`)"
					exit 1
				fi
			done
			sleep 3
			TEMP_PASSWORD=$(docker logs qbittorrent 2>&1 | grep password | grep session | cut -d":" -f2 | xargs)
			dialog --msgbox "Qbittorrent is listening at http://$LOCALIPADD:${module_options["module_qbittorrent,port"]}\n\nLogin as: admin\n\nTemporally password: ${TEMP_PASSWORD} " 9 70
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${QBITTORRENT_BASE}" && "${QBITTORRENT_BASE}" != "/" ]] && rm -rf "${QBITTORRENT_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_qbittorrent,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_qbittorrent,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_qbittorrent,feature"]} ${commands[3]}
		;;
	esac
}

declare -A module_options
module_options+=(
	["module_haos,author"]="@igorpecovnik"
	["module_haos,feature"]="module_haos"
	["module_haos,example"]="help install uninstall"
	["module_haos,desc"]="Hos container install and configure"
	["module_haos,port"]="8123"
	["module_haos,status"]="review"
)
#
# Install haos container
#
module_haos() {



	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/home-assistant/{print $1}')
		local image=$(docker image ls -a | mawk '/home-assistant/{print $3}')
	fi

	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_haos,example"]}"

	case "$1" in
		"${commands[0]}")
			## help/menu options for the module
			echo -e "\nUsage: ${module_options["module_haos,feature"]} <command>"
			echo -e "Commands: ${module_options["module_haos,example"]}"
			echo "Available commands:"
			if [[ "${container}" ]] || [[ "${image}" ]]; then
				echo -e "\tstatus\t- Show the status of the $title service."
				echo -e "\tremove\t- Remove $title."
			else
				echo -e "  install\t- Install $title."
			fi
			echo
		;;
		install)
			check_if_installed docker-ce || install_docker

			# this hack will allow running it on minimal image, but this has to be done properly in the network section, to allow easy switching
			systemctl disable systemd-networkd

			# hack to force install
			sed -i 's/^PRETTY_NAME=".*/PRETTY_NAME="Debian GNU\/Linux 12 (bookworm)"/g' "${SDCARD}/etc/os-release"

			# we host packages at our repository and version for both is determined:
			# https://github.com/armbian/os/blob/main/external/haos-agent.conf
			# https://github.com/armbian/os/blob/main/external/haos-supervised-installer.conf

			apt_install_wrapper apt-get -y install --download-only homeassistant-supervised os-agent

			# determine machine type
			case "${ARCH}" in
				armhf) MACHINE="tinker";;
				amd64) MACHINE="generic-x86-64";;
				arm64) MACHINE="odroid-n2";;
				*) exit 1;;
			esac

			# this we can't put behind wrapper
			MACHINE="${MACHINE}" apt-get -y install homeassistant-supervised os-agent

			# workarounding supervisor loosing healthy state https://github.com/home-assistant/supervisor/issues/4381
			cat <<- SUPERVISOR_FIX > "/usr/local/bin/supervisor_fix.sh"
			#!/bin/bash
			while true; do
			if ha supervisor info 2>&1 | grep -q "healthy: false"; then
				echo "Unhealthy detected, restarting" | systemd-cat -t $(basename "$0") -p debug
				systemctl restart hassio-supervisor.service
				sleep 600
			else
				sleep 5
			fi
			done
			SUPERVISOR_FIX

			# add executable bit
			chmod +x "/usr/local/bin/supervisor_fix.sh"

			# generate service file to run this script
			cat <<- SUPERVISOR_FIX_SERVICE > "/etc/systemd/system/supervisor-fix.service"
			[Unit]
			Description=Supervisor Unhealthy Fix

			[Service]
			StandardOutput=null
			StandardError=null
			ExecStart=/usr/local/bin/supervisor_fix.sh

			[Install]
			WantedBy=multi-user.target
			SUPERVISOR_FIX_SERVICE

			if [[ -f /boot/armbianEnv.txt ]]; then
				echo "extraargs=systemd.unified_cgroup_hierarchy=0 apparmor=1 security=apparmor" >> "/boot/armbianEnv.txt"
			fi
			sleep 5
			for s in {1..10};do
				for i in {0..100..10}; do
					j=$i
					echo "$i"
					sleep 1
				done
				if [[ -n "$(docker container ls -a | mawk '/hassio-cli/{print $1}')" ]]; then
					ha supervisor info --raw-json >/dev/null
					if [[ $status -ne 0 ]]; then break; fi
				fi
			done | $DIALOG --gauge "Preparing Home Assistant Supervised\n\nPlease wait! " 10 50 0

			# enable service
			systemctl enable supervisor-fix >/dev/null 2>&1
			systemctl start supervisor-fix >/dev/null 2>&1

			# restore os-release
			sed -i "s/^PRETTY_NAME=\".*/PRETTY_NAME=\"${VENDOR} ${REVISION} ($VERSION_CODENAME)\"/g" "/etc/os-release"

			# show that its done
			$DIALOG --msgbox "Home assistant is available at\n\nhttps://${LOCALIPADD}:8123 " 10 38
		;;
		uninstall)
			# disable service
			systemctl disable supervisor-fix >/dev/null 2>&1
			systemctl stop supervisor-fix >/dev/null 2>&1
			apt_install_wrapper apt-get -y purge homeassistant-supervised os-agent
			echo -e "Removing Home Assistant containers.\n\nPlease wait few minutes! "
			if [[ "${container}" ]]; then
				echo "${container}" | xargs docker stop >/dev/null 2>&1
				echo "${container}" | xargs docker rm >/dev/null 2>&1
			fi
			if [[ "${image}" ]]; then
				echo "${image}" | xargs docker image rm >/dev/null 2>&1
			fi
			rm -f /usr/local/bin/supervisor_fix.sh
			rm -f /etc/systemd/system/supervisor-fix.service
			sed -i "s/ systemd.unified_cgroup_hierarchy=0 apparmor=1 security=apparmor//" /boot/armbianEnv.txt
			systemctl daemon-reload >/dev/null 2>&1
			# restore os-release
			sed -i "s/^PRETTY_NAME=\".*/PRETTY_NAME=\"${VENDOR} ${REVISION} ($VERSION_CODENAME)\"/g" "/etc/os-release"
		;;
		status)
			[[ "${container}" ]] || [[ "${image}" ]] && return 0
		;;
	esac
}

module_haos "$1"

module_options+=(
	["module_deluge,author"]="@armbian"
	["module_deluge,feature"]="module_deluge"
	["module_deluge,desc"]="Install deluge container"
	["module_deluge,example"]="install remove status help"
	["module_deluge,port"]="8112 6181 58846"
	["module_deluge,status"]="Active"
	["module_deluge,arch"]="x86-64,arm64"
)
#
# Module deluge
#
function module_deluge () {
	local title="deluge"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/deluge?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/deluge?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_deluge,example"]}"

	DELUGE_BASE="${SOFTWARE_FOLDER}/deluge"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$DELUGE_BASE" ]] || mkdir -p "$DELUGE_BASE" || { echo "Couldn't create storage directory: $DELUGE_BASE"; exit 1; }
			docker run -d \
			--name=deluge \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-e DELUGE_LOGLEVEL=error `#optional` \
			-p 8112:8112 \
			-p 6181:6881 \
			-p 6181:6881/udp \
			-p 58846:58846 `#optional` \
			-v "${DELUGE_BASE}/config:/config" \
			-v "${DELUGE_BASE}/downloads:/downloads" \
			--restart unless-stopped \
			lscr.io/linuxserver/deluge:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' deluge >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs deluge\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${DELUGE_BASE}" && "${DELUGE_BASE}" != "/" ]] && rm -rf "${DELUGE_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_deluge,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_deluge,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_deluge,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_netdata,author"]="@armbian"
	["module_netdata,feature"]="module_netdata"
	["module_netdata,desc"]="Install netdata container"
	["module_netdata,example"]="install remove purge status help"
	["module_netdata,port"]="19999"
	["module_netdata,status"]="Active"
	["module_netdata,arch"]="x86-64,arm64"
)
#
# Module netdata
#
function module_netdata () {
	local title="netdata"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/netdata?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/netdata?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_netdata,example"]}"

	NETDATA_BASE="${SOFTWARE_FOLDER}/netdata"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$NETDATA_BASE" ]] || mkdir -p "$NETDATA_BASE" || { echo "Couldn't create storage directory: $NETDATA_BASE"; exit 1; }
			docker run -d --name=netdata \
			--pid=host \
			--network=host \
			-v "${NETDATA_BASE}/netdataconfig:/etc/netdata" \
			-v "${NETDATA_BASE}/netdatalib:/var/lib/netdata" \
			-v "${NETDATA_BASE}/netdatacache:/var/cache/netdata" \
			-v /:/host/root:ro,rslave \
			-v /etc/passwd:/host/etc/passwd:ro \
			-v /etc/group:/host/etc/group:ro \
			-v /etc/localtime:/etc/localtime:ro \
			-v /proc:/host/proc:ro \
			-v /sys:/host/sys:ro \
			-v /etc/os-release:/host/etc/os-release:ro \
			-v /var/log:/host/var/log:ro \
			-v /var/run/docker.sock:/var/run/docker.sock:ro \
			--restart unless-stopped \
			--cap-add SYS_PTRACE \
			--cap-add SYS_ADMIN \
			--security-opt apparmor=unconfined \
			netdata/netdata
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' netdata >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs netdata\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
		;;
		"${commands[2]}")
			[[ -n "${NETDATA_BASE}" && "${NETDATA_BASE}" != "/" ]] && rm -rf "${NETDATA_BASE}"
		;;
		"${commands[3]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[4]}")
			echo -e "\nUsage: ${module_options["module_netdata,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_netdata,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_netdata,feature"]} ${commands[4]}
		;;
	esac
}


module_options+=(
	["install_docker,author"]="@schwar3kat"
	["install_docker,ref_link"]=""
	["install_docker,feature"]="install_docker"
	["install_docker,desc"]="Install docker from a repo using apt"
	["install_docker,example"]="install_docker engine"
	["install_docker,status"]="Active"
)
#
# Install Docker from repo using apt
# Setup sources list and GPG key then install the app. If you want a full desktop then $1=desktop
#
install_docker() {
	# Check if repo for distribution exists.
	URL="https://download.docker.com/linux/${DISTRO,,}/dists/$DISTROID"
	if wget --spider "${URL}" 2> /dev/null; then
		# Add Docker's official GPG key:
		wget -qO - https://download.docker.com/linux/${DISTRO,,}/gpg | gpg --dearmor | sudo tee /usr/share/keyrings/docker.gpg > /dev/null
		if [[ $? -eq 0 ]]; then
			# Add the repository to Apt sources:
			cat <<- EOF > "/etc/apt/sources.list.d/docker.list"
			deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker.gpg] https://download.docker.com/linux/${DISTRO,,} $DISTROID stable
			EOF
			apt_install_wrapper apt-get update
			# Install docker
			if [ "$1" = "engine" ]; then
				apt_install_wrapper apt-get -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
			else
				apt_install_wrapper apt-get -y install docker-ce docker-ce-cli containerd.io
			fi
			systemctl enable docker.service > /dev/null 2>&1
			systemctl enable containerd.service > /dev/null 2>&1
		fi
	else
		$DIALOG --msgbox "ERROR ! ${DISTRO} $DISTROID distribution not found in repository!" 7 70
	fi
}


module_options+=(
	["module_watchtower,author"]="@armbian"
	["module_watchtower,feature"]="module_watchtower"
	["module_watchtower,desc"]="Install watchtower container"
	["module_watchtower,example"]="install remove status help"
	["module_watchtower,port"]=""
	["module_watchtower,status"]="Active"
	["module_watchtower,arch"]=""
)
#
# Module watchtower
#
function module_watchtower () {
	local title="watchtower"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/watchtower?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/watchtower?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_watchtower,example"]}"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			docker run -d \
			--name watchtower \
			-v /var/run/docker.sock:/var/run/docker.sock \
			containrrr/watchtower
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' watchtower >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs watchtower\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_watchtower,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_watchtower,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_watchtower,feature"]} ${commands[3]}
		;;
	esac
}


module_options+=(
	["openhab,author"]="@igorpecovnik"
	["openhab,ref_link"]=""
	["openhab,feature"]="install_openhab"
	["openhab,desc"]="Install openhab from a repo using apt"
	["openhab,example"]="install uinstall"
	["openhab,status"]="Active"
)
#
# Install openHAB from repo using apt
#
openhab() {

	case "$1" in
		install)

			# keys
			wget -qO - https://repos.azul.com/azul-repo.key | gpg --dearmor > "/usr/share/keyrings/azul.gpg"
			wget -qO - https://openhab.jfrog.io/artifactory/api/gpg/key/public | gpg --dearmor > "/usr/share/keyrings/openhab.gpg"
			# repos
			echo "deb [signed-by=/usr/share/keyrings/azul.gpg] https://repos.azul.com/zulu/deb stable main" > "/etc/apt/sources.list.d/zulu.list"
			echo "deb [signed-by=/usr/share/keyrings/openhab.gpg] https://openhab.jfrog.io/artifactory/openhab-linuxpkg stable main" > "/etc/apt/sources.list.d/openhab.list"

			apt_install_wrapper apt-get update

			# Optional preinstall top 10 tools
			apt_install_wrapper apt-get -y install zulu17-jdk
			apt_install_wrapper apt-get -y install openhab openhab-addons
			systemctl daemon-reload 2> /dev/null
			systemctl enable openhab.service 2> /dev/null
			systemctl start openhab.service 2> /dev/null

			;;

		uninstall)

			apt_install_wrapper apt-get -y remove zulu17-jdk openhab openhab-addons
			systemctl disable openhab.service 2> /dev/null
			rm -f /usr/share/keyrings/openhab.gpg /usr/share/keyrings/azul.gpg
			rm -f /etc/apt/sources.list.d/zulu.list /etc/apt/sources.list.d/openhab.list

			;;
	esac
}



module_options+=(
	["module_webmin,author"]="@Tearran"
	["module_webmin,feature"]="module_webmin"
	["module_webmin,example"]="help install remove start stop enable disable status check"
	["module_webmin,desc"]="Webmin setup and service setting."
	["module_webmin,status"]="review"
)

function module_webmin() {
	local title="webmin"
	local condition=$(which "$title" 2>/dev/null)

	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_webmin,example"]}"

	case "$1" in
		"${commands[0]}")
			## help/menu options for the module
			echo -e "\nUsage: ${module_options["module_webmin,feature"]} <command>"
			echo -e "Commands: ${module_options["module_webmin,example"]}"
			echo "Available commands:"
			if [[ -z "$condition" ]]; then
				echo -e "  install\t- Install $title."
			else

			if [[ "$(systemctl is-active webmin 2>/dev/null)" == "active" ]]; then
				echo -e "\tstop\t- Stop the $title service."
				echo -e "\tdisable\t- Disable $title from starting on boot."
			else
				echo -e "\tenable\t- Enable $title to start on boot."
				echo -e "\tstart\t- Start the $title service."
			fi
				echo -e "\tstatus\t- Show the status of the $title service."
				echo -e "\tremove\t- Remove $title."

			fi
			echo
		;;
		"${commands[1]}")
			## install webmin
			apt update
			apt install -y wget apt-transport-https
			echo "deb [signed-by=/usr/share/keyrings/webmin-archive-keyring.gpg] http://download.webmin.com/download/repository sarge contrib" | sudo tee /etc/apt/sources.list.d/webmin.list
			wget -qO- http://www.webmin.com/jcameron-key.asc | gpg --dearmor | tee /usr/share/keyrings/webmin-archive-keyring.gpg > /dev/null
			apt update
			apt install -y webmin --install-recommends
			echo "Webmin installed successfully."
		;;
		"${commands[2]}")
			## remove webmin
			systemctl disable webmin
			apt purge -y webmin
			apt autoremove --purge -y
			rm /etc/apt/sources.list.d/webmin.list
			rm /usr/share/keyrings/webmin-archive-keyring.gpg
			apt update
			echo "Webmin removed successfully."
		;;

		"${commands[3]}")
			## start webmin
			sudo systemctl start webmin
			echo "Webmin service started."
			;;

		"${commands[4]}")
			## stop webmin
			sudo systemctl stop webmin
			echo "Webmin service stopped."
			;;

		"${commands[5]}")
			## enable webmin
			sudo systemctl enable webmin
			echo "Webmin service enabled."
			;;

		"${commands[6]}")
			## disable webmin
			sudo systemctl disable webmin
			echo "Webmin service disabled."
			;;

		"${commands[7]}")
			## status webmin
			sudo systemctl status webmin
			;;

		"${commands[8]}")
			## check webmin status
			if [[ $(systemctl is-active webmin) == "active" ]]; then
				echo "Webmin service is active."
				return 0
			elif [[ $(systemctl is-enabled webmin) == "disabled" ]]; then
				echo "Webmin service is disabled."
				return 1
			else
				echo "Webmin service is in an unknown state."
				return 1
			fi
			;;
		*)
		echo "Invalid command.try: '${module_options["module_webmin,example"]}'"

		;;
	esac
}


#module_webmin "$1"

module_options+=(
	["module_prowlarr,author"]="@armbian"
	["module_prowlarr,feature"]="module_prowlarr"
	["module_prowlarr,desc"]="Install prowlarr container"
	["module_prowlarr,example"]="install remove status help"
	["module_prowlarr,port"]="9696"
	["module_prowlarr,status"]="Active"
	["module_prowlarr,arch"]="x86-64,arm64"
)
#
# Module prowlarr
#
function module_prowlarr () {
	local title="prowlarr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/prowlarr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/prowlarr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_prowlarr,example"]}"

	PROWLARR_BASE="${SOFTWARE_FOLDER}/prowlarr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$PROWLARR_BASE" ]] || mkdir -p "$PROWLARR_BASE" || { echo "Couldn't create storage directory: $PROWLARR_BASE"; exit 1; }
			docker run -d \
			--name=prowlarr \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-p 9696:9696 \
			-v "${PROWLARR_BASE}/config:/config" \
			--restart unless-stopped \
			lscr.io/linuxserver/prowlarr:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' prowlarr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs prowlarr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${PROWLARR_BASE}" && "${PROWLARR_BASE}" != "/" ]] && rm -rf "${PROWLARR_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_prowlarr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_prowlarr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_prowlarr,feature"]} ${commands[3]}
		;;
	esac
}


module_options+=(
	["pi_hole,author"]="@armbian"
	["pi_hole,ref_link"]=""
	["pi_hole,feature"]="pi_hole"
	["pi_hole,desc"]="Install/uninstall/check status of pi-hole container"
	["pi_hole,example"]="help install uninstall status password"
	["pi_hole,status"]="Active"
)
#
# Install Pi-Hole DNS blocking
#
function pi_hole () {

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/pihole?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/pihole?( |$)/{print $3}')
	fi
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["pi_hole,example"]}"

	PIHOLE_BASE=/opt/pihole-storage
	PIHOLE_BASE="${PIHOLE_BASE:-$(pwd)}"
	[[ -d "$PIHOLE_BASE" ]] || mkdir -p "$PIHOLE_BASE" || { echo "Couldn't create storage directory: $PIHOLE_BASE"; exit 1; }

	case "$1" in
		"${commands[0]}")
			## help/menu options for the module
			echo -e "\nUsage: ${module_options["pi_hole,feature"]} <command>"
			echo -e "Commands: ${module_options["pi_hole,example"]}"
			echo "Available commands:"
			if [[ "${container}" ]] || [[ "${image}" ]]; then
				echo -e "\tstatus\t- Show the status of the $title service."
				echo -e "\tremove\t- Remove $title."
			else
				echo -e "  install\t- Install $title."
			fi
			echo
		;;
		install)

			check_if_installed docker-ce || install_docker

			# disable dns within systemd-resolved
			if systemctl is-active --quiet systemd-resolved.service && ! grep -q "^DNSStubListener=no" /etc/systemd/resolved.conf; then
				sed -i "s/^#\?DNSStubListener=.*/DNSStubListener=no/" /etc/systemd/resolved.conf
				systemctl restart systemd-resolved.service
				sleep 3
			fi
			# disable dns within Network manager
			if systemctl is-active --quiet NetworkManager && grep -q "dns=true" /etc/NetworkManager/NetworkManager.conf; then
				sed -i "s/dns=.*/dns=false/g" /etc/NetworkManager/NetworkManager.conf
				systemctl restart NetworkManager
				sleep 3
			fi

			docker run -d \
			--name pihole \
			-p 53:53/tcp -p 53:53/udp \
			-p 80:80 \
			-e TZ="$(cat /etc/timezone)" \
			-v "${PIHOLE_BASE}/etc-pihole:/etc/pihole" \
			-v "${PIHOLE_BASE}/etc-dnsmasq.d:/etc/dnsmasq.d" \
			--dns=9.9.9.9 \
			--restart=unless-stopped \
			--hostname pi.hole \
			-e VIRTUAL_HOST="pi.hole" \
			-e PROXY_LOCATION="pi.hole" \
			-e FTLCONF_LOCAL_IPV4="${LOCALIPADD}" \
			pihole/pihole:latest

			for i in $(seq 1 20); do
				if [ "$(docker inspect -f "{{.State.Health.Status}}" pihole)" == "healthy" ] ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for Pi-hole start, consult your container logs for more info (\`docker logs pihole\`)"
					exit 1
				fi
			done
		;;

		uninstall)
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
		;;
		password)
			SELECTED_PASSWORD=$($DIALOG --title "Enter new password for Pi-hole admin" --passwordbox "" 7 50 3>&1 1>&2 2>&3)
			if [[ -n $SELECTED_PASSWORD ]]; then
				docker exec -it "${container}" sh -c "sudo pihole -a -p ${SELECTED_PASSWORD}" >/dev/null
			fi
		;;
		status)
			[[ "${container}" ]] || [[ "${image}" ]] && return 0
		;;
	esac
}

#pi_hole help


module_options+=(
	["see_monitoring,author"]="@Tearran"
	["see_monitoring,ref_link"]=""
	["see_monitoring,feature"]="see_monitoring"
	["see_monitoring,desc"]="Menu for armbianmonitor features"
	["see_monitoring,example"]="see_monitoring"
	["see_monitoring,status"]="review"
	["see_monitoring,doc_link"]=""
)
#
# @decrition generate a menu for armbianmonitor
#
function see_monitoring() {
	if [ -f /usr/bin/htop ]; then
		choice=$(armbianmonitor -h | grep -Ev '^\s*-c\s|^\s*-M\s' | show_menu)

		armbianmonitor -$choice

	else
		echo "htop is not installed"
	fi
}

module_options+=(
	["module_lidarr,author"]="@armbian"
	["module_lidarr,feature"]="module_lidarr"
	["module_lidarr,desc"]="Install lidarr container"
	["module_lidarr,example"]="install remove status help"
	["module_lidarr,port"]="8686"
	["module_lidarr,status"]="Active"
	["module_lidarr,arch"]="x86-64,arm64"
)
#
# Module lidarr
#
function module_lidarr () {
	local title="lidarr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/lidarr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/lidarr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_lidarr,example"]}"

	LIDARR_BASE="${SOFTWARE_FOLDER}/lidarr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$LIDARR_BASE" ]] || mkdir -p "$LIDARR_BASE" || { echo "Couldn't create storage directory: $LIDARR_BASE"; exit 1; }
			docker run -d \
			--name=lidarr \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-p 8686:8686 \
			-v "${LIDARR_BASE}/config:/config" \
			-v "${LIDARR_BASE}/music:/music" `#optional` \
			-v "${LIDARR_BASE}/downloads:/downloads" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/lidarr:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' lidarr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs lidarr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${LIDARR_BASE}" && "${LIDARR_BASE}" != "/" ]] && rm -rf "${LIDARR_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_lidarr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_lidarr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_lidarr,feature"]} ${commands[3]}
		;;
	esac
}


module_options+=(
	["module_portainer,author"]="@armbian"
	["module_portainer,ref_link"]=""
	["module_portainer,feature"]="module_portainer"
	["module_portainer,desc"]="Install/uninstall/check status of portainer container"
	["module_portainer,example"]="help install uninstall status"
	["module_portainer,status"]="Active"
	["module_portainer,port"]="9000"
)
#
# Install portainer container
#
module_portainer() {

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/portainer\/portainer(-ce)?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/portainer\/portainer(-ce)?( |$)/{print $3}')
	fi
	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_portainer,example"]}"

	case "$1" in
		"${commands[0]}")
			## help/menu options for the module
			echo -e "\nUsage: ${module_options["module_webmin,feature"]} <command>"
			echo -e "Commands: ${module_options["module_webmin,example"]}"
			echo "Available commands:"
			if [[ "${container}" ]] || [[ "${image}" ]]; then
				echo -e "\tstatus\t- Show the status of the $title service."
				echo -e "\tremove\t- Remove $title."
			else
				echo -e "  install\t- Install $title."
			fi
			echo
		;;
		install)
			check_if_installed docker-ce || install_docker
			docker volume ls -q | grep -xq 'portainer_data' || docker volume create portainer_data
			docker run -d \
			-p '9000:9000' \
			-p '8000:8000' \
			-p '9443:9443' \
			--name=portainer --restart=always \
			-v '/run/docker.sock:/var/run/docker.sock' \
			-v '/etc/ssl/certs/ca-certificates.crt:/etc/ssl/certs/ca-certificates.crt:ro' \
			-v 'portainer_data:/data' 'portainer/portainer-ce'
		;;
		uninstall)
			[[ "${container}" ]] && docker container rm -f "$container"
			[[ "${image}" ]] && docker image rm "$image"
		;;
		status)
			[[ "${container}" ]] || [[ "${image}" ]] && return 0
		;;
	esac
}

#module_portainer help

declare -A module_options
module_options+=(
	["module_medusa,author"]="@armbian"
	["module_medusa,feature"]="module_medusa"
	["module_medusa,desc"]="Install medusa container"
	["module_medusa,example"]="install remove status help"
	["module_medusa,port"]="8081"
	["module_medusa,status"]="Active"
	["module_medusa,arch"]="x86-64,arm64"
)
#
# Install Module medusa
#
function module_medusa () {
	local title="Medusa"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/medusa?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/medusa?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_medusa,example"]}"

	MEDUSA_BASE="${SOFTWARE_FOLDER}/medusa"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$MEDUSA_BASE" ]] || mkdir -p "$MEDUSA_BASE" || { echo "Couldn't create storage directory: $MEDUSA_BASE"; exit 1; }
			docker run -d \
			--name=medusa \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-p 8081:8081 \
			-v "${MEDUSA_BASE}/config:/config" \
			-v "${MEDUSA_BASE}/downloads:/downloads" \
			-v "${MEDUSA_BASE}/downloads/tv:/tv" \
			--restart unless-stopped \
			lscr.io/linuxserver/medusa:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' medusa >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs medusa\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${MEDUSA_BASE}" && "${MEDUSA_BASE}" != "/" ]] && rm -rf "${MEDUSA_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_medusa,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_medusa,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_medusa,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_sonarr,author"]="@armbian"
	["module_sonarr,feature"]="module_sonarr"
	["module_sonarr,desc"]="Install sonarr container"
	["module_sonarr,example"]="install remove status help"
	["module_sonarr,port"]="8989"
	["module_sonarr,status"]="Active"
	["module_sonarr,arch"]="x86-64,arm64"
)
#
# Mmodule_sonarr
#
function module_sonarr () {
	local title="sonarr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/sonarr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/sonarr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_sonarr,example"]}"

	SONARR_BASE="${SOFTWARE_FOLDER}/sonarr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$SONARR_BASE" ]] || mkdir -p "$SONARR_BASE" || { echo "Couldn't create storage directory: $SONARR_BASE"; exit 1; }
			docker run -d \
			--name=sonarr \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-p 8989:8989 \
			-v "${SONARR_BASE}/config:/config" \
			-v "${SONARR_BASE}/tvseries:/tv" `#optional` \
			-v "${SONARR_BASE}/client:/downloads" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/sonarr:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' sonarr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs sonarr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${SONARR_BASE}" && "${SONARR_BASE}" != "/" ]] && rm -rf "${SONARR_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_sonarr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_sonarr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_sonarr,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_stirling,author"]="@Frooodle"
	["module_stirling,maintainer"]="@armbian @igorpecovnik"
	["module_stirling,testers"]="@igorpecovnik"
	["module_stirling,feature"]="module_stirling"
	["module_stirling,desc"]="Install stirling container"
	["module_stirling,example"]="install remove purge status help"
	["module_stirling,port"]="8077"
	["module_stirling,status"]="Active"
	["module_stirling,arch"]=""
)
#
# Module stirling-PDF
#
function module_stirling () {
	local title="stirling"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/stirling-pdf?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/stirling-pdf?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_stirling,example"]}"

	STIRLING_BASE="${SOFTWARE_FOLDER}/stirling"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$STIRLING_BASE" ]] || mkdir -p "$STIRLING_BASE" || { echo "Couldn't create storage directory: $STIRLING_BASE"; exit 1; }
			docker run -d \
			-p 8077:8080 \
			-v "${STIRLING_BASE}/trainingData:/usr/share/tessdata" \
			-v "${STIRLING_BASE}/extraConfigs:/configs" \
			-v "${STIRLING_BASE}/logs:/logs" \
			-v "${STIRLING_BASE}/customFiles:/customFiles" \
			-e DOCKER_ENABLE_SECURITY=false \
			-e INSTALL_BOOK_AND_ADVANCED_HTML_OPS=false \
			-e LANGS=en_GB \
			--name stirling-pdf \
			stirlingtools/stirling-pdf:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' stirling-pdf >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs stirling-pdf\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
		;;
		"${commands[2]}")
			[[ -n "${STIRLING_BASE}" && "${STIRLING_BASE}" != "/" ]] && rm -rf "${STIRLING_BASE}"
		;;
		"${commands[3]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[4]}")
			echo -e "\nUsage: ${module_options["module_stirling,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_stirling,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tpurge\t- Purge $title data folder."
			echo -e "\tstatus\t- Installation status $title."

			echo
		;;
		*)
		${module_options["module_stirling,feature"]} ${commands[4]}
		;;
	esac
}


module_options+=(
	["install_embyserver,author"]="@schwar3kat"
	["install_embyserver,ref_link"]=""
	["install_embyserver,feature"]="install_embyserver"
	["install_embyserver,desc"]="Install embyserver from repo using apt"
	["install_embyserver,example"]="install_embyserver"
	["install_embyserver,status"]="Active"
)
#
#
# Download a deb file from a URL and install using wget and apt with dialog progress bars
#
install_embyserver() {
	URL=$(curl -s https://api.github.com/repos/MediaBrowser/Emby.Releases/releases/latest |
		grep "/emby-server-deb.*$(dpkg --print-architecture).deb" | cut -d : -f 2,3 | tr -d '"')
	cd ~/
	wget -O "emby-server.deb" $URL 2>&1 | stdbuf -oL awk '/[.] +[0-9][0-9]?[0-9]?%/ { print substr($0,63,3) }' |
		$DIALOG --gauge "Please wait\nDownloading ${URL##*/}" 8 70 0
	apt_install_wrapper apt-get -y install ~/emby-server.deb
	unlink emby-server.deb
	$DIALOG --msgbox "To test that Emby Server  has installed successfully\nIn a web browser go to http://localhost:8096 or \nhttp://127.0.0.1:8096 on this computer." 9 70
}

module_options+=(
	["module_uptimekuma,author"]="@armbian"
	["module_uptimekuma,feature"]="module_uptimekuma"
	["module_uptimekuma,desc"]="Install uptimekuma container"
	["module_uptimekuma,example"]="install remove purge status help"
	["module_uptimekuma,port"]="3001"
	["module_uptimekuma,status"]="Active"
	["module_uptimekuma,arch"]="x86-64,arm64"
)
#
# Module uptimekuma
#
function module_uptimekuma () {
	local title="uptimekuma"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/uptime-kuma?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/uptime-kuma?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_uptimekuma,example"]}"

	UPTIMEKUMA_BASE="${SOFTWARE_FOLDER}/uptimekuma"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$UPTIMEKUMA_BASE" ]] || mkdir -p "$UPTIMEKUMA_BASE" || { echo "Couldn't create storage directory: $UPTIMEKUMA_BASE"; exit 1; }
			docker run -d --name uptime-kuma \
			--restart=always \
			-p 3001:3001 \
			-v "${UPTIMEKUMA_BASE}:/app/data" \
			louislam/uptime-kuma:1
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' uptime-kuma >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs uptimekuma\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
		;;
		"${commands[2]}")
			[[ -n "${UPTIMEKUMA_BASE}" && "${UPTIMEKUMA_BASE}" != "/" ]] && rm -rf "${UPTIMEKUMA_BASE}"
		;;
		"${commands[3]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[4]}")
			echo -e "\nUsage: ${module_options["module_uptimekuma,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_uptimekuma,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tpurge\t- Purge $title data folder."
			echo -e "\tstatus\t- Installation status $title."
			echo
		;;
		*)
		${module_options["module_uptimekuma,feature"]} ${commands[4]}
		;;
	esac
}

module_options+=(
	["module_transmission,author"]="@armbian"
	["module_transmission,feature"]="module_transmission"
	["module_transmission,desc"]="Install transmission container"
	["module_transmission,example"]="install remove status help"
	["module_transmission,port"]="9091"
	["module_transmission,status"]="Active"
	["module_transmission,arch"]="x86-64,arm64"
)
#
# Module transmission
#
function module_transmission () {
	local title="transmission"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/transmission?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/transmission?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_transmission,example"]}"

	TRANSMISSION_BASE="${SOFTWARE_FOLDER}/transmission"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$TRANSMISSION_BASE" ]] || mkdir -p "$TRANSMISSION_BASE" || { echo "Couldn't create storage directory: $TRANSMISSION_BASE"; exit 1; }
			docker run -d \
			--name=transmission \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-e TRANSMISSION_WEB_HOME= `#optional` \
			-e USER= `#optional` \
			-e PASS= `#optional` \
			-e WHITELIST= `#optional` \
			-e PEERPORT= `#optional` \
			-e HOST_WHITELIST= `#optional` \
			-p 9091:9091 \
			-p 51413:51413 \
			-p 51413:51413/udp \
			-v "${TRANSMISSION_BASE}/config:/config" \
			-v "${TRANSMISSION_BASE}/downloads:/downloads" \
			-v "${TRANSMISSION_BASE}/watch:/watch" \
			--restart unless-stopped \
			lscr.io/linuxserver/transmission:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' transmission >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs transmission\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${TRANSMISSION_BASE}" && "${TRANSMISSION_BASE}" != "/" ]] && rm -rf "${TRANSMISSION_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_transmission,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_transmission,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_transmission,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_radarr,author"]="@armbian"
	["module_radarr,feature"]="module_radarr"
	["module_radarr,desc"]="Install radarr container"
	["module_radarr,example"]="install remove status help"
	["module_radarr,port"]="7878"
	["module_radarr,status"]="Active"
	["module_radarr,arch"]="x86-64,arm64"
)
#
# Module radarr
#
function module_radarr () {
	local title="radarr"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/radarr?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/radarr?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_radarr,example"]}"

	RADARR_BASE="${SOFTWARE_FOLDER}/radarr"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$RADARR_BASE" ]] || mkdir -p "$RADARR_BASE" || { echo "Couldn't create storage directory: $RADARR_BASE"; exit 1; }
			docker run -d \
			--name=radarr \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-p 7878:7878 \
			-v "${RADARR_BASE}/config:/config" \
			-v "${RADARR_BASE}/movies:/movies" `#optional` \
			-v "${RADARR_BASE}/client:/downloads" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/radarr:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' radarr >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs radarr\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${RADARR_BASE}" && "${RADARR_BASE}" != "/" ]] && rm -rf "${RADARR_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_radarr,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_radarr,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_radarr,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_sabnzbd,author"]="@armbian"
	["module_sabnzbd,feature"]="module_sabnzbd"
	["module_sabnzbd,desc"]="Install sabnzbd container"
	["module_sabnzbd,example"]="install remove status help"
	["module_sabnzbd,port"]="8080"
	["module_sabnzbd,status"]="Active"
	["module_sabnzbd,arch"]="x86-64,arm64"
)
#
# Module Sabnzbd
#
function module_sabnzbd () {
	local title="Sabnzbd"
	local condition=$(which "$title" 2>/dev/null)

	if check_if_installed docker-ce; then
		local container=$(docker container ls -a | mawk '/sabnzbd?( |$)/{print $1}')
		local image=$(docker image ls -a | mawk '/sabnzbd?( |$)/{print $3}')
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_sabnzbd,example"]}"

	SABNZBD_BASE="${SOFTWARE_FOLDER}/sabnzbd"

	case "$1" in
		"${commands[0]}")
			check_if_installed docker-ce || install_docker
			[[ -d "$SABNZBD_BASE" ]] || mkdir -p "$SABNZBD_BASE" || { echo "Couldn't create storage directory: $SABNZBD_BASE"; exit 1; }
			docker run -d \
			--name=sabnzbd \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-p 8080:8080 \
			-v "${SABNZBD_BASE}/config:/config" \
			-v "${SABNZBD_BASE}/downloads:/downloads" `#optional` \
			-v "${SABNZBD_BASE}/incomplete:/incomplete-downloads" `#optional` \
			--restart unless-stopped \
			lscr.io/linuxserver/sabnzbd:latest
			for i in $(seq 1 20); do
				if docker inspect -f '{{ index .Config.Labels "build_version" }}' sabnzbd >/dev/null 2>&1 ; then
					break
				else
					sleep 3
				fi
				if [ $i -eq 20 ] ; then
					echo -e "\nTimed out waiting for ${title} to start, consult your container logs for more info (\`docker logs sabnzbd\`)"
					exit 1
				fi
			done
		;;
		"${commands[1]}")
			[[ "${container}" ]] && docker container rm -f "$container" >/dev/null
			[[ "${image}" ]] && docker image rm "$image" >/dev/null
			[[ -n "${SABNZBD_BASE}" && "${SABNZBD_BASE}" != "/" ]] && rm -rf "${SABNZBD_BASE}"
		;;
		"${commands[2]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_sabnzbd,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_sabnzbd,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_sabnzbd,feature"]} ${commands[3]}
		;;
	esac
}

