#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi
#if [ -f /etc/lightdm/slick-greeter.conf ]; then sed -i 's/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg/armbian-4k-purplepunk-gauss.jpg/g' /etc/lightdm/slick-greeter.conf; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i /etc/pulse/default.pa; fi

##dconf desktop settings
keys=/etc/dconf/db/local.d/00-desktop
profile=/etc/dconf/profile/user

install -Dv /dev/null $keys
install -Dv /dev/null $profile

# gather dconf settings
# deconf dump org/nemo/ > nemo_backup
# deconf dump org/budgie/ > budgie_desktop_backup

echo "[org/nemo/desktop]
desktop-layout='true::false'
font='Noto Sans UI 11'

[org/nemo/list-view]
default-visible-columns=['name', 'size', 'type', 'date_modified', 'owner', 'permissions']

[org/nemo/preferences]
quick-renames-with-pause-in-between=true
show-advanced-permissions=true
show-compact-view-icon-toolbar=false
show-full-path-titles=true
show-hidden-files=true
show-home-icon-toolbar=true
show-icon-view-icon-toolbar=false
show-image-thumbnails='never'
show-list-view-icon-toolbar=false
show-new-folder-icon-toolbar=true
show-open-in-terminal-toolbar=true

[org/nemo/window-state]
geometry='800x550+550+244'
maximized=false
sidebar-bookmark-breakpoint=5

[org/gnome/desktop/background]
color-shading-type='solid'
picture-options='stretched'
picture-uri='file:////usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
primary-color='#008094'

[org/gnome/settings-daemon/plugins/power]
sleep-inactive-ac-timeout='0'

[org/gnome/desktop/interface]
cursor-theme='DMZ-White'
document-font-name='Noto Sans UI 11'
font-name='Noto Sans UI 11'
gtk-im-module='gtk-im-context-simple'
gtk-theme='Numix'
icon-theme='LoginIcons'
monospace-font-name='Noto Mono 11'
toolkit-accessibility=false

[org/gnome/desktop/screensaver]
picture-uri='file:///usr/share/backgrounds/armbian-lightdm/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg'

[org/cinnamon/desktop/applications/terminal]
exec='/usr/bin/terminator'

[org/cinnamon/desktop/default-applications/terminal]
exec='/usr/bin/terminator'

[org/gnome/desktop/wm/preferences]
button-layout='appmenu:minimize,maximize,close'
num-workspaces=2
theme='Plata-Compact'
titlebar-font='Noto Sans UI Bold 11'

[org/ubuntubudgie/budgie-wpreviews]
allworkspaces=true
enable-previews=true" >> $keys

echo "user-db:user
system-db:local" >> $profile

dconf update

#re-compile schemas
if [ -d /usr/share/glib-2.0/schemas ]; then glib-compile-schemas /usr/share/glib-2.0/schemas; fi
