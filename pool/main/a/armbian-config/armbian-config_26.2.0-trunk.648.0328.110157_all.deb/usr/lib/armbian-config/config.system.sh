
module_options+=(

["adjust_motd,author"]="@igorpecovnik"
["adjust_motd,ref_link"]=""
["adjust_motd,feature"]="about_armbian_configng"
["adjust_motd,desc"]="Adjust welcome screen (motd)"
["adjust_motd,example"]="adjust_motd clear, header, sysinfo, tips, commands"
["adjust_motd,status"]="Active"
)
#
# @description Toggle message of the day items
#
function adjust_motd() {

	# show motd description
	motd_desc() {
		case $1 in
			clear|00-clear)
				echo "Clear screen on login"
				;;
			header|10-armbian-header)
				echo "Show header with logo and version info"
				;;
			ap-info|15-ap-info)
				echo "Display active Wi-Fi access point (SSID, channel)"
				;;
			ip-info|20-ip-info)
				echo "Show LAN/WAN IPv4 and IPv6 addresses"
				;;
			containers-info|25-containers-info)
				echo "List running Docker containers"
				;;
			sysinfo|30-armbian-sysinfo)
				echo "Display performance and system information"
				;;
			tips|35-armbian-tips)
				echo "Show helpful tips and Armbian resources"
				;;
			commands|41-commands)
				echo "Show recommended commands"
				;;
			autoreboot-warn|98-armbian-autoreboot-warn)
				echo "Warn about pending automatic reboot after update"
				;;
			*)
				echo "No description available"
				;;
		esac
	}

	# read status
	function motd_status() {
		source /etc/default/armbian-motd
		if [[ $MOTD_DISABLE == *$1* ]]; then
			echo "OFF"
		else
			echo "ON"
		fi
	}

	LIST=()
	for v in $(grep THIS_SCRIPT= /etc/update-motd.d/* | cut -d"=" -f2 | sed "s/\"//g"); do
		LIST+=("$v" "$(motd_desc $v)" "$(motd_status $v)")
	done

	INLIST=($(grep THIS_SCRIPT= /etc/update-motd.d/* | cut -d"=" -f2 | sed "s/\"//g"))
	CHOICES=$(dialog_checklist "Adjust welcome screen" "" 14 76 8 --separate-output --nocancel -- "${LIST[@]}")
	INSERT="$(echo "${INLIST[@]}" "${CHOICES[@]}" | tr ' ' '\n' | sort | uniq -u | tr '\n' ' ' | sed 's/ *$//')"
	# adjust motd config
	sed -i "s/^MOTD_DISABLE=.*/MOTD_DISABLE=\"$INSERT\"/g" /etc/default/armbian-motd
	reset
	clear
	find /etc/update-motd.d/. -type f -executable | sort | bash
	echo "Press any key to return to armbian-config"
	read
}


module_options+=(
["about_armbian_configng,author"]="@igorpecovnik"
["about_armbian_configng,ref_link"]=""
["about_armbian_configng,feature"]="about_armbian_configng"
["about_armbian_configng,desc"]="Show general information about this tool"
["about_armbian_configng,example"]="about_armbian_configng"
["about_armbian_configng,status"]="Active"
)
#
# @description Show general information about this tool
#
function about_armbian_configng() {

	echo "Armbian Config: The Next Generation"
	echo ""
	echo "How to make this tool even better?"
	echo ""
	echo "- propose new features or software titles"
	echo "  https://github.com/armbian/configng/issues/new?template=feature-reqests.yml"
	echo ""
	echo "- report bugs"
	echo "  https://github.com/armbian/configng/issues/new?template=bug-reports.yml"
	echo ""
	echo "- support developers with a small donation"
	echo "  https://github.com/sponsors/armbian"
	echo ""

}

module_options+=(
	["module_armbian_rsyncd,author"]="@igorpecovnik"
	["module_armbian_rsyncd,maintainer"]="@igorpecovnik"
	["module_armbian_rsyncd,feature"]="module_armbian_rsyncd"
	["module_armbian_rsyncd,example"]="install remove status help"
	["module_armbian_rsyncd,desc"]="Install and configure Armbian rsyncd."
	["module_armbian_rsyncd,doc_link"]=""
	["module_armbian_rsyncd,group"]="Armbian"
	["module_armbian_rsyncd,status"]="Active"
	["module_armbian_rsyncd,port"]="873"
	["module_armbian_rsyncd,arch"]=""
)

function module_armbian_rsyncd() {
	local title="rsyncd"
	local condition=$(which "$title" 2>/dev/null)

	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_armbian_rsyncd,example"]}"

	case "$1" in
		"${commands[0]}")
			if export_path=$(dialog_inputbox "Where is armbian file storage located?" "" "/armbian/openssh-server/storage"); then

				# lets make temporally file
				rsyncd_config=$(mktemp)
				if target_sync=$(dialog_checklist "Select rsync target" "Choose which Armbian rsync targets to mirror" 15 60 6 \
				"apt" "Armbian stable packages" ON \
				"dl" "Stable images" ON \
				"beta" "Armbian unstable packages" OFF \
				"archive" "Old images" OFF \
				"oldarchive" "Very old archive" OFF \
				"cache" "Nightly and community images cache" OFF); then

					for choice in $(echo ${target_sync} | tr -d '"'); do
						cat <<- EOF >> $rsyncd_config
						[$choice]
						path = $export_path/$choice
						max connections = 8
						uid = nobody
						gid = users
						list = yes
						read only = yes
						write only = no
						use chroot = yes
						lock file = /run/lock/rsyncd-$choice
						EOF
					done
					mv $rsyncd_config /etc/rsyncd.conf
					pkg_update
					pkg_install rsync >/dev/null 2>&1
					srv_enable rsync >/dev/null 2>&1
					srv_start rsync >/dev/null 2>&1
				fi
			fi
		;;
		"${commands[1]}")
			srv_stop rsync >/dev/null 2>&1
			rm -f /etc/rsyncd.conf
		;;
		"${commands[2]}")
			if srv_active rsyncd; then
				return 0
			elif ! srv_enabled rsync; then
				return 1
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_armbian_rsyncd,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_armbian_rsyncd,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tstatus\t- Status of $title."
			echo
		;;
		*)
			${module_options["module_armbian_rsyncd,feature"]} ${commands[3]}
		;;
	esac
	}


module_options+=(
["store_netplan_config,author"]="@igorpecovnik"
["store_netplan_config,ref_link"]="store_netplan_config"
["store_netplan_config,feature"]="store_netplan_config"
["store_netplan_config,desc"]="Storing netplan config to tmp"
["store_netplan_config,example"]="store_netplan_config"
["store_netplan_config,status"]="Active"
)
#
# @description Storing Netplan configuration to temp folder
#
function store_netplan_config () {

	# store current configs to temporal folder
	restore_netplan_config_folder=$(mktemp -d /tmp/XXXXXXXXXX)
	rsync --quiet /etc/netplan/* ${restore_netplan_config_folder}/ 2>/dev/null
	trap restore_netplan_config 1 2 3 6

}



module_options+=(
["manage_dtoverlays,author"]="@viraniac"
["manage_dtoverlays,maintainer"]="@igorpecovnik,@The-going"
["manage_dtoverlays,ref_link"]=""
["manage_dtoverlays,feature"]="manage_dtoverlays"
["manage_dtoverlays,desc"]="Enable/disable device tree overlays"
["manage_dtoverlays,example"]=""
["manage_dtoverlays,status"]="Active"
["manage_dtoverlays,group"]="Kernel"
["manage_dtoverlays,port"]=""
["manage_dtoverlays,arch"]="aarch64 armhf"
)
#
# @description Enable/disable device tree overlays
#
function manage_dtoverlays () {
	# check if user agree to enter this area
	local changes="false"
	local overlayconf="/boot/armbianEnv.txt"
	if [[ "${LINUXFAMILY}" == "bcm2711" ]]; then
		# Raspberry Pi has different name
		overlayconf="/boot/firmware/config.txt"
		local overlaydir=$(find /boot/dtb/ -maxdepth 1 -type d \( -name "overlay" -o -name "overlays" \) | head -n1)
		local overlay_prefix=$(awk -F= '/^overlay_prefix=/ {print $2}' "$overlayconf")
	else
		local overlaydir="$(find /boot/dtb/ -name overlay -and -type d)"
		local overlay_prefix=$(awk -F"=" '/overlay_prefix/ {print $2}' $overlayconf)
	fi
	if [[ -z $(find "$overlaydir" -name "*$overlay_prefix*" 2>/dev/null) && "$LINUXFAMILY" != "bcm2711" ]]; then
		echo "Invalid overlay_prefix $overlay_prefix"; exit 1
	fi

	[[ ! -f "${overlayconf}" || ! -d "${overlaydir}" ]] && echo -e "Incompatible OS configuration\nArmbian device tree configuration files not found" | show_message && return 1

	# check /boot/boot.scr scenario overlay(s)/${overlay_prefix}-${overlay_name}.dtbo
	# or overlay(s)/${overlay_name}.dtbo.
	# scenario:
	# 00 - The /boot/boot.scr script cannot load the overlays provided by Armbian.
	# 01 - It is possible to load only if the full name of the overlay is written.
	# 10 - Loading is possible only if the overlay name is written without a prefix.
	# 11 - Both spellings will be loaded.
	scenario=$(
		awk 'BEGIN{p=0;s=0}
			/load.*overlays?\/\${overlay_prefix}-\${overlay_file}.dtbo/{p=1}
			/load.*overlays?\/\${overlay_file}.dtbo/{s=1}
			END{print p s}
		' /boot/boot.scr
	)

	while true; do
		local options=()
		j=0

		if [[ "${scenario}" == "10" ]] || [[ "${scenario}" == "11" ]]; then
			# read overlays
			available_overlays=$(
				# Find the files that match the overlay prefix pattern.
				# Remove the overlay prefix, file extension, and path
				# in one pass. Sort it out.
				find "${overlaydir}"/ -name "$overlay_prefix"'*.dtbo' 2>/dev/null | \
				awk -F'/' -v p="${overlay_prefix}-" '{
					gsub(p, "", $NF)
					gsub(".dtbo", "", $NF)
					print $NF
				}' | sort
			)
		fi

		# Check the branch in case it is not available in /etc/armbian-release
		update_kernel_env

		# Add support for rk3588 vendor kernel overlays which don't have overlay prefix mostly
		builtin_overlays=""
		if [[ "${scenario}" == "01" ]] || [[ "${scenario}" == "11" ]]; then

			if [[ $BOARDFAMILY == "rockchip-rk3588" ]] && [[ $BRANCH == "vendor" ]]; then
				builtin_overlays=$(
					find "${overlaydir}"/ -name '*.dtbo' ! -name "$overlay_prefix"'*.dtbo' 2>/dev/null | \
					awk -F'/' -v p="${overlay_prefix}" '{
						if ($0 !~ p) {
							gsub(".dtbo", "", $NF)
							print $NF
						}
					}' | sort
				)
			fi
		fi

		if [[ "${scenario}" == "00" ]]; then
			dialog_yesno "Manage devicetree overlays" "    The overlays provided by Armbian cannot be loaded\n    by /boot/boot.scr script.\n" "Exit" "Cancel" 11 44
				exit_status=$?
			if [ $exit_status == 0 ]; then
				exit 0
			fi
			break
		fi

		for overlay in ${available_overlays} ${builtin_overlays}; do
			local status="OFF"
			grep '^overlays' ${overlayconf} | grep -qw ${overlay} && status=ON
			# Raspberry Pi
			grep '^dtoverlay' ${overlayconf} | grep -qw ${overlay} && status=ON
			# handle case where overlay_prefix is part of overlay name
			if [[ -n $overlay_prefix ]]; then
				candidate="${overlay#$overlay_prefix}"
				candidate="${candidate#'-'}" # remove any trailing hyphen
			else
				candidate="$overlay"
			fi
			grep '^overlays' ${overlayconf} | grep -qw ${candidate} && status=ON
			options+=( "$overlay" "" "$status")
		done
		selection=$(dialog_checklist "Manage devicetree overlays" "\nUse <space> to toggle functions and save them.\nExit when you are done.\n\n    overlay_prefix=$overlay_prefix\n " 0 0 0 --cancel-button "Back" --ok-button "Save" -- "${options[@]}")
		exit_status=$?
		case $exit_status in
			0)
				changes="true"
				newoverlays=$(echo $selection | sed 's/"//g')
				# handle case where overlay_prefix is part of overlay name
				IFS=' ' read -r -a ovs <<< "$newoverlays"
				newoverlays=""
				# remove prefix, if any
				for ov in "${ovs[@]}"; do
					if [[ -n $overlay_prefix && $ov == "$overlay_prefix"* ]]; then
						ov="${ov#$overlay_prefix}"
					fi
					# remove '-' hyphen from beginning of ov, if any
					ov="${ov#-}"
					newoverlays+="$ov "
				done
				newoverlays="${newoverlays% }"
				# Raspberry Pi
				if [[ "${LINUXFAMILY}" == "bcm2711" ]]; then
					# Remove any existing Armbian config block
					if grep -q '^# Armbian config$' "$overlayconf"; then
						sed -i '/^# Armbian config$/,$d' "$overlayconf"
					fi
					# Append fresh marker and overlays atomically
					{
						echo "# Armbian config"
						while IFS= read -r ov; do
							printf 'dtoverlay=%s\n' "$ov"
						done <<< "$newoverlays"
					} >> "$overlayconf"
				else
					sed -i "s/^overlays=.*/overlays=$newoverlays/" ${overlayconf}
					if ! grep -q "^overlays" ${overlayconf}; then echo "overlays=$newoverlays" >> ${overlayconf}; fi
				fi
				;;
			1)
				if [[ "$changes" == "true" ]]; then
					dialog_yesno "Reboot required" "A reboot is required to apply the changes. Shall we reboot now?" "Reboot" "Cancel" 7 34
					if [[ $? = 0 ]]; then
						reboot
					fi
				fi
				break
				;;
			255)
				;;
		esac
	done
}

module_options+=(
	["module_desktop_packages,author"]="@igorpecovnik"
	["module_desktop_packages,feature"]="module_desktop"
	["module_desktop_packages,desc"]="Generate desktop packages list"
	["module_desktop_packages,de"]="budgie cinnamon deepin enlightenment gnome i3-wm kde-plasma mate xfce xmonad"
	["module_desktop_packages,release"]="bookworm noble plucky"
	["module_desktop_packages,status"]="Active"
	["module_desktop_packages,arch"]="x86-64"
)
#
# Module desktop packages
#
function module_desktop_packages() {
	local title="test"
	local condition=$(which "$title" 2>/dev/null)

	# Convert the example string to an array
	local de
	IFS=' ' read -r -a de <<< "${module_options["module_desktop_packages,de"]}"

	# Common desktop packages
	local packages+=(
			"anacron"
			"cups"
			"eject"
			"printer-driver-all"
			"profile-sync-daemon"
			"system-config-printer"
			"terminator"
			"upower"
			"xarchiver"
		)

	case "$1" in
		"${de[0]}")
			# budgie
		;;
		"${de[1]}")
			# cinnamon
		;;
		"${de[2]}")
			# deepin
		;;
		"${de[3]}")
			# enlightenment
		;;
		"${de[4]}")
			# gnome
			local packages+=(
				"apt-xapian-index"
				"at-spi2-core"
				"colord"
				"dbus-x11"
				"dconf-cli"
				"dmz-cursor-theme"
				"foomatic-db-compressed-ppds"
				"fonts-noto-cjk"
				"fonts-ubuntu"
				"fonts-ubuntu-console"
				"gdebi"
				"gdm3"
				"gnome-control-center"
				"gnome-desktop3-data"
				"gnome-disk-utility"
				"gnome-disk-utility"
				"gnome-keyring"
				"gnome-menus"
				"gnome-packagekit"
				"gnome-screenshot"
				"gnome-session"
				"gnome-shell"
				"gnome-shell-extension-appindicator"
				"gnome-system-monitor"
				"gnome-terminal"
				"gvfs-backends"
				"inputattach"
				"libnotify-bin"
				"lm-sensors"
				"nautilus"
				"nautilus-extension-gnome-terminal"
				"pavucontrol"
				"pulseaudio"
				"pulseaudio-module-bluetooth"
				"software-properties-gtk"
				"synaptic"
				"x11-apps"
				"x11-session-utils"
				"x11-utils"
				"x11-xserver-utils"
				"xdg-user-dirs"
				"xdg-user-dirs-gtk"
				"xfonts-base"
				"xserver-xorg"
				"xwayland"
				"zenity"
			)
		;;
		"${de[5]}")
			# i3-wm
		;;
		"${de[6]}")
			# kde-plasma
		;;
		"${de[7]}")
			# mate
		;;
		"${de[8]}")
			# xfce
			local packages+=(
				"anacron"
				"apt-xapian-index"
				"blueman"
				"bluez"
				"bluez-cups"
				"bluez-tools"
				"brltty"
				"brltty-x11"
				"cifs-utils"
				"colord"
				"cups"
				"cups-bsd"
				"cups-client"
				"cups-filters"
				"dbus-x11"
				"dmz-cursor-theme"
				"evince"
				"evince-common"
				"fontconfig"
				"fontconfig-config"
				"fonts-noto-cjk"
				"fonts-ubuntu"
				"fonts-ubuntu-console"
				"foomatic-db-compressed-ppds"
				"gdebi"
				"ghostscript-x"
				"gnome-disk-utility"
				"gnome-font-viewer"
				"gnome-screenshot"
				"gnome-system-monitor"
				"gstreamer1.0-packagekit"
				"gstreamer1.0-plugins-base-apps"
				"gstreamer1.0-pulseaudio"
				"gtk2-engines"
				"gtk2-engines-murrine"
				"gtk2-engines-pixbuf"
				"gvfs-backends"
				"hplip"
				"ayatana-indicator-printers"
				"inputattach"
				"inxi"
				"keyutils"
				"laptop-detect"
				"libatk-adaptor"
				"libfontconfig1"
				"libfontembed1"
				"libfontenc1"
				"libgail-common"
				"libgl1-mesa-dri"
				"libgsettings-qt1"
				"libgtk2.0-bin"
				"libnotify-bin"
				"libpam-gnome-keyring"
				"libproxy1-plugin-gsettings"
				"libwmf0.2-7-gtk"
				"libxcursor1"
				"lightdm"
				"lm-sensors"
				"lxtask"
				"mesa-utils"
				"mousepad"
				"mousetweaks"
				"numix-gtk-theme"
				"numix-icon-theme"
				"numix-icon-theme-circle"
				"openprinting-ppds"
				"orca"
				"p7zip-full"
				"pamix"
				"pasystray"
				"pavucontrol"
				"pavumeter"
				"policykit-1"
				"printer-driver-all"
				"profile-sync-daemon"
				"pulseaudio"
				"pulseaudio-module-bluetooth"
				"qalculate-gtk"
				"redshift"
				"slick-greeter"
				"smbclient"
				"software-properties-gtk"
				"spice-vdagent"
				"synaptic"
				"system-config-printer"
				"system-config-printer-common"
				"terminator"
				"thunar-volman"
				"update-inetd"
				"update-manager"
				"update-manager-core"
				"viewnior"
				"x11-apps"
				"x11-utils"
				"x11-xserver-utils"
				"xapps-common"
				"xarchiver"
				"xauth"
				"xbacklight"
				"xcursor-themes"
				"xdg-user-dirs"
				"xdg-user-dirs-gtk"
				"xfce4"
				"xfce4-notifyd"
				"xfce4-power-manager"
				"xfce4-screenshooter"
				"xfce4-terminal"
				"xfonts-100dpi"
				"xfonts-75dpi"
				"xfonts-base"
				"xfonts-encodings"
				"xfonts-scalable"
				"xfonts-utils"
				"xorg-docs-core"
				"xscreensaver"
				"xsensors"
				"xserver-xorg"
				"xserver-xorg-video-fbdev"
				"xwallpaper"
			)
			local architecture+=(
				"arm64"
				"amd64"
				"armhf"
				"riscv64"
			)
			local supported=(
				"supported"
			)
			local packages_uninstall=()
			local packages_remove=()
		;;
		"${de[9]}")
			# xmonad
		;;
	esac

	local release
	IFS=' ' read -r -a release <<< "${module_options["module_desktop_packages,release"]}"
	case "$2" in
		"${release[0]}")
			# bookworm
			local packages+=(
				"accountsservice"
				"gnome-calculator"
				"libu2f-udev"
			)
			local packages_remove+=(
				"libfontembed1"
				"update-manager"
				"update-manager-core"
			)
		;;
		"${release[1]}")
			# noble
			local packages+=(
				"polkitd"
				"pkexec"
				"libu2f-udev"
			)
			local packages_remove+=(
				"qalculate-gtk"
				"hplip"
				"indicator-printers"
				"libfontembed1"
				"policykit-1"
				"printer-driver-all"
				"qalculate-gtk"
			)
			local packages_uninstall+=(
				"ubuntu-session"
			)
		;;
		"${release[2]}")
			# plucky
			local packages+=(
				"polkitd"
				"pkexec"
				"libu2f-udev"
			)
			local packages_remove+=(
				"qalculate-gtk"
				"hplip"
				"indicator-printers"
				"libfontembed1"
				"policykit-1"
				"printer-driver-all"
				"qalculate-gtk"
				"libfontembed1"
				"pavumeter"
			)
			local packages_uninstall+=(
				"ubuntu-session"
			)
		;;
	esac

	# Remove packages_remove from packages
	filtered_packages=()
	for p in "${packages[@]}"; do
		# Check if $p is in packages_remove
		if [[ ! " ${packages_remove[@]} " =~ " $p " ]]; then
			filtered_packages+=("$p")
		fi
	done
	packages=("${filtered_packages[@]}")

	PACKAGES=${packages[@]}
	PACKAGES_UNINSTALL=${packages_uninstall[@]}
	SUPPORTED=${supported}
	ARCHITECTURE=${architecture}

}

declare -A module_options
module_options+=(
	["module_armbian_upgrades,author"]="@igorpecovnik"
	["module_armbian_upgrades,feature"]="module_armbian_upgrades"
	["module_armbian_upgrades,desc"]="Install and configure automatic updates"
	["module_armbian_upgrades,example"]="install remove configure status defaults help"
	["module_armbian_upgrades,port"]=""
	["module_armbian_upgrades,status"]="Active"
	["module_armbian_upgrades,arch"]=""
)
#
# Module configure automatic updates
#
function module_armbian_upgrades () {

	local title="package updates"
	local condition=$(which "$title" 2>/dev/null)

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_armbian_upgrades,example"]}"

	case "$1" in

		"${commands[0]}")
			pkg_update
			pkg_install -o Dpkg::Options::="--force-confold" unattended-upgrades
			# set Armbian defaults
			${module_options["module_armbian_upgrades,feature"]} ${commands[4]}
		;;
		"${commands[1]}")
			pkg_remove unattended-upgrades
		;;
		"${commands[2]}")
			# read values from 20auto-upgrades
			if [[ -f "/etc/apt/apt.conf.d/20auto-upgrades" ]]; then
				Unattended_Upgrade=$(
					awk -F'"' '/APT::Periodic::Unattended-Upgrade/ {print ($2 == 1) ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/20auto-upgrades
					)
				Update_Package_Lists=$(
					awk -F'"' '/APT::Periodic::Update-Package-Lists/ {print ($2 == 1) ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/20auto-upgrades
					)
				Download_Upgradeable_Packages=$(
					awk -F'"' '/APT::Periodic::Download-Upgradeable-Packages/ {print ($2 == 1) ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/20auto-upgrades
					)
			fi
			# read values from 50unattended-upgrades
			if [[ -f "/etc/apt/apt.conf.d/50unattended-upgrades" ]]; then
				AutoFixInterruptedDpkg=$(
					awk -F'"' '/Unattended-Upgrade::AutoFixInterruptedDpkg/ {print ($2 == "true") ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/50unattended-upgrades
					)
				Remove_New_Unused_Dependencies=$(
					awk -F'"' '/Unattended-Upgrade::Remove-New-Unused-Dependencies/ {print ($2 == "true") ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/50unattended-upgrades
					)
				Automatic_Reboot=$(
					awk -F'"' '/Unattended-Upgrade::Automatic-Reboot "/ {print ($2 == "true") ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/50unattended-upgrades
					)
				Automatic_Reboot_WithUsers=$(
					awk -F'"' '/Unattended-Upgrade::Automatic-Reboot-WithUsers/ {print ($2 == "true") ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/50unattended-upgrades
					)
				Remove_Unused_Dependencies=$(
					awk -F'"' '/Unattended-Upgrade::Remove-Unused-Dependencies/ {print ($2 == "true") ? "ON" : "OFF"}' \
					/etc/apt/apt.conf.d/50unattended-upgrades
					)
			fi
			# toggle options
			if target_sync=$(dialog_checklist "Select an Option" \
				"\nConfigure unattended-upgrade options:" 16 73 8 --notags \
				"Unattended-Upgrade" "Automatic security and package updates system." ${Unattended_Upgrade:-ON} \
				"Update-Package-Lists" "Automatically updates the list of available packages." ${Update_Package_Lists:-OFF} \
				"Download-Upgradeable-Packages" "Downloads upgradeable packages without installing them." ${Download_Upgradeable_Packages:-OFF} \
				"AutoFixInterruptedDpkg" "Fixes interrupted package installations during upgrades." ${AutoFixInterruptedDpkg:-OFF} \
				"Remove-New-Unused-Dependencies" "Removes dependencies no longer required after upgrades." ${Remove_New_Unused_Dependencies:-OFF} \
				"Automatic-Reboot" "Reboots the system automatically if required after upgrades.    " ${Automatic_Reboot:-OFF} \
				"Automatic-Reboot-WithUsers" "Reboots even if users are logged in." ${Automatic_Reboot_WithUsers:-OFF} \
				"Remove-Unused-Dependencies" "Removes packages that are no longer required after upgrades." ${Remove_Unused_Dependencies:-OFF}); then
				# set all to 0 or false
				sed -i 's/"[0-9]"/"0"/g' /etc/apt/apt.conf.d/20auto-upgrades
				sed -i 's/"true"/"false"/g' /etc/apt/apt.conf.d/50unattended-upgrades
				for choice in $(echo ${target_sync} | tr -d '"'); do
					sed -i "s/\($choice \"\)0\(\";\)/\11\2/" /etc/apt/apt.conf.d/20auto-upgrades
					sed -i "s/\($choice \"\)false\(\";\)/\1true\2/" /etc/apt/apt.conf.d/50unattended-upgrades
				done
			fi
			srv_restart unattended-upgrades
		;;
		"${commands[3]}")
			if pkg_installed unattended-upgrades; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[4]}")

			# global options
			cat > "/etc/apt/apt.conf.d/20auto-upgrades" <<- EOT
			APT::Periodic::Update-Package-Lists "1";
			APT::Periodic::Download-Upgradeable-Packages "1";
			APT::Periodic::AutocleanInterval "7";
			APT::Periodic::Unattended-Upgrade "1";
			EOT

			# unattended-upgrades
			cat > "/etc/apt/apt.conf.d/50unattended-upgrades" <<- EOT
			// armbian-config generated
			Unattended-Upgrade::Origins-Pattern {
				"o=${DISTRO},n=${DISTROID},l=${DISTRO}";
				"o=${DISTRO},n=${DISTROID}-updates,l=${DISTRO}";
				"o=${DISTRO},n=${DISTROID}-security,l=${DISTRO}-Security";
				"o=armbian.github.io/configurator,c=main,l=armbian.github.io/configurator";
			};
			// black list
			// Unattended-Upgrade::Package-Blacklist {
			//    "armbian-";
			//    "linux-";
			//};

			// This option allows you to control if on a unclean dpkg exit
			// unattended-upgrades will automatically run
			//   dpkg --force-confold --configure -a
			// The default is true, to ensure updates keep getting installed
			Unattended-Upgrade::AutoFixInterruptedDpkg "true";

			// Do automatic removal of newly unused dependencies after the upgrade
			Unattended-Upgrade::Remove-New-Unused-Dependencies "true";

			// Do automatic removal of unused packages after the upgrade
			// (equivalent to apt-get autoremove)
			Unattended-Upgrade::Remove-Unused-Dependencies "true";

			// Automatically reboot *WITHOUT CONFIRMATION* if
			//  the file /var/run/reboot-required is found after the upgrade
			Unattended-Upgrade::Automatic-Reboot "true";

			// Automatically reboot even if there are users currently logged in
			// when Unattended-Upgrade::Automatic-Reboot is set to true
			Unattended-Upgrade::Automatic-Reboot-WithUsers "true";
			EOT

		;;
		"${commands[5]}")
			echo -e "\nUsage: ${module_options["module_armbian_upgrades,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_armbian_upgrades,example"]}"
			echo -e "Available commands:\n"
			echo -e "\tinstall\t\t- Install Armbian $title."
			echo -e "\tremove\t\t- Remove Armbian $title."
			echo -e "\tconfigure\t- Configure Armbian $title."
			echo -e "\tstatus\t\t- Status of Armbian $title."
			echo -e "\tdefaults\t- Set to Armbian defalt $title config."
			echo
		;;
		*)
			${module_options["module_armbian_upgrades,feature"]} ${commands[5]}
		;;
	esac
}


module_options+=(
["store_netplan_config,author"]="@igorpecovnik"
["store_netplan_config,ref_link"]=""
["store_netplan_config,feature"]="Storing netplan config to tmp"
["store_netplan_config,desc"]=""
["store_netplan_config,example"]=""
["store_netplan_config,status"]="Active"
)
#
# @description Restoring Netplan configuration from temp folder
#
function restore_netplan_config() {

	echo "Restoring NetPlan configs" | show_infobox
	# just in case
	if [[ -n ${restore_netplan_config_folder} ]]; then
		rm -f /etc/netplan/*
		rsync -ar ${restore_netplan_config_folder}/. /etc/netplan
	fi

}



module_options+=(
	["release_upgrade,author"]="@igorpecovnik"
	["release_upgrade,ref_link"]=""
	["release_upgrade,feature"]="Upgrade upstream distribution release"
	["release_upgrade,desc"]="Upgrade to next stable or rolling release"
	["release_upgrade,example"]="release_upgrade stable verify"
	["release_upgrade,status"]="Active"
)
#
# Upgrade distribution
#
release_upgrade(){

	local upgrade_type=$1
	local verify=$2

	local distroid=${DISTROID}

	if [[ "${upgrade_type}" == stable ]]; then
		local filter=$(grep "supported" /etc/armbian-distribution-status | cut -d"=" -f1 | grep -v "^${distroid}")
	elif [[ "${upgrade_type}" == rolling ]]; then
		local filter=$(grep "eos\|csc" /etc/armbian-distribution-status | cut -d"=" -f1 | sed "s/sid/testing/g" | grep -v "^${distroid}")
	else
		local filter=$(cat /etc/armbian-distribution-status | cut -d"=" -f1 | grep -v "^${distroid}")
	fi

	local upgrade=$(for j in $filter; do
		for i in $(grep "^${distroid}" /etc/armbian-distribution-status | cut -d";" -f2 | cut -d"=" -f2 | sed "s/,/ /g"); do
			if [[ $i == $j ]]; then
				echo $i
			fi
		done
	done | tail -1)

	if [[ -z "${upgrade}" ]]; then
		return 1;
	elif [[ -z "${verify}" ]]; then
		[[ -f /etc/apt/sources.list.d/ubuntu.sources ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/ubuntu.sources
		[[ -f /etc/apt/sources.list.d/debian.sources ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/debian.sources
		[[ -f /etc/apt/sources.list ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list
		[[ "${upgrade}" == "testing" ]] && upgrade="sid" # our repo and everything is tied to sid
		[[ -f /etc/apt/sources.list.d/armbian.sources ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/armbian.sources
		[[ -f /etc/apt/sources.list.d/armbian.list ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/armbian.list
		pkg_update
		pkg_upgrade -o Dpkg::Options::="--force-confold" --without-new-pkgs
		pkg_fix || return 1 # Hacks for Ubuntu
		pkg_full_upgrade -o Dpkg::Options::="--force-confold"
		pkg_fix || return 1 # Hacks for Ubuntu
		pkg_full_upgrade -o Dpkg::Options::="--force-confold"
		pkg_fix || return 1 # Hacks for Ubuntu
		pkg_remove # remove all auto-installed packages
	fi
}

module_options+=(
	["module_desktop,author"]="@igorpecovnik"
	["module_desktop,feature"]="module_desktop"
	["module_desktop,desc"]="XFCE desktop packages"
	["module_desktop,example"]="install remove disable enable status auto manual login help"
	["module_desktop,status"]="Active"
	["module_desktop,arch"]="x86-64"
)
#
# Module install and configure desktop
#
function module_desktop() {
	local title="test"
	local condition=$(which "$title" 2>/dev/null)

	# get user who executed this script
	if [ $SUDO_USER ]; then local user=$SUDO_USER; else local user=$(whoami); fi

	# read additional parameters from command line
	local parameter
	IFS=' ' read -r -a parameter <<< "${2}"
	for feature in de; do
	for selected in ${parameter[@]}; do
		IFS='=' read -r -a split <<< "${selected}"
		[[ ${split[0]} == $feature ]] && eval "$feature=${split[1]}"
		done
	done

	local de="${de:-xfce}" # DE

	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_desktop,example"]}"

	# generate and install packages
	module_desktop_packages "$de" "$DISTROID"

	case "$1" in
		"${commands[0]}")

			# update package list
			pkg_update

			# desktops has different default login managers
			case "$de" in
				gnome)
					echo "/usr/sbin/gdm3" > /etc/X11/default-display-manager
					pkg_install -o Dpkg::Options::="--force-confold" ${PACKAGES}
					pkg_install -o Dpkg::Options::="--force-confold" ${PACKAGES_UNINSTALL}
					pkg_install -o Dpkg::Options::="--force-confold" gdm3
				;;
				kde-neon)
					echo "/usr/sbin/sddm" > /etc/X11/default-display-manager
					pkg_install -o Dpkg::Options::="--force-confold" ${PACKAGES}
					pkg_install -o Dpkg::Options::="--force-confold" ${PACKAGES_UNINSTALL}
					pkg_install -o Dpkg::Options::="--force-confold" kde-standard
				;;
				*)
					echo "/usr/sbin/lightdm" > /etc/X11/default-display-manager
					pkg_install -o Dpkg::Options::="--force-confold" ${PACKAGES}
					pkg_install -o Dpkg::Options::="--force-confold" ${PACKAGES_UNINSTALL}
					pkg_install -o Dpkg::Options::="--force-confold" lightdm
				;;
			esac

			# install desktop
			pkg_install -o Dpkg::Options::="--force-confold" armbian-${DISTROID}-desktop-${de}

			# add user to groups
			for additionalgroup in sudo netdev audio video dialout plugdev input bluetooth systemd-journal ssh; do
				usermod -aG ${additionalgroup} ${user} 2> /dev/null
			done
			# set up profile sync daemon on desktop systems
			which psd > /dev/null 2>&1
			if [[ $? -eq 0 && -z $(grep overlay-helper /etc/sudoers) ]]; then
				echo "${user} ALL=(ALL) NOPASSWD: /usr/bin/psd-overlay-helper" >> /etc/sudoers
				touch /home/${user}/.activate_psd
			fi
			# update skel
			update_skel

			# stop display managers in case we are switching them
			if srv_active gdm3; then
				srv_stop gdm3
			elif srv_active lightdm; then
				srv_stop lightdm
			elif srv_active sddm; then
				srv_stop sddm
			fi

			# start new default display manager
			srv_restart display-manager

			# enable auto login
			${module_options["module_desktop,feature"]} ${commands[5]}
		;;

		"${commands[1]}")
			# disable auto login
			${module_options["module_desktop,feature"]} ${commands[6]}
			# remove destkop
			srv_stop display-manager
			pkg_remove ${PACKAGES}
			pkg_remove armbian-${DISTROID}-desktop-${de}
		;;
		"${commands[2]}")
			# disable
			srv_stop display-manager
			srv_disable display-manager
		;;
		"${commands[3]}")
			# enable
			srv_enable display-manager
			srv_start display-manager
		;;
		"${commands[4]}")
			# status
			case "$de" in
				gnome)
					if srv_active gdm3; then
						return 0
					else
						return 1
					fi
				;;
				kde-neon)
					if srv_active sddm; then
						return 0
					else
						return 1
					fi
				;;
				*)
					if srv_active lightdm; then
						return 0
					else
						return 1
					fi
				;;
			esac
		;;
		"${commands[5]}")
			# autologin methods
			case "$de" in
				gnome)
					# gdm3 autologin
					mkdir -p /etc/gdm3
					cat <<- EOF > /etc/gdm3/custom.conf
					[daemon]
					AutomaticLoginEnable = true
					AutomaticLogin = ${user}
					EOF
				;;
				kde-neon)
					# sddm autologin
					mkdir -p "/etc/sddm.conf.d/"
					cat <<- EOF > "/etc/sddm.conf.d/autologin.conf"
					[Autologin]
					User=${user}
					EOF
				;;
				*)
					# lightdm autologin
					mkdir -p /etc/lightdm/lightdm.conf.d
					cat <<- EOF > "/etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf"
					[Seat:*]
					autologin-user=${user}
					autologin-user-timeout=0
					user-session=xfce
					EOF

				;;
			esac
			# restart after selection
			srv_restart display-manager
		;;
		"${commands[6]}")
			# manual login, disable auto-login
			case "$de" in
				gnome)    rm -f /etc/gdm3/custom.conf ;;
				kde-neon) rm -f /etc/sddm.conf.d/autologin.conf ;;
				*)        rm -f /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf ;;
			esac
			# restart after selection
			srv_restart display-manager
		;;
		"${commands[7]}")
			# status
			if [[ -f /etc/gdm3/custom.conf ]] || [[ -f /etc/sddm.conf.d/autologin.conf ]] || [[ -f /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[8]}")
			echo -e "\nUsage: ${module_options["module_desktop,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_desktop,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Generate packages for $title."
			echo -e "\tremove\t-  Generate packages for $title."
			echo -e "\tdisable\t- Generate packages for $title."
			echo -e "\tenable\t-  Generate packages for $title."
			echo -e "\tstatus\t-  Generate packages for $title."

			echo -e "\nAvailable switches:\n"
			echo -e "\tkvmprefix\t- Name prefix (default = kvmtest)"
			echo
		;;
		*)
			${module_options["module_desktop,feature"]} ${commands[8]}
		;;
	esac
}

module_options+=(
	["manage_zsh,author"]="@igorpecovnik"
	["manage_zsh,ref_link"]=""
	["manage_zsh,feature"]="manage_zsh"
	["manage_zsh,desc"]="Set system shell to BASH"
	["manage_zsh,example"]="manage_zsh enable|disable"
	["manage_zsh,status"]="Active"
)
#
# @description Set system shell to ZSH
#
function manage_zsh() {

	local bash_location=$(grep /bash$ /etc/shells | tail -1)
	local zsh_location=$(grep /zsh$ /etc/shells | tail -1)

	if [[ "$1" == "enable" ]]; then

		pkg_update

		# install zsh before changing any shells — if install fails, abort
		# to avoid setting an invalid shell that locks all users out via pam_shells
		if ! pkg_install armbian-zsh zsh-common zsh tmux; then
			echo "Failed to install zsh packages; shell not changed"
			return 1
		fi

		sed -i "s|^SHELL=.*|SHELL=/bin/zsh|" /etc/default/useradd
		sed -i -E "s|(^\|#)DSHELL=.*|DSHELL=/bin/zsh|" /etc/adduser.conf

		update_skel

		# change shell for root
		usermod --shell "/bin/zsh" root
		# change shell for others
		sed -i 's/bash$/zsh/g' /etc/passwd

	else

		sed -i "s|^SHELL=.*|SHELL=/bin/bash|" /etc/default/useradd
		sed -i -E "s|(^\|#)DSHELL=.*|DSHELL=/bin/bash|" /etc/adduser.conf

		# remove
		pkg_remove armbian-zsh zsh-common zsh tmux

		# change shell for root
		usermod --shell "/bin/bash" root
		# change shell for others
		sed -i 's/zsh$/bash/g' /etc/passwd

	fi

}

# This module is used only for generating documentation. Where we use command from the menu directly, there is no module behind.
# We assume that when calling command directly, its multiarch
module_options+=(
	["module_generic,author"]="@armbian"
	["module_generic,maintainer"]="@armbian"
	["module_generic,status"]="Active"
	["module_generic,doc_link"]="https://forum.armbian.com/"
	["module_generic,arch"]="x86-64 aarch64 armhf riscv64"
)

module_options+=(
	["module_openssh-server,author"]="@armbian"
	["module_openssh-server,maintainer"]="@igorpecovnik"
	["module_openssh-server,feature"]="module_openssh-server"
	["module_openssh-server,example"]="install remove purge status help"
	["module_openssh-server,desc"]="Install openssh-server container"
	["module_openssh-server,status"]="Active"
	["module_openssh-server,doc_link"]="https://docs.linuxserver.io/images/docker-openssh-server/#server-mode"
	["module_openssh-server,group"]="Network"
	["module_openssh-server,port"]="2222"
	["module_openssh-server,arch"]="x86-64 arm64"
)
#
# Module openssh-server
#
function module_openssh-server () {
	local title="openssh-server"
	local condition=$(which "$title" 2>/dev/null)

	# Ensure Docker is available for commands that need it (install, remove, purge)
	if [[ "$1" != "status" && "$1" != "help" ]]; then
		if ! module_docker status >/dev/null 2>&1; then
			module_docker install
		fi
	fi

	local container=$(docker container ls -a --filter "name=openssh-server" --format '{{.ID}}' 2>/dev/null) || echo ""
	local image=$(docker image ls -a --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep 'lscr.io/linuxserver/openssh-server:' | head -1) || echo ""

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_openssh-server,example"]}"

	OPENSSHSERVER_BASE="${SOFTWARE_FOLDER}/openssh-server"

	case "$1" in
		"${commands[0]}")
			[[ -d "${OPENSSHSERVER_BASE}" ]] || mkdir -p "${OPENSSHSERVER_BASE}" || { echo "Couldn't create storage directory: ${OPENSSHSERVER_BASE}"; return 1; }
			USER_NAME=$(dialog_inputbox "Enter username" "\nHit enter for defaults" "upload")
			PUBLIC_KEY=$(dialog_inputbox "Enter public key" "" "" 9 50)
			MOUNT_POINT=$(dialog_inputbox "Enter shared folder path" "" "${SOFTWARE_FOLDER}/swag/config/www")
			docker run -d \
			--name=openssh-server \
			--net=lsio \
			--hostname=openssh-server `#optional` \
			-e PUID=1000 \
			-e PGID=1000 \
			-e TZ="$(cat /etc/timezone)" \
			-e PUBLIC_KEY="${PUBLIC_KEY}"  \
			-e SUDO_ACCESS=false \
			-e PASSWORD_ACCESS=false  \
			-e USER_PASSWORD=password \
			-e USER_NAME="${USER_NAME}" \
			-p 2222:2222 \
			-v "${OPENSSHSERVER_BASE}/config:/config" \
			-v "${MOUNT_POINT}:/config/storage" \
			--restart unless-stopped \
			lscr.io/linuxserver/openssh-server:latest
			wait_for_container_ready "openssh-server" 20 3 "running" || return 1
			# read container version
			container_version=$(docker exec openssh-server /bin/bash -c "grep ^PRETTY_NAME= /etc/os-release | sed -E 's/PRETTY_NAME=\"([^\"]*) v[0-9].*/\\1/'")
			# install rsync
			docker exec openssh-server /bin/bash -c "
			apk update; apk add rsync;
			echo '' > /etc/motd;
			echo \"Welcome to your sandboxed Armbian SSH environment running $container_version\" >> /etc/motd;
			echo '' >> /etc/motd;
			"
		;;
		"${commands[1]}")
			if [[ "${container}" ]]; then
				echo "Removing container: $container"
				docker container rm -f "$container" >/dev/null
			fi
		;;
		"${commands[2]}")
			${module_options["module_openssh-server,feature"]} ${commands[1]}
			if [[ "${image}" ]]; then
				sleep 2
				docker image rm -f "$image" 2>/dev/null || true
			fi
			if [[ -n "${OPENSSHSERVER_BASE}" && "${OPENSSHSERVER_BASE}" != "/" ]]; then
				rm -rf "${OPENSSHSERVER_BASE}"
			fi
		;;
		"${commands[3]}")
			if [[ "${container}" && "${image}" ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[4]}")
			echo -e "\nUsage: ${module_options["module_openssh-server,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_openssh-server,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tpurge\t- Purge $title."
			echo
		;;
		*)
			${module_options["module_openssh-server,feature"]} ${commands[4]}
		;;
	esac
}

module_options+=(
	["module_armbian_runners,author"]="@igorpecovnik"
	["module_armbian_runners,feature"]="module_armbian_runners"
	["module_armbian_runners,desc"]="Manage self hosted runners"
	["module_armbian_runners,example"]="install remove remove_online purge status help"
	["module_armbian_runners,port"]=""
	["module_armbian_runners,status"]="Active"
	["module_armbian_runners,arch"]=""
)

#
# Module Armbian self hosted Github runners
#
function module_armbian_runners () {

	local title="runners"
	local condition=$(which "$title" 2>/dev/null)

	# read parameters from command install
	local parameter
	for var in "$@"; do
		IFS=' ' read -r -a parameter <<< "${var}"
		for feature in gh_token runner_name start stop label_primary label_secondary organisation owner repository; do
			for selected in ${parameter[@]}; do
				IFS='=' read -r -a split <<< "${selected}"
				[[ ${split[0]} == $feature ]] && eval "$feature=${split[1]}"
			done
		done
	done

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_armbian_runners,example"]}"

	case "$1" in

		"${commands[0]}")

			# Prompt using dialog if parameters are missing AND in interactive mode
			if [[ -t 1 ]]; then
				if [[ -z "$gh_token" ]]; then
					gh_token=$(dialog_inputbox "" "Enter your GitHub token:" "" 8 60)
				fi

				if [[ -z "$runner_name" ]]; then
					runner_name=$(dialog_inputbox "" "Enter runner name:" "armbian" 8 60)
				fi

				if [[ -z "$start" ]]; then
					start=$(dialog_inputbox "" "Enter start index:" "01" 8 60)
				fi

				if [[ -z "$stop" ]]; then
					stop=$(dialog_inputbox "" "Enter stop index:" "01" 8 60)
				fi

				if [[ -z "$label_primary" ]]; then
					label_primary=$(dialog_inputbox "" "Enter primary label(s):" "alfa" 8 60)
				fi

				if [[ -z "$label_secondary" ]]; then
					label_secondary=$(dialog_inputbox "" "Enter secondary label(s):" "fast,images" 8 60)
				fi

				if [[ -z "$organisation" ]]; then
					organisation=$(dialog_inputbox "" "Enter GitHub organisation:" "armbian" 8 60)
				fi
			fi

			if [[ -z $gh_token ]]; then
				echo "Error: Github token is mandatory"
				${module_options["module_armbian_runners,feature"]} ${commands[6]}
				exit 1
			fi

			# default values if not defined
			local gh_token="${gh_token}"
			local runner_name="${runner_name:-armbian}"
			local start="${start:-01}"
			local stop="${stop:-01}"
			local label_primary="${label_primary:-alfa}"
			local label_secondary="${label_secondary:-fast,images}"
			local organisation="${organisation:-armbian}"
			local owner="${owner}"
			local repository="${repository}"

			# workaround. Remove when parameters handling is fixed
			local label_primary=$(echo $label_primary | sed "s/_/,/g") # convert
			local label_secondary=$(echo $label_secondary | sed "s/_/,/g") # convert

			# we can generate per org or per repo
			local registration_url="${organisation}"
			local prefix="orgs"
			if [[ -n "${owner}" && -n "${repository}" ]]; then
				registration_url="${owner}/${repository}"
				prefix=repos
			fi

			# Docker preinstall is needed for our build framework
			pkg_installed docker-ce || module_docker install
			pkg_update
			pkg_install jq curl libicu-dev mktorrent rsync

			# download latest runner package
			local temp_dir=$(mktemp -d)
			trap '{ rm -rf -- "$temp_dir"; }' EXIT
			[[ "$ARCH" == "x86_64" ]] && local arch=x64 || local arch=arm64
			local LATEST=$(curl -sL https://api.github.com/repos/actions/runner/tags | jq -r '.[0].zipball_url' | rev | cut -d"/" -f1 | rev | sed "s/v//g")
			curl --progress-bar --create-dir --output-dir ${temp_dir} -o \
			actions-runner-linux-${ARCH}-${LATEST}.tar.gz -L \
			https://github.com/actions/runner/releases/download/v${LATEST}/actions-runner-linux-${arch}-${LATEST}.tar.gz

			# make runners each under its own user
			for i in $(seq -w $start $stop)
			do
				local token=$(curl -s \
				-X POST \
				-H "Accept: application/vnd.github+json" \
				-H "Authorization: Bearer ${gh_token}"\
				-H "X-GitHub-Api-Version: 2022-11-28" \
				https://api.github.com/${prefix}/${registration_url}/actions/runners/registration-token | jq -r .token)

				${module_options["module_armbian_runners,feature"]} ${commands[1]} ${runner_name} "${i}"

				adduser --quiet --disabled-password --shell /bin/bash \
				--home /home/actions-runner-${i} --gecos "actions-runner-${i}" actions-runner-${i}

				# add to sudoers
				if ! sudo grep -q "actions-runner-${i}" /etc/sudoers; then
					echo "actions-runner-${i} ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers
				fi
				usermod -aG docker actions-runner-${i}
				tar xzf ${temp_dir}/actions-runner-linux-${ARCH}-${LATEST}.tar.gz -C /home/actions-runner-${i}
				chown -R actions-runner-${i}:actions-runner-${i} /home/actions-runner-${i}

				# 1st runner has different labels
				local label=$label_secondary
				if [[ "$i" == "${start}" ]]; then
					local label=$label_primary
				fi

				runuser -l actions-runner-${i} -c \
				"./config.sh --url https://github.com/${registration_url} \
				--token ${token} --labels ${label} --name ${runner_name}-${i} --unattended"
				if [[ -f /home/actions-runner-${i}/svc.sh ]]; then
					sh -c "cd /home/actions-runner-${i} ; \
					sudo ./svc.sh install actions-runner-${i} 2>/dev/null; \
					sudo ./svc.sh start actions-runner-${i} >/dev/null"
				fi
			done

		;;
		"${commands[1]}")
			# delete if previous already exists
			echo "Removing runner $3 on GitHub"
			${module_options["module_armbian_runners,feature"]} ${commands[2]} "$2-$3"
			echo "Removing runner $3 locally"
			runner_home=$(getent passwd "actions-runner-${3}" | cut -d: -f6)
			if [[ -f "${runner_home}/svc.sh" ]]; then
				sh -c "cd ${runner_home} ; sudo ./svc.sh stop actions-runner-$3 >/dev/null; sudo ./svc.sh uninstall actions-runner-$3 >/dev/null"
			fi
			userdel -r -f actions-runner-$3 2>/dev/null
			groupdel actions-runner-$3 2>/dev/null
			sed -i "/^actions-runner-$3.*/d" /etc/sudoers
			[[ ${runner_home} != "/" ]] && rm -rf "${runner_home}"
		;;
		"${commands[2]}")
			DELETE=$2
			x=1
			while [ $x -le 9 ] # need to do it different as it can be more then 9 pages
			do
			RUNNER=$(
			curl -s -L \
			-H "Accept: application/vnd.github+json" \
			-H "Authorization: Bearer ${gh_token}" \
			-H "X-GitHub-Api-Version: 2022-11-28" \
			https://api.github.com/${prefix}/${registration_url}/actions/runners\?page\=${x} \
			| jq -r '.runners[] | .id, .name' | xargs -n2 -d'\n' | sed -e 's/ /,/g')

			while IFS= read -r DATA; do
				RUNNER_ID=$(echo $DATA | cut -d"," -f1)
				RUNNER_NAME=$(echo $DATA | cut -d"," -f2)
				# deleting a runner
				if [[ $RUNNER_NAME == ${DELETE} ]]; then
					echo "Delete existing: $RUNNER_NAME"
					curl -s -L \
					-X DELETE \
					-H "Accept: application/vnd.github+json" \
					-H "Authorization: Bearer ${gh_token}"\
					-H "X-GitHub-Api-Version: 2022-11-28" \
					https://api.github.com/${prefix}/${registration_url}/actions/runners/${RUNNER_ID}
				fi
			done <<< $RUNNER
			x=$(( $x + 1 ))
			done
		;;
		"${commands[3]}")
			if [[ -z $gh_token ]]; then
				echo "Error: Github token is mandatory"
				${module_options["module_armbian_runners,feature"]} ${commands[6]}
				exit 1
			fi
			for i in $(seq -w $start $stop); do
				${module_options["module_armbian_runners,feature"]} ${commands[1]} ${runner_name}
			done
		;;
		"${commands[4]}")
			if [[ $(systemctl list-units --type=service 2>/dev/null | grep actions.runner) -gt 0 ]]; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[6]}")
			echo -e "\nUsage: ${module_options["module_armbian_runners,feature"]} <command> [switches]"
			echo -e "Commands:  install purge"
			echo -e "Available commands:\n"
			echo -e "\tinstall\t\t- Install or reinstall $title."
			echo -e "\tpurge\t\t- Purge $title."
			echo -e "\tstatus\t\t- Status of $title."
			echo -e "\nAvailable switches:\n"
			echo -e "\tgh_token\t- token with rights to admin runners."
			echo -e "\trunner_name\t- name of the runner (series)."
			echo -e "\tstart\t\t- start of serie (01)."
			echo -e "\tstop\t\t- stop (01)."
			echo -e "\tlabel_primary\t- runner tags for first runner (alfa)."
			echo -e "\tlabel_secondary\t- runner tags for all others (images)."
			echo -e "\torganisation\t- GitHub organisation name (armbian)."
			echo -e "\towner\t\t- GitHub owner."
			echo -e "\trepository\t- GitHub repository (if adding only for repo)."
			echo ""
		;;
		*)
			${module_options["module_armbian_runners,feature"]} ${commands[6]}
		;;
	esac
}

module_options+=(
	["module_overlayfs,author"]="@igorpecovnik"
	["module_overlayfs,maintainer"]="@igorpecovnik"
	["module_overlayfs,feature"]="module_overlayfs"
	["module_overlayfs,example"]="install remove status help"
	["module_overlayfs,desc"]="Set Armbian root filesystem to read only"
	["module_overlayfs,status"]="Active"
	["module_overlayfs,doc_link"]="https://docs.kernel.org/filesystems/overlayfs.html"
	["module_overlayfs,group"]="System"
	["module_overlayfs,port"]=""
	["module_overlayfs,arch"]=""
)
#
# Install overlayroot for read-only root filesystem
#
function module_overlayfs() {
	local title="overlayfs"
	local condition=$(which "$title" 2>/dev/null)

	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_overlayfs,example"]}"

	OVERLAYFS_BASE="${SOFTWARE_FOLDER}/overlayfs"

	case "$1" in
		"${commands[0]}")
			pkg_install --reinstall -o Dpkg::Options::="--force-confold" overlayroot
			cat > /etc/overlayroot.conf <<-EOT
			# overlayroot config - managed by configng
			overlayroot_cfgdisk="disabled"
			overlayroot="tmpfs"
			EOT
			rm -f /etc/update-motd.d/97-overlayroot

			if dialog_yesno " Reboot required " "A reboot is required to apply the changes. Shall we reboot now?" "Reboot" "Cancel" 7 34; then
			reboot
			fi
		;;
		"${commands[1]}")
			overlayroot-chroot rm /etc/overlayroot.conf > /dev/null 2>&1
			if dialog_yesno " Reboot required " "A reboot is required to apply the changes. Shall we reboot now?" "Reboot" "Cancel" 7 34; then
			reboot
			fi
		;;
		"${commands[2]}")
			overlayroot-chroot true > /dev/null 2>&1
			case $? in
				0) return 0 ;;
				*) return 1 ;;
			esac
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_overlayfs,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_overlayfs,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tstatus\t- Status $title."
			echo
		;;
		*)
			${module_options["module_overlayfs,feature"]} ${commands[3]}
		;;
	esac
}


module_options+=(
	["update_skel,author"]="@igorpecovnik"
	["update_skel,ref_link"]=""
	["update_skel,feature"]="update_skel"
	["update_skel,desc"]="Update the /etc/skel files in users directories"
	["update_skel,example"]="update_skel"
	["update_skel,status"]="Active"
)
#
# check dpkg status of $1 -- currently only 'not installed at all' case caught
#
function update_skel() {

	getent passwd |
		while IFS=: read -r username x uid gid gecos home shell; do
			if [ ! -d "$home" ] || [ "$username" == 'root' ] || [ "$uid" -lt 1000 ]; then
				continue
			fi
			tar -C /etc/skel/ -cf - . | su - "$username" -c "tar --skip-old-files -xf -"
		done

}


# ==============================================================================
# Armbian Firmware Module
# ==============================================================================
#
# This module manages Armbian kernel and firmware packages, providing critical
# system functionality for switching between different kernel versions and branches.
#
# WARNING: This is a critical system module. Kernel management can render a
# system unbootable if misused. Always test on non-production systems first.
#
# Architecture Support:
#   x86-64     - Intel/AMD 64-bit systems
#   arm64      - ARM 64-bit systems (most SBCs)
#   armhf      - ARM 32-bit systems (hard float)
#   riscv64    - RISC-V 64-bit systems
#
# Commands:
#   select     - Interactive TUI for selecting and installing kernels
#   install    - Direct installation of specific kernel version
#   show       - Display available packages without installing
#   hold       - Prevent kernel packages from automatic upgrades
#   unhold     - Release held packages, allowing upgrades
#   repository - Switch between stable and rolling beta repositories
#   help       - Display usage information
#
# Kernel Branches:
#   legacy     - Older stable kernels (LTS 4.x/5.x)
#   vendor     - Vendor-specific kernels (board-specific)
#   current    - Latest stable kernels (LTS 6.x)
#   edge       - Bleeding edge kernels (testing/latest)
#
# Typical Usage:
#   module_armbian_firmware select              # Interactive kernel selection
#   module_armbian_firmware install current "" "" "" "" # Install latest current kernel
#   module_armbian_firmware hold status         # Check if kernels are held
#
# ==============================================================================

module_options+=(
	["module_armbian_firmware,author"]="@igorpecovnik"
	["module_armbian_firmware,maintainer"]="@igorpecovnik"
	["module_armbian_firmware,feature"]="module_armbian_firmware"
	["module_armbian_firmware,example"]="select install show hold unhold repository help"
	["module_armbian_firmware,desc"]="Module for Armbian firmware manipulating"
	["module_armbian_firmware,status"]="Active"
	["module_armbian_firmware,doc_link"]="https://docs.armbian.com/"
	["module_armbian_firmware,group"]="System"
	["module_armbian_firmware,arch"]="x86-64 arm64 armhf riscv64"
	["module_armbian_firmware,max_versions"]="4"
)

function module_armbian_firmware() {
	local title="Armbian FW"

	# Convert the example string to an array of available commands
	# Commands: select, install, show, hold, unhold, repository, help
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_armbian_firmware,example"]}"

	# Update kernel environment variables
	# BRANCH, KERNELPKG_VERSION, KERNELPKG_LINUXFAMILY may require being updated after kernel switch
	update_kernel_env

	case "$1" in

		# ========================================================================
		# SELECT COMMAND: Interactive TUI for selecting and installing kernels
		# ========================================================================
		"${commands[0]}")

			# Update package lists to ensure we have latest kernel information
			# Beta repositories are updated frequently, so we always refresh before showing available kernels
			pkg_update

			# Default to showing all kernel branches if not explicitly defined
			# This handles old builds where KERNEL_TEST_TARGET might not be set
			[[ -z "${KERNEL_TEST_TARGET}" ]] && KERNEL_TEST_TARGET="legacy,vendor,current,edge"

			# Check if firmware packages are currently on hold (prevented from upgrading)
			# If so, warn user and offer to release the hold before proceeding
			if ${module_options["module_armbian_firmware,feature"]} ${commands[3]} "status"; then
				if dialog_yesno "Warning!" "Firmware upgrade is disabled. Release hold and proceed?" "Yes" "No" 7 60; then
					${module_options["module_armbian_firmware,feature"]} ${commands[4]}
				else
					return 0
				fi
			fi

			# Ask user if they want to see all available kernels or just mainstream ones
			# Default (no) shows all branches including edge and vendor-specific kernels
			if ! dialog_yesno "Advanced options" "Show only mainstream kernels on the list?" "Yes" "No" 7 60 --defaultno; then
				KERNEL_TEST_TARGET="legacy,vendor,current,edge"
			fi

			# Build list of kernel package names to search for in repository
			# Special handling for Rockchip RK3588 boards which use different naming scheme
			local kernel_test_target=$(\
				for kernel_test_target in ${KERNEL_TEST_TARGET//,/ }
				do
					# Rockchip RK3588 exception: vendor kernel uses rk35xx suffix
					# current/edge kernels use rockchip64 suffix
					if [[ "${BOARDFAMILY}" == "rockchip-rk3588" ]]; then
						if [[ "${kernel_test_target}" == "vendor" ]]; then
							echo "linux-image-${kernel_test_target}-rk35xx"
						elif [[ "${kernel_test_target}" =~ ^(current|edge)$ ]]; then
							echo "linux-image-${kernel_test_target}-rockchip64"
						fi
					else
						# Standard naming for all other board families
						echo "linux-image-${kernel_test_target}-${LINUXFAMILY}"
					fi
				done
				)

			# Get currently installed kernel version to hide it from the selection list
			# This prevents users from "reinstalling" the same kernel they already have
			local installed_kernel_version=$(dpkg -l | grep '^ii' | grep linux-image | awk '{print $2"="$3}' | head -1)

			# Build grep command to filter out currently installed kernel from the list
			[[ -n ${installed_kernel_version} ]] && local grep_current_kernel=" | grep -v ${installed_kernel_version}"

			# Construct apt-cache search command to find available kernel versions
			# This complex pipeline extracts package names and versions from repository metadata
			local search_exec="apt-cache show ${kernel_test_target} \
			| grep -E \"Package:|Version:|version:|family\" \
			| grep -v \"Config-Version\" \
			| sed -n -e 's/^.*: //p' \
			| sed 's/\.$//g' \
			| xargs -n3 -d'\n' \
			| sed \"s/ /=/\" $grep_current_kernel"

			# Collect all kernels grouped by branch, then take last N of each branch
			# This prevents overwhelming the user with too many old kernel versions
			declare -A branch_kernels
			IFS=$'\n'
			for line in $(eval ${search_exec}); do
				# Extract package and version (package=version format), and kernel version
				local pkg=$(echo "$line" | awk -F '=| ' '{print $1}')
				local kernel_ver=$(echo "$line" | awk -F '=| ' '{print $2}')
				# Extract branch (3rd field in package name: linux-image-<branch>-<linuxfamily>)
				local branch=$(echo "$pkg" | cut -d'-' -f3 | cut -d'=' -f1)
				# Add to branch group
				branch_kernels["$branch"]+="$line"$'\n'
			done
			unset IFS

			# Build menu list for dialog: package name and kernel version
			# Only show last N kernels per branch (most recent versions)
			# N is configurable via module_armbian_firmware,max_versions option
			IFS=$'\n'
			local LIST=()
			local max_versions="${module_options["module_armbian_firmware,max_versions"]:-3}"
			for branch in "${!branch_kernels[@]}"; do
				# Sort by kernel version (field 2) and take last N (newest)
				for line in $(echo "${branch_kernels[$branch]}" | sort -k2 -V -r | head -n "$max_versions"); do
					# First field: package=version (e.g., linux-image-current-meson64=23.02.2-trunk)
					# Second field: kernel version (e.g., 6.6.44)
					LIST+=("$(echo $line | awk '{print $1}')      ")
					LIST+=("v$(echo $line | awk '{print $2}')")
				done
			done
			unset IFS

			# Calculate menu dimensions and display selection dialog
			local list_length=$((${#LIST[@]} / 2))
			if [ "$list_length" -eq 0 ]; then
				# No alternative kernels available for this board
				dialog_msgbox "Warning" "No other kernels available!" 7 31
			else
				# Calculate menu dimensions
				local menu_height=$((${list_length} + 7))
				local menu_width=80
				local menu_list_height=${list_length}

				# Show kernel selection menu and capture user's choice
				if target_version=$(dialog_menu "Select kernel" "" ${menu_height} ${menu_width} ${menu_list_height} -- "${LIST[@]}")
				then
					# Extract branch and linuxfamily from selected package name
					# Package name format: linux-image-<branch>-<linuxfamily>=<version>
					local branch=$(echo "${target_version}" | cut -d'-' -f3)
					local linuxfamily=$(echo "${target_version}" | cut -d'-' -f4 | cut -d'=' -f1)
					# Call install command to perform the actual kernel installation
					${module_options["module_armbian_firmware,feature"]} ${commands[1]} "${branch}" "${target_version/*=/}" "" "${linuxfamily}"
				fi
			fi

		;;

		# ========================================================================
		# INSTALL COMMAND: Purge old kernel packages and install new ones
		# Parameters: $2=branch, $3=version, $4=hide, $5=linuxfamily
		# ========================================================================
		"${commands[1]}")

			# Parse input parameters
			local branch=$2                              # Kernel branch: legacy, vendor, current, edge
			local version="$( echo $3 | tr -d '\011\012\013\014\015\040')" # Specific version (cleaned of tabs/spaces)
			local hide=$4                                # If "hide", suppress output
			local linuxfamily=$5                         # Board family (e.g., rockchip64, meson64)

			# Idempotency check: don't reinstall if exact version is already present
			# This prevents unnecessary reboots and saves time
			if [[ -n "${version}" ]]; then
				local current_version=$(dpkg -l | grep "^ii" | grep "linux-image-${branch}-${linuxfamily}" | awk '{print $3}')
				if [[ "${current_version}" == "${version}" ]]; then
					echo "Kernel ${branch}-${linuxfamily} version ${version} is already installed."
					return 0
				fi
			fi

			# Update package lists to ensure we have latest repository information
			# This is critical for beta repositories which are updated frequently
			pkg_update

			# Create temporary APT pinning policy to force packages from current release
			# Priority 1001 ensures these packages won't be upgraded to different versions
			# The trap ensures cleanup even if the script is interrupted
			cat > "/etc/apt/preferences.d/armbian-upgrade-policy" <<- EOT
			Package: armbian-bsp* armbian-firmware* linux-*
			Pin: release a=${DISTROID}
			Pin-Priority: 1001
			EOT
			trap '{ rm -f -- "/etc/apt/preferences.d/armbian-upgrade-policy"; }' EXIT

			# Generate the list of packages to install based on branch and version
			# The "hide" parameter suppresses output since we're using the list programmatically
			${module_options["module_armbian_firmware,feature"]} ${commands[2]} "${branch}" "${version}" "hide" "" "$linuxfamily"

			# Install each package with proper error handling
			# For each package: remove existing version, then install new version
			for pkg in ${packages[@]}; do
				# Test if package installation is possible (dependencies exist, network available)
				# This fails gracefully before attempting actual installation
				if [[ -z $(LC_ALL=C apt-get install --simulate --download-only --allow-downgrades --reinstall "${pkg}" 2>/dev/null | grep "not possible") ]]; then
					# Convert specific package name to wildcard pattern for removal
					# e.g., "linux-image-current-meson64=1.2.3" -> "linux-image*"
					purge_pkg=$(echo $pkg | sed -e 's/linux-image.*/linux-image*/;s/linux-dtb.*/linux-dtb*/;s/linux-headers.*/linux-headers*/;s/armbian-firmware-*/armbian-firmware*/')
					pkg_remove ${purge_pkg}
					pkg_install --allow-downgrades ${pkg}
				else
					# Package installation failed - likely network or repository issue
					echo "Error: Package ${pkg} install not possible due to network / repository problem. Try again later and report to Armbian forums"
					return 1
				fi
			done

			# Clean up the temporary APT policy file
			rm -f /etc/apt/preferences.d/armbian-upgrade-policy

			# Prompt for reboot if running interactively
			# Kernel changes require reboot to take effect
			if test -t 0; then
				if dialog_yesno " Reboot required " "A reboot is required to apply the changes. Shall we reboot now?" "Reboot" "Cancel" 7 34; then
					reboot
				fi
			fi
		;;

		# ========================================================================
		# SHOW COMMAND: Generate list of packages to install (without installing)
		# Parameters: $2=branch, $3=version, $4=hide, $5=repository, $6=linuxfamily
		# Output: Space-separated list of package names (unless $4=="hide")
		# ========================================================================
		"${commands[2]}")

			# Parse input parameters with defaults
			local branch="${2:-$BRANCH}"                 # Default to current branch
			local version="$( echo "$3" | tr -d '\011\012\013\014\015\040')" # Clean version string
			local hide="$4"                              # If "hide", don't output the list
			local repository="$5"                        # Repository to use (currently unused)
			local linuxfamily="${6:-$KERNELPKG_LINUXFAMILY}" # Default to kernel environment

			# Default to stable repository if not specified
			[[ -z $repository ]] && local repository="apt.armbian.com"

			# Build base package list for kernel installation
			# Always includes kernel image and device tree binaries
			armbian_packages=(
				"linux-image-${branch}-${linuxfamily}"
				"linux-dtb-${branch}-${linuxfamily}"
			)

			# Add headers to package list if they were previously installed
			# This maintains user's previous choice to have headers installed
			if dpkg -l | grep -E "linux-headers" >/dev/null; then
				armbian_packages+=("linux-headers-${branch}-${linuxfamily}")
			fi

			# Resolve specific package versions from repository cache
			# When a specific version is requested, we check if it exists
			# If the requested version doesn't exist, we skip that package rather than failing
			# This prevents breaking installations when specific versions are removed from repos
			packages=""
			for pkg in ${armbian_packages[@]}; do

				# Query APT cache for package information
				# Returns package name and version if available in repository
				local cache_show=$(apt-cache show "$pkg" 2> /dev/null | grep -E "Package:|^Version:|family" \
					| sed -n -e 's/^.*: //p' \
					| sed 's/\.$//g' \
					| xargs -n2 -d'\n' \
					| grep "${pkg}")

				# Add package to installation list
				# If version specified, use "package=version" format
				# If version not specified or not found, use bare package name (latest)
				if [[ -n "${version}" && -n "${cache_show}" ]]; then
					# Check if exact version exists in cache
					if [[ -n $(echo "$cache_show" | grep "$version""$" ) ]]; then
						packages+="${pkg}=${version} "
					fi
					# If version doesn't exist, package is silently skipped (fallback behavior)
				elif [[ -n "${cache_show}" ]]; then
					# No version specified, use package name (will install latest)
					packages+="${pkg} "
				fi
			done

			# Output the package list unless "hide" parameter is set
			# The "hide" mode is used when we need the list programmatically but don't want to display it
			[[ "$4" != "hide" ]] && echo ${packages[@]}

		;;

		# ========================================================================
		# HOLD COMMAND: Prevent kernel packages from being upgraded
		# Parameters: $2=status (if "status", check if packages are held; otherwise, hold them)
		# Returns: 0 if packages are held (when status=="status"), 1 otherwise
		# ========================================================================
		"${commands[3]}")

			# Parse input parameter
			local status="$2"    # "status" to check, empty to actually hold packages

			# Generate list of kernel packages that would be affected
			${module_options["module_armbian_firmware,feature"]} ${commands[2]} "" "" hide

			# Two modes: check status or actually hold packages
			if [[ "$status" == "status" ]]; then
				# STATUS MODE: Check if Armbian kernel packages are currently on hold
				# Get list of all packages on hold in the system
				local get_hold=($(apt-mark showhold))

				# Check which of our packages are in the held packages list
				# This nested loop matches our packages against the global hold list
				local test_hold=($(for all_packages in "${packages[@]}"; do
					for hold_packages in "${get_hold[@]}"; do
						echo "$all_packages" | grep -q "$hold_packages" && echo "$all_packages"
					done
				done))

				# Return 0 (true) if any packages are held, 1 (false) otherwise
				[[ -z ${test_hold[@]} ]] && return 1 || return 0
			else
				# HOLD MODE: Place Armbian kernel packages on hold
				# This prevents automatic upgrades via apt upgrade
				# Note: packages array must not be quoted to allow word splitting
				apt-mark hold ${packages[@]} # without quotes
			fi

		;;

		# ========================================================================
		# UNHOLD COMMAND: Release held kernel packages, allowing upgrades
		# Parameters: None
		# ========================================================================
		"${commands[4]}")

			# Generate list of kernel packages to unhold
			${module_options["module_armbian_firmware,feature"]} ${commands[2]} "" "" hide

			# Remove hold mark from all Armbian kernel packages
			# This allows them to be upgraded again via apt upgrade
			# Note: packages array must not be quoted to allow word splitting
			apt-mark unhold ${packages[@]} # without quotes

		;;

		# ========================================================================
		# REPOSITORY COMMAND: Switch between stable and rolling repositories
		# Parameters: $2=repository (stable/rolling), $3=status (if "status", just check)
		# Side effect: When not just checking status, reinstalls firmware from new repo
		# ========================================================================
		"${commands[5]}")

			# Parse input parameters
			local repository=$2     # Target repository: "stable" or "rolling"
			local status=$3          # If "status", only check current repo without switching

			# Get current kernel branch and family for potential reinstallation
			local branch=${BRANCH}
			local linuxfamily=${LINUXFAMILY:-$KERNELPKG_LINUXFAMILY}

			# Find which Armbian sources file exists (old .list or new .sources format)
			local sources_file=""
			[[ -f "/etc/apt/sources.list.d/armbian.list" ]] && sources_file="/etc/apt/sources.list.d/armbian.list"
			[[ -f "/etc/apt/sources.list.d/armbian.sources" ]] && sources_file="/etc/apt/sources.list.d/armbian.sources"

			# Validate we found a sources file
			if [[ -z "$sources_file" ]]; then
				echo "Error: Armbian APT sources file not found." >&2
				return 1
			fi

			# Check current repository and switch if requested
			if grep -q 'apt.armbian.com' "$sources_file"; then
				# Currently on STABLE repository
				if [[ "$repository" == "rolling" && "$status" == "status" ]]; then
					return 1  # Not on rolling
				elif [[ "$status" == "status" ]]; then
					return 0  # On stable
				fi
				# Switch to rolling repository
				if [[ "$repository" == "rolling" ]]; then
					sed -i 's|[a-zA-Z0-9.-]*\.armbian\.com|beta.armbian.com|g' "$sources_file"
					pkg_update
				fi
			else
				# Currently on ROLLING (beta) repository
				if [[ "$repository" == "stable" && "$status" == "status" ]]; then
					return 1  # Not on stable
				elif [[ "$status" == "status" ]]; then
					return 0  # On rolling
				fi
				# Switch to stable repository
				if [[ "$repository" == "stable" ]]; then
					sed -i 's|[a-zA-Z0-9.-]*\.armbian\.com|apt.armbian.com|g' "$sources_file"
					pkg_update
				fi
			fi

			# If we're not just checking status, trigger firmware reinstallation
			# This pulls packages from the newly-switched repository
			[[ "$status" != "status" ]] && ${module_options["module_armbian_firmware,feature"]} ${commands[1]} "${branch}" "" "" "${linuxfamily}"
		;;


		# ========================================================================
		# HELP COMMAND: Display usage information
		# ========================================================================
		"${commands[6]}")
			echo -e "\nUsage: ${module_options["module_armbian_firmware,feature"]} <command> <switches>"
			echo -e "Commands:  ${module_options["module_armbian_firmware,example"]}"
			echo "Available commands:"
			echo -e "  select     - TUI to select $title.                    switches: [ stable | rolling ]"
			echo -e "  install    - Install $title.                          switches: [ \$branch | \$version ]"
			echo -e "  show       - Show $title packages.                    switches: [ \$branch | \$version | hide ]"
			echo -e "  hold       - Mark $title packages as held back.       switches: [status] returns true or false"
			echo -e "  unhold     - Unset $title packages set as held back."
			echo -e "  repository - Selects repository and performs update.   switches: [ stable | rolling ]"
			echo
		;;
		*)
			# Default to help if invalid command is provided
			${module_options["module_armbian_firmware,feature"]} ${commands[6]}
		;;
	esac
}

module_options+=(
	["change_system_hostname,author"]="@igorpecovnik"
	["change_system_hostname,ref_link"]=""
	["change_system_hostname,feature"]="Change hostname"
	["change_system_hostname,desc"]="change_system_hostname"
	["change_system_hostname,example"]="change_system_hostname"
	["change_system_hostname,status"]="Active"
)
#
# @description Change system hostname
#
function change_system_hostname() {
	local new_hostname=$(dialog_inputbox "Enter new hostname" "" "" 7 50)
	[ $? -eq 0 ] && [ -n "${new_hostname}" ] && hostnamectl set-hostname "${new_hostname}"
}


module_options+=(
	["module_armbian_kvmtest,author"]="@igorpecovnik"
	["module_armbian_kvmtest,feature"]="module_armbian_kvmtest"
	["module_armbian_kvmtest,desc"]="Deploy Armbian KVM instances"
	["module_armbian_kvmtest,example"]="install remove save drop restore list help"
	["module_armbian_kvmtest,port"]=""
	["module_armbian_kvmtest,status"]="Active"
	["module_armbian_kvmtest,arch"]="x86-64"
)
#
# Module deploy Armbian QEMU KVM instances
# module_armbian_kvmtest - Manage the lifecycle of Armbian KVM virtual machines.
#
# This function deploys, configures, and manages Armbian-based KVM instances. It supports a suite of
# commands (install, remove, save, drop, restore, list, help) to handle the entire virtual machine lifecycle.
# Depending on the command, the function performs operations such as downloading cloud-based Armbian images,
# resizing and mounting VM disk images, customizing network settings, and executing provisioning scripts.
#
# Globals:
#   module_options - An associative array with module metadata (author, features, command examples, etc.).
#
# Arguments:
#   The first argument specifies the command to execute (e.g., install, remove, save, drop, restore, list, help).
#   Additional arguments should be provided as key=value pairs to customize the operation. Supported keys include:
#     instances     - Number of VM instances to deploy (default: "01").
#     provisioning  - Path to a provisioning script to be run on the first boot of each VM.
#     firstconfig   - File with initial configuration commands for the VMs.
#     startingip    - Starting IP address (with underscores replacing dots, e.g., 192_168_1_100).
#     gateway       - Gateway IP address (with underscores replacing dots, e.g., 192_168_1_1).
#     keyword       - Image filter keyword; supports comma-separated values (converted internally to a regex).
#     arch          - Architecture of the VM image (default: "x86").
#     kvmprefix     - Prefix used for naming VMs (default: "kvmtest").
#     network       - Network configuration (default: "default", or set to "bridge=[bridge]" if a bridge is specified).
#     bridge        - Overrides the default network by specifying a network bridge.
#     memory        - Memory allocation for each VM, in MB (default: "3072").
#     vcpus         - Number of virtual CPUs allocated per VM (default: "2").
#     size          - Additional disk space in GB to allocate to each VM (default: "10").
#
# Outputs:
#   The function prints deployment progress, image URLs (when listing), and usage instructions to STDOUT.
#
# Returns:
#   This function does not return a value; it executes commands with side effects.
#
# Example:
#   To deploy three VMs using a custom provisioning script, increased memory, and specific IP settings:
#     module_armbian_kvmtest install instances=03 memory=4096 vcpus=4 startingip=192_168_1_100 gateway=192_168_1_1 provisioning=/path/to/script keyword=Focal
#
#   To remove all deployed VMs:
#     module_armbian_kvmtest remove
function module_armbian_kvmtest () {

	local title="kvmtest"
	local condition=$(which "$title" 2>/dev/null)

	# read additional parameters from command line
	local parameter
	declare -A params
	for var in "$@"; do
		IFS=' ' read -r -a parameter <<< "${var}"
		for selected in ${parameter[@]}; do
			IFS='=' read -r -a split <<< "${selected}"
			# Only accept known parameters for security
			case "${split[0]}" in
				instances|provisioning|firstconfig|startingip|gateway|keyword|arch|kvmprefix|network|bridge|memory|vcpus|size|destination|channel)
					params["${split[0]}"]="${split[1]}"
					;;
			esac
		done
	done

	# Extract parameters from array
	instances="${params[instances]:-}"
	provisioning="${params[provisioning]:-}"
	firstconfig="${params[firstconfig]:-}"
	startingip="${params[startingip]:-}"
	gateway="${params[gateway]:-}"
	keyword="${params[keyword]:-}"
	arch="${params[arch]:-}"
	kvmprefix="${params[kvmprefix]:-}"
	network="${params[network]:-}"
	bridge="${params[bridge]:-}"
	memory="${params[memory]:-}"
	vcpus="${params[vcpus]:-}"
	size="${params[size]:-}"
	destination="${params[destination]:-}"
	channel="${params[channel]:-nightly}"

	# if we provide startingip and gateway, set network
	if [[ -n "${startingip}" && -n "${gateway}" ]]; then
		PRESET_NET_CHANGE_DEFAULTS="1"
	fi

	local startingip=$(echo "${startingip:-}" | sed "s/_/./g")
	local gateway=$(echo "${gateway:-}" | sed "s/_/./g")

	local arch="${arch:-x86}" # VM architecture
	local network="${network:-default}"
	if [[ -n "${bridge}" ]]; then network="bridge=${bridge}"; fi
	local instances="${instances:-01}" # number of instances
	local size="${size:-10}" # additional disk space in GB
	local destination="${destination:-/var/lib/libvirt/images}"
	local kvmprefix="${kvmprefix:-kvmtest}"
	local memory="${memory:-3072}"
	local vcpus="${vcpus:-2}"
	local startingip="${startingip:-10.0.60.60}"
	local gateway="${gateway:-10.0.60.1}"
	local keyword=$(echo "${keyword:-}" | sed "s/,/|/g") # convert

	# Define image arrays for different channels
	local qcowimages_nightly=(
		"https://dl.armbian.com/nightly/uefi-${arch}/Forky_cloud_minimal-qcow2"
		"https://dl.armbian.com/nightly/uefi-${arch}/Plucky_cloud_minimal-qcow2"
	)

	local qcowimages_stable=(
		"https://dl.armbian.com/uefi-${arch}/Noble_cloud_minimal-qcow2"
		"https://dl.armbian.com/uefi-${arch}/Trixie_cloud_minimal-qcow2"
	)

	# Select image array based on channel parameter
	case "${channel}" in
		stable)
			qcowimages=("${qcowimages_stable[@]}")
			;;
		nightly|*)
			qcowimages=("${qcowimages_nightly[@]}")
			;;
	esac

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_armbian_kvmtest,example"]}"

	case "$1" in

		"${commands[0]}")

			pkg_install virtinst libvirt-daemon-system libvirt-clients qemu-kvm qemu-utils dnsmasq

			# start network
			virsh net-start default 2>/dev/null
			virsh net-autostart default 2>/dev/null

			# download images
			tempfolder=$(mktemp -d)
			trap '{ rm -rf -- "$tempfolder"; }' EXIT
			for qcowimage in ${qcowimages[@]}; do
				[[ -n "${keyword}" && ! $qcowimage =~ ${keyword} ]] && continue # skip not needed ones
				local filename=$(basename "$qcowimage" | sed "s/-qcow2/.qcow2/g")
				local output_file="${tempfolder}/${filename}"

				# Download with real progress based on file size
				(
					# Get expected file size
					expected_size=$(curl -sI "$qcowimage" | grep -i "content-length" | awk '{print $2}' | tr -d '\r')
					[[ -z "$expected_size" || "$expected_size" -eq 0 ]] && expected_size=100000000

					# Start download in background
					curl -sL "$qcowimage" -o "$output_file" &
					curl_pid=$!

					# Monitor file size and report progress
					while kill -0 $curl_pid 2>/dev/null; do
						if [[ -f "$output_file" ]]; then
							current_size=$(stat -f%z "$output_file" 2>/dev/null || stat -c%s "$output_file" 2>/dev/null)
							percent=$((current_size * 100 / expected_size))
							[[ $percent -gt 95 ]] && percent=95
							echo $percent
						fi
						sleep 0.5
					done
					echo 100
					wait $curl_pid
				) | dialog_gauge "Download" "$filename" 8 70

				# decompress
				if [[ "$(file $output_file --extension -b)" == "xz" ]]; then
					dialog_infobox "Decompressing" "$(basename $output_file)" 6 60
					mv "$output_file" "$output_file".xz
					xz -d "$output_file".xz
				fi




			done

			# we will mount qcow image
			modprobe nbd max_part=8

			mounttempfolder=$(mktemp -d)
			trap '{ umount "$mounttempfolder" 2>/dev/null; rm -rf -- "$tempfolder"; }' EXIT

			# Deploy several instances
			local j=0  # Initialize IP address counter
			for i in $(seq -w 01 $instances); do
				for qcowimage in ${qcowimages[@]}; do
					[[ ! $qcowimage =~ ${keyword/,/|} ]] && continue # skip not needed ones
					local filename=$(basename $qcowimage | sed "s/-qcow2/.qcow2/g") # identify filename
					local domain=$i-${kvmprefix}-$(basename $qcowimage | sed "s/-qcow2//g") # without qcow2
					local image="$i"-"${kvmprefix}"-"${filename}" # get image name
					cp ${tempfolder}/${filename} ${destination}/${image} # make a copy under different number
					sync
					qemu-img resize ${destination}/${image} +"${size}G" 2>/dev/null # expand
					qemu-nbd --connect=/dev/nbd0 ${destination}/${image} 2>/dev/null # connect to qemu image
					printf "fix\n" | sudo parted ---pretend-input-tty /dev/nbd0 print >/dev/null # fix resize
					mount /dev/nbd0p3 ${mounttempfolder} # 3rd partition on uefi images is rootfs
					# Check if it reads and display OS info
					local os_name=$(cat ${mounttempfolder}/etc/os-release | grep ARMBIAN_PRETTY_NAME | cut -d"=" -f2 | sed 's/"//g')
					dialog_infobox "" "$os_name" 6 60
					# commands for changing follows here
					j=$(( j + 1 ))
					local ip_address=$(awk -F\. '{ print $1"."$2"."$3"."$4+'$j' }' <<< $startingip )

					# script that is executed at firstrun
					if [[ -f ${provisioning} ]]; then
						echo "INSTANCE=$i" > ${mounttempfolder}/root/provisioning.sh
						cat "${provisioning}" >> ${mounttempfolder}/root/provisioning.sh
						chmod +x ${mounttempfolder}/root/provisioning.sh
					fi

					# first config
					if [[ ${firstconfig} ]]; then
						if [[ -f ${firstconfig} ]]; then
							cat "${firstconfig}" >> ${mounttempfolder}/root/.not_logged_in_yet
						fi
					else
					dialog_infobox "Applying first config" "$domain" 6 60
					cat <<- EOF >> ${mounttempfolder}/root/.not_logged_in_yet
					PRESET_NET_CHANGE_DEFAULTS="${PRESET_NET_CHANGE_DEFAULTS}"
					PRESET_NET_ETHERNET_ENABLED="1"
					PRESET_NET_USE_STATIC="1"
					PRESET_NET_STATIC_IP="${ip_address}"
					PRESET_NET_STATIC_MASK="255.255.255.0"
					PRESET_NET_STATIC_GATEWAY="${gateway}"
					PRESET_NET_STATIC_DNS="9.9.9.9 8.8.4.4"
					SET_LANG_BASED_ON_LOCATION="y"
					PRESET_LOCALE="${LANG:-en_US.UTF-8}"
					PRESET_TIMEZONE="$(cat /etc/timezone)"
					PRESET_ROOT_PASSWORD="armbian"
					PRESET_USER_NAME="armbian"
					PRESET_USER_PASSWORD="armbian"
					PRESET_USER_KEY=""
					PRESET_DEFAULT_REALNAME="Armbian user"
					PRESET_USER_SHELL="bash"
					EOF
					fi

					umount /dev/nbd0p3 # unmount
					qemu-nbd --disconnect /dev/nbd0 >/dev/null # disconnect from qemu image
					# install and start VM
					sleep 3
					virt-install \
					--name ${domain} \
					--memory ${memory} \
					--vcpus ${vcpus} \
					--autostart \
					--disk ${destination}/${image},bus=sata \
					--import \
					--os-variant ubuntu24.04 \
					--network ${network} \
					--noautoconsole
				done
			done

		;;
		"${commands[1]}")
			dialog_infobox "Info" "Removing VMs..." 6 60
			local shutdown_success=false
			for i in {1..10}; do
				for j in $(virsh list --all --name | grep ${kvmprefix}); do
					dialog_infobox "Shutting Down" "Stopping VM: $(virsh shutdown $j)" 6 60

					snapshots=($(virsh snapshot-list $j | tail -n +3 | head -n -1 | cut -d' ' -f2))
					if [[ ${#snapshots[@]} -gt 0 ]]; then
						local count=0
						local total=${#snapshots[@]}
						for snapshot in "${snapshots[@]}"; do
							count=$((count + 1))
							percent=$((count * 100 / total))
							echo $percent
							virsh snapshot-delete $j $snapshot
						done | dialog_gauge "Removing Snapshots" "Deleting snapshots from $j" 8 70
					fi
				done
				sleep 2
				if [[ -z "$(virsh list --name | grep ${kvmprefix})" ]]; then
					shutdown_success=true
					break
				fi
			done
			if $shutdown_success; then
				vms=($(virsh list --all --name | grep ${kvmprefix}))
				if [[ ${#vms[@]} -gt 0 ]]; then
					local count=0
					local total=${#vms[@]}
					for j in "${vms[@]}"; do
						count=$((count + 1))
						percent=$((count * 100 / total))
						echo $percent
						virsh undefine $j --remove-all-storage
					done | dialog_gauge "Removing VMs" "Undefining and removing VM storage" 8 70
				fi
			fi
		;;
		"${commands[2]}")
			dialog_infobox "" "Saving VM states..." 6 60
			for j in $(virsh list --all --name | grep ${kvmprefix}); do
				# create snapshots
				virsh snapshot-create-as --domain ${j} --name "initial-state"
			done
		;;
		"${commands[3]}")
			dialog_infobox "" "Dropping VM states..." 6 60
			for j in $(virsh list --all --name | grep ${kvmprefix}); do
				# drop snapshots
				virsh snapshot-delete "${j}" "initial-state"
			done
		;;
		"${commands[4]}")
			dialog_infobox "" "Restoring VM states..." 6 60
			for j in $(virsh list --all --name | grep ${kvmprefix}); do
				virsh shutdown $j 2>/dev/null
				virsh snapshot-revert --domain $j --snapshotname "initial-state" --running
				virsh shutdown $j 2>/dev/null
				for i in {1..20}; do
					sleep 2
					if [[ "$(virsh domstate $j | grep "shut off")" == "shut off" ]]; then break; fi
				done
				virsh start $j 2>/dev/null
			done
		;;
		"${commands[5]}")
			for qcowimage in ${qcowimages[@]}; do
				[[ -n "${keyword}" && ! $qcowimage =~ ${keyword} ]] && continue # skip not needed ones
				echo $qcowimage
			done
		;;
		"${commands[6]}")
			local help_text="Usage: ${module_options["module_armbian_kvmtest,feature"]} <command> [switches]\n\n"
			help_text+="Commands:  ${module_options["module_armbian_kvmtest,example"]}\n\n"
			help_text+="Available commands:\n\n"
			help_text+="  install  - Install $title\n"
			help_text+="  remove   - Remove all virtual machines $title\n"
			help_text+="  save     - Save state of all VM $title\n"
			help_text+="  restore  - Restore all saved state of VM $title\n"
			help_text+="  drop     - Drop all saved states of VM $title\n"
			help_text+="  list     - Show available VM machines $title\n"
			help_text+="\nAvailable switches:\n\n"
			help_text+="  kvmprefix     - Name prefix (default = kvmtest)\n"
			help_text+="  memory        - KVM memory (default = 3072)\n"
			help_text+="  vcpus         - Virtual CPUs (default = 2)\n"
			help_text+="  bridge        - Use network bridge br0,br1,... instead of default interface\n"
			help_text+="  instances     - Number of instances (default = 01)\n"
			help_text+="  provisioning  - File of command that is executed at first run\n"
			help_text+="  firstconfig   - Armbian first config\n"
			help_text+="  keyword       - Select only certain image, example: Focal_Jammy VM image\n"
			help_text+="  arch          - Architecture of VM image (default = x86)\n"
			help_text+="  size          - Additional disk space in GB (default = 10)\n"
			help_text+="  startingip    - Starting IP address (default = 10.0.60.60)\n"
			help_text+="  gateway       - Gateway IP address (default = 10.0.60.1)\n"
			help_text+="  channel       - Image channel: stable or nightly (default = nightly)\n"

			if [[ "$DIALOG" == "read" ]]; then
				echo -e "$help_text"
			else
				dialog_msgbox "Armbian KVM Test Help" "$help_text" 25 80
			fi
		;;
		*)
			${module_options["module_armbian_kvmtest,feature"]} ${commands[6]}
		;;
	esac
}


module_options+=(
	["module_headers,author"]="@armbian"
	["module_headers,maintainer"]="@igorpecovnik"
	["module_headers,feature"]="module_headers"
	["module_headers,desc"]="Install kernel headers for building kernel modules"
	["module_headers,example"]="install remove status help"
	["module_headers,port"]=""
	["module_headers,status"]="Active"
	["module_headers,arch"]=""
	["module_headers,doc_link"]="https://www.kernel.org/doc/html/latest/"
	["module_headers,group"]="System"
	["module_headers,help_remove"]="Remove kernel headers and build dependencies"
)
#
# Module Headers
#
function module_headers () {
	local title="Kernel Headers"
	local install_pkg=""

	# Determine the correct headers package to install
	if [[ -f /etc/armbian-release ]]; then
		source /etc/armbian-release
		# Branch information is stored in armbian-release at boot time.
		# When we change kernel branches, we need to re-read this and update it
		update_kernel_env
		if [[ -n "${BRANCH}" && -n "${LINUXFAMILY}" ]]; then
			install_pkg="linux-headers-${BRANCH}-${LINUXFAMILY}"
		fi
	fi
	if [[ -z "${install_pkg}" ]]; then
		local arch
		arch="$(dpkg --print-architecture)" || return 1
		local kernel_release
		kernel_release="$(uname -r)" || return 1
		# Remove architecture suffix from kernel release if present
		install_pkg="linux-headers-$(echo "${kernel_release}" | sed "s/-${arch}//")"
	fi

	# Validate we determined a package name
	if [[ -z "${install_pkg}" ]]; then
		echo "Error: Unable to determine kernel headers package name"
		return 1
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_headers,example"]}"

	case "$1" in
		"${commands[0]}")
			# Check if the module is already installed
			if pkg_installed "${install_pkg}"; then
				echo "Kernel headers are already installed: ${install_pkg}"
				return 0
			fi

			echo "Installing kernel headers: ${install_pkg}"
			pkg_update
			pkg_install "${install_pkg}" build-essential git || return 1
			echo "Kernel headers installed successfully"
		;;
		"${commands[1]}")
			echo "Removing kernel headers: ${install_pkg}"
			pkg_remove "${install_pkg}" build-essential || return 1
			# Safely remove header directories
			if compgen -G "/usr/src/linux-headers*" > /dev/null; then
				rm -rf /usr/src/linux-headers*
				echo "Kernel headers removed successfully"
			fi
		;;
		"${commands[2]}")
			if pkg_installed "${install_pkg}"; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			show_module_help "module_headers" "$title" "" "native"
		;;
		*)
			${module_options["module_headers,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["module_nfsd,author"]="@igorpecovnik"
	["module_nfsd,feature"]="module_nfsd"
	["module_nfsd,desc"]="Install nfsd server"
	["module_nfsd,example"]="install remove manage add status clients servers help"
	["module_nfsd,port"]=""
	["module_nfsd,status"]="Active"
	["module_nfsd,arch"]=""
)
#
# Module nfsd
#
function module_nfsd () {
	local title="nfsd"
	local condition=$(which "$title" 2>/dev/null)?

	local service_name=nfs-server.service

	# we will store our config in subfolder
	mkdir -p /etc/exports.d/

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_nfsd,example"]}"

	NFSD_BASE="${SOFTWARE_FOLDER}/nfsd"

	case "$1" in
		"${commands[0]}")
			pkg_install nfs-common nfs-kernel-server
			# add some exports
			${module_options["module_nfsd,feature"]} ${commands[2]}
			srv_restart $service_name
		;;
		"${commands[1]}")
			pkg_remove nfs-kernel-server
		;;
		"${commands[2]}")
			while true; do
				LIST=() IFS=$'\n' LIST=($(grep "^[^#;]" /etc/exports.d/armbian.exports))
				LIST_LENGTH=${#LIST[@]}
				if [[ "${LIST_LENGTH}" -ge 1 ]]; then
					line=$(dialog --no-items \
					--title "Select export to edit" \
					--ok-label "Add" \
					--cancel-label "Apply" \
					--extra-button \
					--extra-label "Delete" \
					--menu "" \
					$((${LIST_LENGTH} + 6)) \
					80 \
					$((${LIST_LENGTH})) \
					${LIST[@]} 3>&1 1>&2 2>&3)
					exitstatus=$?
					case "$exitstatus" in
						0)
							${module_options["module_nfsd,feature"]} ${commands[3]}
						;;
						1)
							break
						;;
						3)
							sed -i '\?^'$line'?d' /etc/exports.d/armbian.exports
						;;
					esac
				else
					${module_options["module_nfsd,feature"]} ${commands[3]}
					break
				fi
			done
			srv_restart $service_name
		;;
		"${commands[3]}")
			# choose between most common options
			LIST=()
			LIST=("ro" "Allow read only requests" On)
			LIST+=("rw" "Allow read and write requests" OFF)
			LIST+=("sync" "Immediate sync all writes" On)
			LIST+=("fsid=0" "Check man pages" OFF)
			LIST+=("no_subtree_check" "Disables subtree checking, improves reliability" On)
			LIST_LENGTH=$((${#LIST[@]}/3))
			if add_folder=$(dialog --title \
							"Which folder do you want to export?" \
							--inputbox "" \
							6 80 "${SOFTWARE_FOLDER}" 3>&1 1>&2 2>&3); then
				if add_ip=$(dialog --title \
							"Which IP or range can access this folder?" \
							--inputbox "\nExamples: 192.168.1.1, 192.168.1.0/24" \
							8 80 "${LOCALSUBNET}" 3>&1 1>&2 2>&3); then
					if add_options=$(dialog --separate-output \
							--nocancel \
							--title "NFS volume options" \
							--checklist "" \
							$((${LIST_LENGTH} + 6)) 80 ${LIST_LENGTH} "${LIST[@]}" 3>&1 1>&2 2>&3); then
							echo "$add_folder $add_ip($(echo $add_options | tr ' ' ','))" \
							>> /etc/exports.d/armbian.exports
							[[ -n "${add_folder}" ]] && mkdir -p "${add_folder}"
					fi
				fi
			fi
		;;
		"${commands[4]}")
			pkg_installed nfs-kernel-server
		;;
		"${commands[5]}")
			show_message <<< $(printf '%s\n' "${NFS_CLIENTS_CONNECTED[@]}")
		;;
		"${commands[6]}")

			if ! pkg_installed nmap; then
				pkg_install nmap
			fi

			LIST=($(nmap -oG - -p2049 ${LOCALSUBNET} | grep '/open/' | cut -d' ' -f2 | grep -v "${LOCALIPADD}"))
			LIST_LENGTH=$((${#LIST[@]}))
			if nfs_server=$(dialog --no-items \
				--title "Network filesystem (NFS) servers in subnet" \
				--menu "" \
				$((${LIST_LENGTH} + 6)) \
				80 \
				$((${LIST_LENGTH})) \
				${LIST[@]} 3>&1 1>&2 2>&3); then
					# verify if we can connect there
					LIST=($(showmount -e "${nfs_server}" | tail -n +2 | cut -d" " -f1 | sort))
					VERIFIED_LIST=()
					local tempfolder=$(mktemp -d)
					local alreadymounted=$(df | grep $nfs_server | cut -d" " -f1 | xargs)
					for i in "${LIST[@]}"; do
						mount -n -t nfs $nfs_server:$i ${tempfolder} 2>/dev/null
						if [[ $? -eq 0 ]]; then
							if echo "${alreadymounted}" | grep -vq $i; then
							VERIFIED_LIST+=($i)
							fi
							umount ${tempfolder}
						fi
					done
					VERIFIED_LIST_LENGTH=$((${#VERIFIED_LIST[@]}))
					if shares=$(dialog --no-items \
						--title "Network filesystem (NFS) shares on ${nfs_server}" \
						--menu "" \
						$((${VERIFIED_LIST_LENGTH} + 6)) \
						80 \
						$((${VERIFIED_LIST_LENGTH})) \
						${VERIFIED_LIST[@]} 3>&1 1>&2 2>&3)
						then
							if mount_folder=$(dialog --title \
							"Where do you want to mount $shares ?" \
							--inputbox "" \
							6 80 "/armbian" 3>&1 1>&2 2>&3); then
								if mount_options=$(dialog --title \
								"Which mount options do you want to use?" \
							--inputbox "" \
							6 80 "auto,noatime 0 0" 3>&1 1>&2 2>&3); then
								mkdir -p ${mount_folder}
								read
								sed -i '\?^'$nfs_server:$shares'?d' /etc/fstab
								echo "${nfs_server}:${shares} ${mount_folder} nfs ${mount_options}" >> /etc/fstab
								srv_daemon_reload
								mount ${mount_options}
							fi
							fi
						fi
					fi
		;;
		"${commands[7]}")
			echo -e "\nUsage: ${module_options["module_nfsd,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_nfsd,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tmanage\t- Edit exports in $title."
			echo -e "\tadd\t- Add exports to $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
			${module_options["module_nfsd,feature"]} ${commands[7]}
		;;
	esac
}

module_options+=(
	["manage_odroid_board,author"]="@GeoffClements"
	["manage_odroid_board,ref_link"]=""
	["manage_odroid_board,feature"]="Odroid board"
	["manage_odroid_board,desc"]="Select optimised Odroid board configuration"
	["manage_odroid_board,example"]="select"
	["manage_odroid_board,status"]="Stable"
	["manage_odroid_board,arch"]="armhf"
)
#
# @description Select optimised board configuration
#
function manage_odroid_board() {

	local board_list=("Odroid XU4" "Odroid XU3" "Odroid XU3 Lite" "Odroid HC1/HC2")
	local board_id=("xu4" "xu3" "xu3l" "hc1")
	local -a list
	local state

	local env_file=/boot/armbianEnv.txt
	local current_board=$(grep -oP '^board_name=\K.*' ${env_file})
	local target_board=${current_board}

	for board_num in $(seq 0 $((${#board_list[@]} - 1))); do
		if [[ "${board_id[${board_num}]}" == "${current_board}" ]]; then
			state=on
		else
			state=off
		fi
	list+=("${board_id[${board_num}]}" "${board_list[${board_num}]}" "${state}")
	done

	if target_board=$(dialog_radiolist "Select optimised board configuration" "" 10 42 4 --notags -- "${list[@]}"); then
		sed -i "s/^board_name=.*/board_name=${target_board}/" ${env_file} 2> /dev/null && \
		grep -q "^board_name=${target_board}" ${env_file} 2>/dev/null || \
		echo "board_name=${target_board}" >> ${env_file}
		sed -i "s/^BOARD_NAME.*/BOARD_NAME=\"Odroid ${target_board^^}\"/" /etc/armbian-release

		if dialog_yesno " Reboot required " "A reboot is required to apply the changes. Shall we reboot now?" "Reboot" "Cancel" 7 34; then
		reboot
		fi
	fi
}

module_options+=(
	["module_nfs,author"]="@igorpecovnik"
	["module_nfs,feature"]="module_nfs"
	["module_nfs,desc"]="Install nfs client"
	["module_nfs,example"]="install remove servers mounts help"
	["module_nfs,port"]=""
	["module_nfs,status"]="Active"
	["module_nfs,arch"]=""
)
#
# Module nfs client
#
function module_nfs () {
	local title="nfs"
	local condition=$(which "$title" 2>/dev/null)?

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_nfs,example"]}"

	nfs_BASE="${SOFTWARE_FOLDER}/nfs"

	case "$1" in
		"${commands[0]}")
			pkg_install nfs-common
		;;
		"${commands[1]}")
			pkg_remove nfs-common
		;;
		"${commands[2]}")

			if ! pkg_installed nmap; then pkg_install nmap; fi
			if ! pkg_installed nfs-common; then pkg_install nfs-common; fi

			local subnet=$(dialog_inputbox "Choose subnet to search for NFS server" "\\nValid format: <IP Address>/<Subnet Mask Length>" "${LOCALSUBNET}" 9 60)
			LIST=($(nmap -oG - -p2049 ${subnet} | grep '/open/' | cut -d' ' -f2 | grep -v "${LOCALIPADD}"))
			LIST_LENGTH=$((${#LIST[@]}))
			if nfs_server=$(dialog --no-items \
				--title "Network filesystem (NFS) servers in subnet" \
				--menu "" \
				$((${LIST_LENGTH} + 6)) \
				80 \
				$((${LIST_LENGTH})) \
				${LIST[@]} 3>&1 1>&2 2>&3); then
					# verify if we can connect there. adding timeout kill as it can hang if server doesn't share to this client
					LIST=($(timeout --kill 10s 5s showmount -e "${nfs_server}" 2>/dev/null | tail -n +2 | cut -d" " -f1 | sort))
					VERIFIED_LIST=()
					local tempfolder=$(mktemp -d)
					local alreadymounted=$(df | grep $nfs_server | cut -d" " -f1 | xargs)
					for i in "${LIST[@]}"; do
						mount -n -t nfs $nfs_server:$i ${tempfolder} 2>/dev/null
						if [[ $? -eq 0 ]]; then
							if echo "${alreadymounted}" | grep -vq $i; then
							VERIFIED_LIST+=($i)
							fi
							umount ${tempfolder}
						fi
					done
					VERIFIED_LIST_LENGTH=$((${#VERIFIED_LIST[@]}))
					if shares=$(dialog --no-items \
						--title "Network filesystem (NFS) shares on ${nfs_server}" \
						--menu "" \
						$((${VERIFIED_LIST_LENGTH} + 6)) \
						80 \
						$((${VERIFIED_LIST_LENGTH})) \
						${VERIFIED_LIST[@]} 3>&1 1>&2 2>&3)
						then
							if mount_folder=$(dialog --title \
							"Where do you want to mount $shares ?" \
							--inputbox "" \
							6 80 "/armbian" 3>&1 1>&2 2>&3); then
								if mount_options=$(dialog --title \
								"Which mount options do you want to use?" \
							--inputbox "" \
							6 80 "auto,noatime 0 0" 3>&1 1>&2 2>&3); then
								mkdir -p ${mount_folder}
								sed -i '\?^'$nfs_server:$shares'?d' /etc/fstab
								echo "${nfs_server}:${shares} ${mount_folder} nfs ${mount_options}" >> /etc/fstab
								srv_daemon_reload
								mount ${mount_folder}
								show_message <<< $(mount -t nfs4 | cut -d" " -f1)
							fi
							fi
						fi
					fi
		;;
		"${commands[3]}")
			local list=($(mount --type=nfs4 | cut -d" " -f1))
			if shares=$(dialog --no-items \
						--title "Mounted NFS shares" \
						--menu "" \
						$((${#list[@]} + 6)) \
						80 \
						$((${#list[@]})) \
						${list[@]} 3>&1 1>&2 2>&3); then
						echo "Chosen $mount"
			read
			fi
		;;
		"${commands[4]}")
			echo -e "\nUsage: ${module_options["module_nfs,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_nfs,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tservers\t- Find and mount shares $title."
			echo
		;;
		*)
			${module_options["module_nfs,feature"]} ${commands[4]}
		;;
	esac
}

module_options+=(
	["module_zfs,author"]="@igorpecovnik"
	["module_zfs,maintainer"]="@igorpecovnik"
	["module_zfs,feature"]="module_zfs"
	["module_zfs,desc"]="Install ZFS filesystem support"
	["module_zfs,example"]="install remove status tune scan import kernel_max zfs_version zfs_installed_version help"
	["module_zfs,port"]=""
	["module_zfs,status"]="Active"
	["module_zfs,arch"]="x86-64 arm64"
	["module_zfs,doc_link"]="https://openzfs.github.io/openzfs-docs/"
	["module_zfs,group"]="System"
	["module_zfs,config_file"]="/etc/modprobe.d/zfs.conf"
	# Custom command help descriptions
	["module_zfs,help_tune"]="Fine-tune ZFS performance parameters (ARC, dirty data, TXG, compression)"
	["module_zfs,help_scan"]="Scan for ZFS pools that can be imported"
	["module_zfs,help_import"]="Import a selected ZFS pool with optional alternate mount point"
	["module_zfs,help_kernel_max"]="Determine maximum supported kernel version for ZFS"
	["module_zfs,help_zfs_version"]="Get ZFS version from DKMS"
	["module_zfs,help_zfs_installed_version"]="Read installed ZFS version"
)
#
# Module OpenZFS
#
function module_zfs () {
	local title="zfs"

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_zfs,example"]}"

	case "$1" in
		"${commands[0]}") # install
			# Check if the module is already installed
			if pkg_installed zfsutils-linux; then
				echo "ZFS is already installed."
				return 0
			fi

			# Headers are needed, install them if not already present
			if ! module_headers status >/dev/null 2>&1; then
				echo "Installing kernel headers (required for ZFS)..."
				module_headers install
			fi

			echo "Installing ZFS packages..."
			# Suppress DKMS license prompt during ZFS compilation
			pkg_install zfsutils-linux zfs-dkms || return 1
		;;
		"${commands[1]}") # remove
			echo "Removing ZFS packages..."
			pkg_remove zfsutils-linux zfs-dkms
			# Note: We don't remove kernel headers as they may be needed by other modules
		;;
		"${commands[2]}") # status
			if pkg_installed zfsutils-linux; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}") # tune
			# Check if ZFS is installed
			if ! pkg_installed zfsutils-linux; then
				dialog_msgbox "ZFS Not Installed" \
					"ZFS is not installed. Please install ZFS first before tuning parameters."
				return 1
			fi

			# Check if ZFS module is loaded
			if ! lsmod | grep -q "^zfs "; then
				dialog_msgbox "ZFS Not Loaded" \
					"ZFS kernel module is not loaded. Loading module now..."
				modprobe zfs 2>/dev/null || {
					dialog_msgbox "Failed to Load ZFS" \
						"Failed to load ZFS kernel module. Please check your installation."
					return 1
				}
			fi

			local config_file="${module_options["module_zfs,config_file"]}"
			local backup_file="${config_file}.bak"

			# Get current system memory in MB
			local total_mem_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
			local total_mem_mb=$((total_mem_kb / 1024))
			local total_mem_gb=$((total_mem_mb / 1024))

			# Calculate recommended values based on system memory
			local recommended_arc_min=$((total_mem_mb / 8))
			local recommended_arc_max=$((total_mem_mb / 2))
			local recommended_dirty=$((total_mem_mb / 25))  # 4% of RAM

			# Get current ARC settings
			local arc_min_current=$(cat /sys/module/zfs/parameters/zfs_arc_min 2>/dev/null || echo "0")
			local arc_max_current=$(cat /sys/module/zfs/parameters/zfs_arc_max 2>/dev/null || echo "0")
			local arc_min_mb=$((arc_min_current / 1024 / 1024))
			local arc_max_mb=$((arc_max_current / 1024 / 1024))

			# Convert to readable format
			local arc_max_display="${arc_max_mb} MB"
			if [[ $arc_max_mb -eq 0 ]]; then
				arc_max_display="Default (all RAM)"
			fi

			# Get current dirty data settings
			local dirty_max_current=$(cat /sys/module/zfs/parameters/zfs_dirty_data_max 2>/dev/null || echo "0")
			local dirty_max_mb=$((dirty_max_current / 1024 / 1024))

			# Get TXG timeout
			local txg_timeout=$(cat /sys/module/zfs/parameters/zfs_txg_timeout 2>/dev/null || echo "5")

			# Create tuning menu
			while true; do
				local menu_text="System Memory: ${total_mem_mb} MB (${total_mem_gb} GB)\n\n"
				menu_text+="Current Settings:\n"
				menu_text+="ARC Min: ${arc_min_mb} MB\n"
				menu_text+="ARC Max: ${arc_max_display}\n"
				menu_text+="Dirty Data Max: ${dirty_max_mb} MB\n"
				menu_text+="TXG Timeout: ${txg_timeout} sec\n\n"
				menu_text+="Select a parameter to tune:"

				local choice=$(dialog_menu "ZFS Performance Tuning" "$menu_text" 23 80 7 \
					"1" "ARC Cache Size (zfs_arc_min/max)" \
					"2" "Dirty Data Limits (zfs_dirty_data_max)" \
					"3" "TXG Timeout (zfs_txg_timeout)" \
					"4" "Advanced Settings" \
					"5" "Reset to Defaults" \
					"6" "Save & Apply Configuration" \
					"7" "Show Current Configuration")

				[[ -z "$choice" ]] && break

				case $choice in
					1) # ARC Cache Size Tuning
						dialog_msgbox "ARC Cache Size Tuning" \
							"The ARC (Adaptive Replacement Cache) is ZFS's intelligent cache.\n\nRecommended Settings:\n- zfs_arc_min: ${recommended_arc_min} MB (1/8 of RAM)\n- zfs_arc_max: ${recommended_arc_max} MB (1/2 of RAM)\n\nCurrent: ${arc_min_mb} MB / ${arc_max_display}" 16 80

						local new_arc_min_mb=$(dialog_inputbox "ARC Min Size" \
							"Enter ARC Min Size in MB:\n\n  Recommended: ${recommended_arc_min} MB\n  Existing value: ${arc_min_mb} MB\n\nPress OK to accept or change value:" \
							"${arc_min_mb}" 11 70)
						[[ -z "$new_arc_min_mb" ]] && continue

						# Validate numeric input
						if ! [[ "$new_arc_min_mb" =~ ^[0-9]+$ ]]; then
							dialog_msgbox "Invalid Input" "ARC Min must be a positive number!" 8 60
							continue
						fi

						local new_arc_max_mb=$(dialog_inputbox "ARC Max Size" \
							"Enter ARC Max Size in MB:\n\n  Recommended: ${recommended_arc_max} MB (0 = all RAM)\n  Existing value: ${arc_max_mb} MB\n\nPress OK to accept or change value:" \
							"${arc_max_mb}" 11 70)
						[[ -z "$new_arc_max_mb" ]] && continue

						# Validate numeric input
						if ! [[ "$new_arc_max_mb" =~ ^[0-9]+$ ]]; then
							dialog_msgbox "Invalid Input" "ARC Max must be a positive number (or 0)!" 8 60
							continue
						fi

						# Validate relationship
						if [[ $new_arc_min_mb -gt $new_arc_max_mb ]] && [[ $new_arc_max_mb -ne 0 ]]; then
							dialog_msgbox "Invalid Values" "ARC Min cannot be greater than ARC Max!" 10 65
							continue
						fi

						arc_min_mb=$new_arc_min_mb
						arc_max_mb=$new_arc_max_mb

						# Update display
						arc_max_display="${arc_max_mb} MB"
						[[ $arc_max_mb -eq 0 ]] && arc_max_display="Default (all RAM)"

						dialog_msgbox "Values Updated" "ARC settings updated.\n\nApply changes to take effect." 10 65
						;;

					2) # Dirty Data Limits
						dialog_msgbox "Dirty Data Limits" \
							"Dirty data is data that has been changed but not yet written to disk.\n\nRecommended: ${recommended_dirty} MB (4% of RAM)\n\nHigher values = better performance but more data loss risk on power failure." 14 75

						local new_dirty_max_mb=$(dialog_inputbox "Dirty Data Max" \
							"Enter Dirty Data Max in MB:\n\n  Recommended: ${recommended_dirty} MB\n  Existing value: ${dirty_max_mb} MB\n\nPress OK to accept or change value:" \
							"${dirty_max_mb}" 11 70)
						[[ -z "$new_dirty_max_mb" ]] && continue

						# Validate numeric input
						if ! [[ "$new_dirty_max_mb" =~ ^[0-9]+$ ]]; then
							dialog_msgbox "Invalid Input" "Dirty Data Max must be a positive number!" 8 60
							continue
						fi

						dirty_max_mb=$new_dirty_max_mb

						dialog_msgbox "Value Updated" "Dirty data max updated.\n\nApply changes to take effect." 10 65
						;;

					3) # TXG Timeout
						dialog_msgbox "TXG (Transaction Group) Timeout" \
							"Controls how often ZFS writes dirty data to disk.\n\nDefault: 5 seconds\n\nLower values = more frequent writes, better data safety, lower performance\nHigher values = less frequent writes, better performance, more data loss risk" 15 75

						local new_txg_timeout=$(dialog_inputbox "TXG Timeout" \
							"Enter TXG Timeout in seconds (1-30):\n\n  Recommended: 5 seconds\n  Existing value: ${txg_timeout} seconds\n\nPress OK to accept or change value:" \
							"${txg_timeout}" 11 70)
						[[ -z "$new_txg_timeout" ]] && continue

						# Validate numeric input
						if ! [[ "$new_txg_timeout" =~ ^[0-9]+$ ]]; then
							dialog_msgbox "Invalid Input" "TXG timeout must be a positive number!" 8 60
							continue
						fi

						# Validate range
						if [[ $new_txg_timeout -lt 1 ]] || [[ $new_txg_timeout -gt 30 ]]; then
							dialog_msgbox "Invalid Value" "TXG timeout must be between 1 and 30 seconds!" 10 65
							continue
						fi

						txg_timeout=$new_txg_timeout

						dialog_msgbox "Value Updated" "TXG timeout updated.\n\nApply changes to take effect." 10 65
						;;

					4) # Advanced Settings
						local adv_choice=$(dialog_menu "Advanced ZFS Tuning" \
							"WARNING: Only change these if you know what you're doing!" 20 80 6 \
							"1" "Prefetch Settings" \
							"2" "Sync Settings" \
							"3" "VDEV Settings" \
							"4" "Debug & Logging" \
							"5" "View Current module parameters" \
							"6" "Back")

						[[ -z "$adv_choice" ]] && continue

						case $adv_choice in
							1)
								local prefetch_current=$(cat /sys/module/zfs/parameters/zfs_prefetch_disable 2>/dev/null || echo "0")
								local prefetch_status="Enabled"
								[[ $prefetch_current -eq 1 ]] && prefetch_status="Disabled"

								if dialog_yesno "Disable ZFS Prefetch?" \
									"Current: ${prefetch_status}\n\nDisabling can help with certain workloads but usually hurts performance.\n\nDisable prefetch?"; then
									dialog_msgbox "Info" "Prefetch settings can be manually added to the config.\n\nEdit: ${config_file}\n\nAdd: options zfs zfs_prefetch_disable=1" 13 75
								else
									dialog_msgbox "Info" "Prefetch will remain enabled.\n\nCurrent default: enabled" 11 70
								fi
								;;
							2)
								dialog_msgbox "Sync Settings" \
									"zfs_sync_taskq_batch_pct controls sync task batching.\n\nDefault: Auto-tuned\n\nIncreasing can improve sync-heavy workloads (databases).\n\nCan be manually set in: ${config_file}" 13 70
								;;
							3)
								dialog_msgbox "VDEV Settings" \
									"zfs_vdev_* parameters control VDEV behavior.\n\nMost are auto-tuned. Manual tuning rarely needed.\n\nCommon parameters:\n- zfs_vdev_async_write_min_active\n- zfs_vdev_max_active\n- zfs_vdev_open_max_ms" 14 70
								;;
							4)
								dialog_msgbox "Debug & Logging" \
									"zfs_deadman_enabled, zfs_flags, etc.\n\nOnly enable for debugging purposes.\n\nWARNING: Can significantly impact performance.\n\nAdd to config manually if needed." 13 70
								;;
							5)
								if [[ -d /sys/module/zfs/parameters ]]; then
									local params_text="Current ZFS module parameters:\n\n"
									# Use ls to get parameter files safely
									for param_file in /sys/module/zfs/parameters/*; do
										if [[ -f "$param_file" ]]; then
											local name=$(basename "$param_file")
											local value
											value=$(cat "$param_file" 2>/dev/null || echo "N/A")
											# Truncate long values for display
											if [[ ${#value} -gt 50 ]]; then
												value="${value:0:47}..."
											fi
											params_text+="${name} = ${value}\n"
										fi
									done
									# Count total parameters
									local param_count=$(ls -1 /sys/module/zfs/parameters/* 2>/dev/null | wc -l)
									params_text+="\nTotal: ${param_count} parameters"
									dialog_msgbox "ZFS Module Parameters" "$params_text" 20 75
								else
									dialog_msgbox "Not Available" "ZFS module parameters not available.\n\nEnsure ZFS module is loaded."
								fi
								;;
						esac
						;;

					5) # Reset to defaults
						if dialog_yesno "Reset to Defaults" \
							"Reset all ZFS parameters to defaults?\n\nThis will remove any custom tuning."; then
							arc_min_mb=0
							arc_max_mb=0
							dirty_max_mb=$recommended_dirty
							txg_timeout=5
							# Update display
							arc_max_display="Default (all RAM)"
							dialog_msgbox "Reset Complete" "Parameters reset to defaults.\n\nApply changes to take effect." 11 70
						fi
						;;

					6) # Save & Apply
						local config_preview="The following settings will be saved to:\n${config_file}\n\n"
						if [[ $arc_min_mb -gt 0 ]]; then
							config_preview+="zfs_arc_min=$((arc_min_mb * 1024 * 1024)) bytes\n"
						fi
						if [[ $arc_max_mb -gt 0 ]]; then
							config_preview+="zfs_arc_max=$((arc_max_mb * 1024 * 1024)) bytes\n"
						else
							config_preview+="# zfs_arc_max=0  (use all RAM, default)\n"
						fi
						config_preview+="zfs_dirty_data_max=$((dirty_max_mb * 1024 * 1024)) bytes\n"
						config_preview+="zfs_txg_timeout=${txg_timeout} seconds\n"

						dialog_msgbox "Saving ZFS Configuration" "$config_preview"

						# Backup existing config if it exists
						if [[ -f "$config_file" ]]; then
							cp "$config_file" "$backup_file" || {
								dialog_msgbox "Backup Failed" "Failed to backup existing configuration.\n\nContinuing without backup."
							}
						fi

						# Build configuration file
						{
							echo "# ZFS Performance Tuning Configuration"
							echo "# Generated by Armbian config on $(date)"
							echo ""
							echo "# ARC Cache Settings"
							if [[ $arc_min_mb -gt 0 ]]; then
								echo "options zfs zfs_arc_min=$((arc_min_mb * 1024 * 1024))"
							fi
							if [[ $arc_max_mb -gt 0 ]]; then
								echo "options zfs zfs_arc_max=$((arc_max_mb * 1024 * 1024))"
							else
								echo "# options zfs zfs_arc_max=0  # 0 = use all RAM (default)"
							fi
							echo ""
							echo "# Dirty Data Settings"
							echo "options zfs zfs_dirty_data_max=$((dirty_max_mb * 1024 * 1024))"
							echo ""
							echo "# Transaction Group Settings"
							echo "options zfs zfs_txg_timeout=${txg_timeout}"
						} > "$config_file"

						# Notify about backup
						if [[ -f "$backup_file" ]]; then
							dialog_msgbox "Configuration Saved" \
								"Configuration saved successfully.\n\nPrevious configuration backed up to:\n${backup_file}\n\nYou can restore it manually if needed." 12 70
						fi

						# Apply changes
						dialog_msgbox "Applying Changes" \
							"Configuration saved.\n\nTo apply changes, ZFS module must be reloaded.\n\nThis requires either:\n1. Reboot\n2. Manual: rmmod zfs && modprobe zfs\n\nWARNING: Unloading ZFS requires exporting all pools first." 16 75

						if dialog_yesno "Reload ZFS Module" \
							"WARNING: All ZFS pools must be exported first!\n\nContinue?"; then
							if [[ -n "$(zpool list -H 2>/dev/null)" ]]; then
								dialog_msgbox "Cannot Reload" \
									"ZFS pools are imported.\n\nPlease export all pools first:\nzpool export -a" 11 70
							else
								# Try to unload ZFS module
								if rmmod zfs 2>/dev/null; then
									# rmmod succeeded, now try to load ZFS module
									if modprobe zfs 2>/dev/null; then
										# Success
										dialog_msgbox "Success" \
											"ZFS module reloaded successfully.\n\nNew settings are now active." 11 70
									else
										# modprobe failed - system without ZFS!
										# Try retry
										if modprobe zfs 2>/dev/null; then
											dialog_msgbox "Success" \
												"ZFS module reloaded after retry.\n\nNew settings are now active." 11 70
										else
											# Recovery failed - show dmesg and recovery instructions
											local dmesg_output
											dmesg_output=$(dmesg | tail -20 2>/dev/null || echo "Cannot retrieve dmesg output")
											dialog_msgbox "Critical Error" \
												"ZFS module unload succeeded but reload FAILED!\n\nSystem is running without ZFS support.\n\nLast dmesg entries:\n${dmesg_output}\n\nRecovery:\n1. Reboot to restore ZFS\n2. Or try manually: modprobe zfs" 18 75
										fi
									fi
								else
									# rmmod failed - module probably in use
									dialog_msgbox "Unload Failed" \
										"Failed to unload ZFS module.\n\nModule may be in use.\n\nTry rebooting to apply new settings." 11 70
								fi
							fi
						fi

						break
						;;

					7) # Show current configuration
						local show_text="Current ZFS Configuration:\n\n"
						if [[ $arc_min_mb -gt 0 ]]; then
							show_text+="ARC Min: ${arc_min_mb} MB ($((arc_min_mb * 1024 * 1024)) bytes)\n"
						else
							show_text+="ARC Min: (not set, using default)\n"
						fi
						if [[ $arc_max_mb -gt 0 ]]; then
							show_text+="ARC Max: ${arc_max_mb} MB ($((arc_max_mb * 1024 * 1024)) bytes)\n"
						else
							show_text+="ARC Max: (not set, will use all RAM)\n"
						fi
						show_text+="Dirty Data Max: ${dirty_max_mb} MB ($((dirty_max_mb * 1024 * 1024)) bytes)\n"
						show_text+="TXG Timeout: ${txg_timeout} seconds\n\n"
						show_text+="Configuration file: ${config_file}\n\n"
						if [[ -f "$config_file" ]]; then
							show_text+="Current file contents:\n\n"
							# Append file contents, converting actual newlines to \n escape sequences
							local file_contents
							file_contents=$(cat "$config_file" 2>/dev/null)
							if [[ -n "$file_contents" ]]; then
								while IFS= read -r line; do
									show_text+="${line}\\n"
								done <<< "$file_contents"
							fi
						else
							show_text+="(No custom configuration file yet)"
						fi
						dialog_msgbox "Current ZFS Configuration" "$show_text" 22 80
						;;
				esac
			done
			;;
		"${commands[4]}") # scan
			# Check if ZFS is installed
			if ! pkg_installed zfsutils-linux; then
				return 1
			fi

			# Check if ZFS module is loaded
			if ! lsmod | grep -q "^zfs "; then
				modprobe zfs 2>/dev/null || return 1
			fi

			# Get list of pools that can be imported
			pool_list=$(zpool import 2>/dev/null)

			if [[ -z "$pool_list" ]]; then
				return 1
			fi

			# Parse pool list to extract pool names and info
			declare -A pool_altroot  # Store original altroot for each pool
			pools=()
			current_pool=""
			while IFS= read -r line; do
				# Lines starting with "pool:" indicate pool names
				if [[ "$line" =~ ^[[:space:]]*pool:[[:space:]]+(.+)$ ]]; then
					current_pool="${BASH_REMATCH[1]}"
					pools+=("$current_pool")
					pool_altroot["$current_pool"]=""
				# Extract altroot if present
				elif [[ "$line" =~ ^[[:space:]]*altroot:[[:space:]]+(.+)$ ]]; then
					altroot_value="${BASH_REMATCH[1]}"
					# Clean up the altroot value
					altroot_value=$(echo "$altroot_value" | sed 's/[[:space:]]*$//')
					pool_altroot["$current_pool"]="$altroot_value"
				fi
			done <<< "$pool_list"
			if [[ ${#pools[@]} -eq 0 ]]; then
				return 1
				else
				export POOLS=${#pools[@]}
			fi
			;;
		"${commands[5]}") # import

			if ! ${module_options["module_zfs,feature"]} ${commands[4]}; then
				return 1
			fi

			# Show pool selection menu
			# Build radiolist arguments - pool names as both tag and description
			local radiolist_args=()
			for pool in "${pools[@]}"; do
				radiolist_args+=("$pool" "$pool" "off")
			done

			local selected_pool
			selected_pool=$(dialog_radiolist "Import ZFS Pool" \
				"Select a ZFS pool to import:\n\nFound ${#pools[@]} pool(s) available for import." \
				18 80 8 -- "${radiolist_args[@]}")

			if [[ -z "$selected_pool" ]]; then
				return 0
			fi

			# Ask for alternate mount point (optional)
			local alt_root=""
			if dialog_yesno "Alternate Mount Point" \
				"Import pool '${selected_pool}' at an alternate mount point?\n\n- Yes: Specify custom mount path\n- No: Use pool's original mount points" "Yes" "No" 10 70 --defaultno; then
				# User wants custom mount point
				alt_root=$(dialog_inputbox "Alternate Mount Point" \
					"Enter alternate root mount point:\n\nExample: /mnt/pool\n\nPool datasets will be mounted under this path." \
					"/mnt/${selected_pool}" 12 70)

				if [[ -n "$alt_root" ]]; then
					# Validate the path
					if [[ ! "$alt_root" =~ ^/ ]]; then
						dialog_msgbox "Invalid Path" \
							"Mount point must be an absolute path (starting with /)." 8 50
						return 1
					fi

					# Create the directory if it doesn't exist
					if [[ ! -d "$alt_root" ]]; then
						mkdir -p "$alt_root" 2>/dev/null || {
							dialog_msgbox "Cannot Create Directory" \
								"Failed to create directory: ${alt_root}\n\nCheck permissions and try again." 9 60
							return 1
						}
					fi
				fi
			fi

			# selected_pool contains the pool name directly from the radiolist

			# Confirm import
			local confirm_msg="Import pool '${selected_pool}'?"
			if [[ -n "$alt_root" ]]; then
				confirm_msg+="\n\nMount point: ${alt_root}"
			else
				confirm_msg+="\n\nMount point: Pool's original mount points"
			fi
			confirm_msg+="\n\nNote: Force import (-f) will be used to ensure pool can be imported."

			if dialog_yesno "Confirm Import" "$confirm_msg"; then
				# Import the pool with -f flag to force import
				# Use altroot if specified and different from original
				local import_output
				local original_altroot="${pool_altroot[$selected_pool]}"

				# Check if user-provided altroot matches the pool's original
				if [[ -n "$alt_root" && "$alt_root" == "$original_altroot" ]]; then
					# Altroot matches original - import without altroot parameter
					dialog_msgbox "Using Original Mount Point" \
						"The specified mount point matches the pool's original altroot.\n\nImporting with original mount points." 10 70
					alt_root=""
				fi

				if [[ -n "$alt_root" ]]; then
					import_output=$(zpool import -f -o altroot="$alt_root" "$selected_pool" 2>&1)
				else
					import_output=$(zpool import -f "$selected_pool" 2>&1)
				fi

				if [[ $? -eq 0 ]]; then
					dialog_msgbox "Import Successful" \
						"Pool '${selected_pool}' imported successfully!" 8 50
				else
					dialog_msgbox "Import Failed" \
						"Failed to import pool '${selected_pool}'.\n\nError:\n${import_output}\n\nCheck 'dmesg' for more details." 14 70
					return 1
				fi
			fi
			;;
		"${commands[6]}") # kernel_max
			echo "${ZFS_KERNEL_MAX:-<not set>}"
		;;
		"${commands[7]}") # zfs_version
			if [[ -n "${ZFS_DKMS_VERSION}" ]]; then
				echo "v${ZFS_DKMS_VERSION}"
			else
				echo "<version not available>"
			fi
		;;
		"${commands[8]}") # zfs_installed_version
			if pkg_installed zfsutils-linux; then
				zfs --version 2>/dev/null | head -1 | cut -d"-" -f2
			else
				echo "ZFS is not installed"
				return 1
			fi
		;;
		"${commands[9]}") # help
			show_module_help "module_zfs" "ZFS" "Configuration file: ${module_options["module_zfs,config_file"]}" "native"
		;;
		*) # default - show help
			${module_options["module_zfs,feature"]} ${commands[9]}
		;;
	esac
}

module_options+=(
	["toggle_ssh_lastlog,author"]="@Tearran"
	["toggle_ssh_lastlog,ref_link"]=""
	["toggle_ssh_lastlog,feature"]="toggle_ssh_lastlog"
	["toggle_ssh_lastlog,desc"]="Toggle SSH lastlog"
	["toggle_ssh_lastlog,example"]="toggle_ssh_lastlog"
	["toggle_ssh_lastlog,status"]="Active"
)
#
# @description Toggle SSH lastlog
#
function toggle_ssh_lastlog() {

	if ! grep -q '^#\?PrintLastLog ' "${SDCARD}/etc/ssh/sshd_config"; then
		# If PrintLastLog is not found, append it with the value 'yes'
		echo 'PrintLastLog no' >> "${SDCARD}/etc/ssh/sshd_config"
		srv_restart ssh
	else
		# If PrintLastLog is found, toggle between 'yes' and 'no'
		sed -i '/^#\?PrintLastLog /
{
	s/PrintLastLog yes/PrintLastLog no/;
	t;
	s/PrintLastLog no/PrintLastLog yes/
}' "${SDCARD}/etc/ssh/sshd_config"
		srv_restart ssh
	fi

}


