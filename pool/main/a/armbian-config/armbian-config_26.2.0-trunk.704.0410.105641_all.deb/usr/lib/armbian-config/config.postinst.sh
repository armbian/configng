#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi
#if [ -f /etc/lightdm/slick-greeter.conf ]; then sed -i 's/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg/armbian-4k-neon-gray-penguin-gauss.jpg/g' /etc/lightdm/slick-greeter.conf; fi

# disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i /etc/pulse/default.pa; fi

##dconf desktop settings
keys=/etc/dconf/db/local.d/00-desktop
profile=/etc/dconf/profile/user

install -Dv /dev/null $keys
install -Dv /dev/null $profile

# gather dconf settings
# deconf dump org/nemo/ > nemo_backup
# deconf dump org/cinnamon/ > cinnamon_desktop_backup

echo "[org/nemo/list-view]
default-visible-columns=['name', 'size', 'type', 'date_modified', 'owner', 'permissions']

[org/nemo/preferences]
quick-renames-with-pause-in-between=true
show-advanced-permissions=true
show-compact-view-icon-toolbar=false
show-full-path-titles=true
show-hidden-files=true
show-home-icon-toolbar=true
show-icon-view-icon-toolbar=false
show-image-thumbnails='never'
show-list-view-icon-toolbar=false
show-new-folder-icon-toolbar=true
show-open-in-terminal-toolbar=true

[org/nemo/window-state]
geometry='800x550+550+244'
maximized=false
sidebar-bookmark-breakpoint=5

[org/cinnamon]
desklet-decorations=0
desktop-effects=false
enabled-applets=['panel1:left:0:menu@cinnamon.org:0', 'panel1:left:1:show-desktop@cinnamon.org:1', 'panel1:left:2:grouped-window-list@cinnamon.org:2', 'panel1:right:0:systray@cinnamon.org:3', 'panel1:right:1:xapp-status@cinnamon.org:4', 'panel1:right:2:notifications@cinnamon.org:5', 'panel1:right:3:printers@cinnamon.org:6', 'panel1:right:4:removable-drives@cinnamon.org:7', 'panel1:right:5:keyboard@cinnamon.org:8', 'panel1:right:6:favorites@cinnamon.org:9', 'panel1:right:7:network@cinnamon.org:10', 'panel1:right:8:sound@cinnamon.org:11', 'panel1:right:9:power@cinnamon.org:12', 'panel1:right:10:calendar@cinnamon.org:13']
enabled-desklets=@as []
next-applet-id=14
panels-height=['1:33']
panels-resizable=['1:true']
startup-animation=false

[org/cinnamon/desktop/a11y/applications]
screen-keyboard-enabled=false
screen-reader-enabled=false

[org/cinnamon/desktop/a11y/mouse]
dwell-click-enabled=false
dwell-threshold=10
dwell-time=1.2
secondary-click-enabled=false
secondary-click-time=1.2

[org/cinnamon/desktop/background]
picture-options='zoom'
picture-uri='file:///usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
primary-color='#456789'
secondary-color='#FFFFFF'

[org/cinnamon/desktop/applications/terminal]
exec='/usr/bin/terminator'

[org/cinnamon/desktop/default-applications/terminal]
exec='/usr/bin/terminator'

[org/cinnamon/desktop/interface]
clock-show-date=true
cursor-theme='whiteglass'
gtk-theme='Numix'
icon-theme='Numix'
scaling-factor=uint32 0
toolkit-accessibility=false

[org/cinnamon/desktop/media-handling]
autorun-never=false

[org/cinnamon/desktop/screensaver]
picture-options='zoom'
picture-uri='file:///usr/share/backgrounds/armbian-lightdm/armbian03-Dre0x-Minum-dark-3840x2160'
primary-color='#456789'
secondary-color='#FFFFFF'

[org/cinnamon/desktop/wm/preferences]
num-workspaces=2
theme='Numix'

[org/cinnamon/settings-daemon/peripherals/touchpad]
disable-while-typing=true
horiz-scroll-enabled=false
motion-acceleration=5.4820717131474108
motion-threshold=2
natural-scroll=false
scroll-method='two-finger-scrolling'
three-finger-click=2
two-finger-click=3

[org/cinnamon/settings-daemon/plugins/power]
button-power='interactive'
critical-battery-action='hibernate'
idle-brightness=30
idle-dim-time=90
lid-close-ac-action='nothing'
lid-close-battery-action='nothing'
sleep-display-ac=600
sleep-display-battery=600
sleep-inactive-ac-timeout=0
sleep-inactive-battery-timeout=0

[org/cinnamon/settings-daemon/plugins/xsettings]
buttons-have-icons=true
menus-have-icons=true

[org/cinnamon/sounds]
login-enabled=false
logout-enabled=false
plug-enabled=false
switch-enabled=false
tile-enabled=false
unplug-enabled=false" >> $keys

echo "user-db:user
system-db:local" >> $profile

dconf update

# Let NetworkManager coexist with systemd-networkd (only if networkd is active)
if command -v NetworkManager > /dev/null 2>&1 && systemctl is-active --quiet systemd-networkd 2>/dev/null; then
	mkdir -p /etc/NetworkManager/conf.d
	cat > /etc/NetworkManager/conf.d/10-armbian-unmanaged.conf <<- NMEOF
	[keyfile]
	unmanaged-devices=type:ethernet
	NMEOF
	systemctl restart NetworkManager 2>/dev/null || true
fi

#re-compile schemas
if [ -d /usr/share/glib-2.0/schemas ]; then glib-compile-schemas /usr/share/glib-2.0/schemas; fi

#!/bin/bash
set +e

# Configure SDDM theme and wallpaper
# plasma-chili only works with X11 greeter (Ubuntu), skip on Wayland greeter (Trixie)
if [ -d /usr/share/sddm/themes/plasma-chili ] && [ -f /etc/sddm.conf ]; then
	# Ubuntu: has /etc/sddm.conf, uses X11 greeter
	cp /usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg \
		/usr/share/sddm/themes/plasma-chili/components/artwork/background.jpg 2>/dev/null || true
	if grep -q '^Current=' /etc/sddm.conf; then
		sed -i 's/^Current=.*/Current=plasma-chili/' /etc/sddm.conf
	else
		sed -i '/^\[Theme\]/a Current=plasma-chili' /etc/sddm.conf
	fi
fi

# Set Armbian wallpaper for skel and users without existing config
for home in /etc/skel /home/*; do
	[ -d "$home" ] || continue
	# skip if user already has a Plasma config
	[ "$home" != "/etc/skel" ] && [ -f "$home/.config/plasma-org.kde.plasma.desktop-appletsrc" ] && continue
	mkdir -p "$home/.config"
	cat > "$home/.config/plasma-org.kde.plasma.desktop-appletsrc" <<- 'PLASMAEOF'
	[Containments][1]
	activityId=
	formfactor=0
	immutability=1
	lastScreen=0
	location=0
	plugin=org.kde.desktopcontainment
	wallpaperplugin=org.kde.image

	[Containments][1][Wallpaper][org.kde.image][General]
	Image=file:///usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg
	FillMode=1
	PLASMAEOF
	# fix ownership for real users
	if [ "$home" != "/etc/skel" ]; then
		user=$(basename "$home")
		chown "$user:$user" "$home/.config/plasma-org.kde.plasma.desktop-appletsrc" 2>/dev/null
	fi
done

# Let NetworkManager coexist with systemd-networkd (only if networkd is active)
if command -v NetworkManager > /dev/null 2>&1 && systemctl is-active --quiet systemd-networkd 2>/dev/null; then
	mkdir -p /etc/NetworkManager/conf.d
	cat > /etc/NetworkManager/conf.d/10-armbian-unmanaged.conf <<- NMEOF
	[keyfile]
	unmanaged-devices=type:ethernet
	NMEOF
	systemctl restart NetworkManager 2>/dev/null || true
fi

#!/bin/bash
set +e

# Configure SDDM theme and wallpaper
# plasma-chili only works with X11 greeter (Ubuntu), skip on Wayland greeter (Trixie)
if [ -d /usr/share/sddm/themes/plasma-chili ] && [ -f /etc/sddm.conf ]; then
	# Ubuntu: has /etc/sddm.conf, uses X11 greeter
	cp /usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg \
		/usr/share/sddm/themes/plasma-chili/components/artwork/background.jpg 2>/dev/null || true
	if grep -q '^Current=' /etc/sddm.conf; then
		sed -i 's/^Current=.*/Current=plasma-chili/' /etc/sddm.conf
	else
		sed -i '/^\[Theme\]/a Current=plasma-chili' /etc/sddm.conf
	fi
fi

# Set Armbian wallpaper for skel and users without existing config
for home in /etc/skel /home/*; do
	[ -d "$home" ] || continue
	# skip if user already has a Plasma config
	[ "$home" != "/etc/skel" ] && [ -f "$home/.config/plasma-org.kde.plasma.desktop-appletsrc" ] && continue
	mkdir -p "$home/.config"
	cat > "$home/.config/plasma-org.kde.plasma.desktop-appletsrc" <<- 'PLASMAEOF'
	[Containments][1]
	activityId=
	formfactor=0
	immutability=1
	lastScreen=0
	location=0
	plugin=org.kde.desktopcontainment
	wallpaperplugin=org.kde.image

	[Containments][1][Wallpaper][org.kde.image][General]
	Image=file:///usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg
	FillMode=1
	PLASMAEOF
	# fix ownership for real users
	if [ "$home" != "/etc/skel" ]; then
		user=$(basename "$home")
		chown "$user:$user" "$home/.config/plasma-org.kde.plasma.desktop-appletsrc" 2>/dev/null
	fi
done

# Let NetworkManager coexist with systemd-networkd (only if networkd is active)
if command -v NetworkManager > /dev/null 2>&1 && systemctl is-active --quiet systemd-networkd 2>/dev/null; then
	mkdir -p /etc/NetworkManager/conf.d
	cat > /etc/NetworkManager/conf.d/10-armbian-unmanaged.conf <<- NMEOF
	[keyfile]
	unmanaged-devices=type:ethernet
	NMEOF
	systemctl restart NetworkManager 2>/dev/null || true
fi

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi


#Adjust xsettings.xml for NumixBlue Theme Ubuntu
if [ -f /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml ]; then sed -i 's/Xfce-dusk/NumixBlue/g' /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml; fi

# Adjust menu
if [ -f /etc/xdg/menus/xfce-applications.menu ]; then
sed -i -n '/<Menuname>Settings<\/Menuname>/{p;:a;N;/<Filename>xfce4-session-logout.desktop<\/Filename>/!ba;s/.*\n/\
\t<Separator\/>\n\t<Merge type="all"\/>\n        <Separator\/>\n        <Filename>armbian-donate.desktop<\/Filename>\
\n        <Filename>armbian-support.desktop<\/Filename>\n/};p' /etc/xdg/menus/xfce-applications.menu
fi

# Hide few items
if [ -f /usr/share/applications/display-im6.q16.desktop ]; then mv /usr/share/applications/display-im6.q16.desktop /usr/share/applications/display-im6.q16.desktop.hidden; fi
if [ -f /usr/share/applications/display-im6.desktop ]; then  mv /usr/share/applications/display-im6.desktop /usr/share/applications/display-im6.desktop.hidden; fi
if [ -f /usr/share/applications/vim.desktop ]; then  mv /usr/share/applications/vim.desktop /usr/share/applications/vim.desktop.hidden; fi
if [ -f /usr/share/applications/libreoffice-startcenter.desktop ]; then mv /usr/share/applications/libreoffice-startcenter.desktop /usr/share/applications/libreoffice-startcenter.desktop.hidden; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i  /etc/pulse/default.pa; fi

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi
if [ -f /etc/lightdm/slick-greeter.conf ]; then sed -i 's/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg/armbian-4k-blue-circle-gauss.jpg/g' /etc/lightdm/slick-greeter.conf; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i  /etc/pulse/default.pa; fi

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi

# disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i /etc/pulse/default.pa; fi

##dconf desktop settings
keys=/etc/dconf/db/local.d/00-desktop
profile=/etc/dconf/profile/user

install -Dv /dev/null $keys
install -Dv /dev/null $profile

echo "[org/mate/desktop/background]
picture-options='zoom'
picture-uri='file:///usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
primary-color='#456789'
secondary-color='#FFFFFF'

[org/mate/desktop/applications/terminal]
exec='/usr/bin/terminator'

[org/mate/desktop/default-applications/terminal]
exec='/usr/bin/terminator'

[org/mate/desktop/interface]
clock-show-date=true
cursor-theme='DMZ-White'
gtk-theme='Numix'
icon-theme='Numix'
scaling-factor=uint32 0
toolkit-accessibility=false

[org/mate/desktop/screensaver]
picture-options='zoom'
picture-uri='file:///usr/share/backgrounds/armbian-lightdm/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg'
primary-color='#456789'
secondary-color='#FFFFFF'

[org/mate/desktop/wm/preferences]
num-workspaces=2
theme='Numix'

[org/mate/settings-daemon/plugins/power]
button-power='interactive'
lid-close-ac-action='nothing'
lid-close-battery-action='nothing'
sleep-inactive-ac-timeout=0
sleep-inactive-battery-timeout=0

[org/mate/settings-daemon/plugins/xsettings]
buttons-have-icons=true
menus-have-icons=true

[org/mate/sounds]
login-enabled=false
logout-enabled=false
plug-enabled=false
switch-enabled=false
tile-enabled=false
unplug-enabled=false

[org/mate/panel/general]
object-id-list=['menu-bar', 'notification-area', 'clock', 'show-desktop-button', 'window-list', 'workspace-switcher']
toplevel-id-list=['top', 'bottom']

[org/mate/panel/toplevels/top]
expand=true
orientation='top'
size=24

[org/mate/panel/toplevels/bottom]
expand=true
orientation='bottom'
size=24

[org/mate/panel/objects/menu-bar]
locked=true
toplevel-id='top'
position=0
object-type='menu-bar'

[org/mate/panel/objects/notification-area]
locked=true
toplevel-id='top'
position=10
panel-right-stick=true
object-type='applet'
applet-iid='NotificationAreaAppletFactory::NotificationArea'

[org/mate/panel/objects/clock]
locked=true
toplevel-id='top'
position=0
panel-right-stick=true
object-type='applet'
applet-iid='ClockAppletFactory::ClockApplet'

[org/mate/panel/objects/show-desktop-button]
locked=true
toplevel-id='bottom'
position=0
object-type='applet'
applet-iid='WnckletFactory::ShowDesktopApplet'

[org/mate/panel/objects/window-list]
locked=true
toplevel-id='bottom'
position=1
object-type='applet'
applet-iid='WnckletFactory::WindowListApplet'

[org/mate/panel/objects/workspace-switcher]
locked=true
toplevel-id='bottom'
position=0
panel-right-stick=true
object-type='applet'
applet-iid='WnckletFactory::WorkspaceSwitcherApplet'" >> $keys

echo "user-db:user
system-db:local" >> $profile

dconf update

# System dconf database + gsettings schema override handle defaults
# for both new and existing users without touching user databases

# Override MATE default schema for wallpaper
mkdir -p /usr/share/glib-2.0/schemas
cat > /usr/share/glib-2.0/schemas/90-armbian-mate.gschema.override <<- 'GSEOF'
[org.mate.background]
picture-filename='/usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
picture-options='zoom'
primary-color='#456789'

[org.mate.interface]
gtk-theme='Numix'
icon-theme='Numix'

[org.mate.Marco.general]
theme='Numix'
num-workspaces=2

[org.mate.caja.desktop]
home-icon-visible=false
computer-icon-visible=false
trash-icon-visible=false
volumes-visible=false
GSEOF

# Let NetworkManager coexist with systemd-networkd (only if networkd is active)
if command -v NetworkManager > /dev/null 2>&1 && systemctl is-active --quiet systemd-networkd 2>/dev/null; then
	mkdir -p /etc/NetworkManager/conf.d
	cat > /etc/NetworkManager/conf.d/10-armbian-unmanaged.conf <<- NMEOF
	[keyfile]
	unmanaged-devices=type:ethernet
	NMEOF
	systemctl restart NetworkManager 2>/dev/null || true
fi

#re-compile schemas
if [ -d /usr/share/glib-2.0/schemas ]; then glib-compile-schemas /usr/share/glib-2.0/schemas; fi

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi
#if [ -f /etc/lightdm/slick-greeter.conf ]; then sed -i 's/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg/armbian-4k-purplepunk-gauss.jpg/g' /etc/lightdm/slick-greeter.conf; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i /etc/pulse/default.pa; fi

##dconf desktop settings
keys=/etc/dconf/db/local.d/00-desktop
profile=/etc/dconf/profile/user

install -Dv /dev/null $keys
install -Dv /dev/null $profile

# gather dconf settings
# deconf dump org/nemo/ > nemo_backup
# deconf dump org/budgie/ > budgie_desktop_backup

echo "[org/nemo/desktop]
desktop-layout='true::false'
font='Noto Sans UI 11'

[org/nemo/list-view]
default-visible-columns=['name', 'size', 'type', 'date_modified', 'owner', 'permissions']

[org/nemo/preferences]
quick-renames-with-pause-in-between=true
show-advanced-permissions=true
show-compact-view-icon-toolbar=false
show-full-path-titles=true
show-hidden-files=true
show-home-icon-toolbar=true
show-icon-view-icon-toolbar=false
show-image-thumbnails='never'
show-list-view-icon-toolbar=false
show-new-folder-icon-toolbar=true
show-open-in-terminal-toolbar=true

[org/nemo/window-state]
geometry='800x550+550+244'
maximized=false
sidebar-bookmark-breakpoint=5

[org/gnome/desktop/background]
color-shading-type='solid'
picture-options='stretched'
picture-uri='file:////usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
primary-color='#008094'

[org/gnome/settings-daemon/plugins/power]
sleep-inactive-ac-timeout='0'

[org/gnome/desktop/interface]
cursor-theme='DMZ-White'
document-font-name='Noto Sans UI 11'
font-name='Noto Sans UI 11'
gtk-im-module='gtk-im-context-simple'
gtk-theme='Numix'
icon-theme='LoginIcons'
monospace-font-name='Noto Mono 11'
toolkit-accessibility=false

[org/gnome/desktop/screensaver]
picture-uri='file:///usr/share/backgrounds/armbian-lightdm/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg'

[org/cinnamon/desktop/applications/terminal]
exec='/usr/bin/terminator'

[org/cinnamon/desktop/default-applications/terminal]
exec='/usr/bin/terminator'

[org/gnome/desktop/wm/preferences]
button-layout='appmenu:minimize,maximize,close'
num-workspaces=2
theme='Plata-Compact'
titlebar-font='Noto Sans UI Bold 11'

[org/ubuntubudgie/budgie-wpreviews]
allworkspaces=true
enable-previews=true" >> $keys

echo "user-db:user
system-db:local" >> $profile

dconf update

#re-compile schemas
if [ -d /usr/share/glib-2.0/schemas ]; then glib-compile-schemas /usr/share/glib-2.0/schemas; fi

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i  /etc/pulse/default.pa; fi

# set wallpapper to armbian



#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi
#if [ -f /etc/lightdm/slick-greeter.conf ]; then sed -i 's/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg/armbian-4k-neglated-gauss.jpg/g' /etc/lightdm/slick-greeter.conf; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i  /etc/pulse/default.pa; fi

#remove linked file
rm /etc/alternatives/deepin-default-background
ln -s /usr/share/backgrounds/armbian/armbian-4k-neglated.jpg /etc/alternatives/deepin-default-background

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi
#if [ -f /etc/lightdm/slick-greeter.conf ]; then sed -i 's/armbian03-Dre0x-Minum-dark-blurred-3840x2160.jpg/armbian-4k-black-psycho-gauss.jpg/g' /etc/lightdm/slick-greeter.conf; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i  /etc/pulse/default.pa; fi

# set wallpapper to armbian
keys=/etc/dconf/db/local.d/00-bg
profile=/etc/dconf/profile/user

install -Dv /dev/null $keys
install -Dv /dev/null $profile

# set default shortcuts
echo "
[org/gnome/shell]
favorite-apps = ['terminator.desktop', 'org.gnome.Nautilus.desktop', 'armbian-imager.desktop']

[org/gnome/settings-daemon/plugins/power]
sleep-inactive-ac-timeout='0'

[org/gnome/desktop/background]
picture-uri='file:///usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
picture-options='zoom'
primary-color='#456789'
secondary-color='#FFFFFF'

[org/gnome/desktop/screensaver]
picture-uri='file:///usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg'
picture-options='zoom'
primary-color='#456789'
secondary-color='#FFFFFF'" >> $keys

echo "user-db:user
system-db:local" >> $profile

dconf update

# Let NetworkManager coexist with systemd-networkd (only if networkd is active)
if command -v NetworkManager > /dev/null 2>&1 && systemctl is-active --quiet systemd-networkd 2>/dev/null; then
	mkdir -p /etc/NetworkManager/conf.d
	cat > /etc/NetworkManager/conf.d/10-armbian-unmanaged.conf <<- NMEOF
	[keyfile]
	unmanaged-devices=type:ethernet
	NMEOF
	systemctl restart NetworkManager 2>/dev/null || true
fi

#compile schemas
if [ -d /usr/share/glib-2.0/schemas ]; then
	glib-compile-schemas /usr/share/glib-2.0/schemas
fi

#!/bin/bash
set +e
# overwrite stock lightdm greeter configuration
if [ -d /etc/armbian/lightdm ]; then cp -R /etc/armbian/lightdm /etc/; fi

# Disable Pulseaudio timer scheduling which does not work with sndhdmi driver
if [ -f /etc/pulse/default.pa ]; then sed "s/load-module module-udev-detect$/& tsched=0/g" -i /etc/pulse/default.pa; fi

# create i3 session file for LightDM
mkdir -p /usr/share/xsessions
if [ ! -f /usr/share/xsessions/i3.desktop ]; then
	cat > /usr/share/xsessions/i3.desktop <<- 'XSEOF'
	[Desktop Entry]
	Name=i3
	Comment=Improved tiling window manager
	Exec=/etc/X11/Xsession i3
	Type=Application
	XSEOF
fi

# set wallpaper and startup apps in i3 config
if [ -f /etc/i3/config ]; then
	# wallpaper
	grep -q "feh --bg-scale" /etc/i3/config || \
		echo "exec_always --no-startup-id feh --bg-scale /usr/share/backgrounds/armbian/armbian03-Dre0x-Minum-dark-3840x2160.jpg" >> /etc/i3/config
	# use terminator instead of default terminal
	sed -i 's/i3-sensible-terminal/terminator/g' /etc/i3/config
	# start nm-applet
	grep -q "nm-applet" /etc/i3/config || \
		echo "exec --no-startup-id nm-applet" >> /etc/i3/config
	# start dunst
	grep -q "dunst" /etc/i3/config || \
		echo "exec --no-startup-id dunst" >> /etc/i3/config

	# copy patched config to skel so users don't get the first-run wizard
	mkdir -p /etc/skel/.config/i3
	cp /etc/i3/config /etc/skel/.config/i3/config

	# also copy to existing users
	for home in /home/*; do
		user=$(basename "$home")
		if id "$user" > /dev/null 2>&1 && [ ! -f "$home/.config/i3/config" ]; then
			mkdir -p "$home/.config/i3"
			cp /etc/i3/config "$home/.config/i3/config"
			chown -R "$(id -u "$user"):$(id -g "$user")" "$home/.config/i3"
		fi
	done
fi

# Let NetworkManager coexist with systemd-networkd (only if networkd is active)
if command -v NetworkManager > /dev/null 2>&1 && systemctl is-active --quiet systemd-networkd 2>/dev/null; then
	mkdir -p /etc/NetworkManager/conf.d
	cat > /etc/NetworkManager/conf.d/10-armbian-unmanaged.conf <<- NMEOF
	[keyfile]
	unmanaged-devices=type:ethernet
	NMEOF
	systemctl restart NetworkManager 2>/dev/null || true
fi

