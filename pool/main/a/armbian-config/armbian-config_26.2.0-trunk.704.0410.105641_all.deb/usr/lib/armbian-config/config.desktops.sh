module_options+=(
	["module_desktops,author"]="@igorpecovnik"
	["module_desktops,feature"]="module_desktops"
	["module_desktops,desc"]="Install and manage desktop environments (YAML-driven)"
	["module_desktops,example"]="install remove disable enable status auto manual login supported installed help"
	["module_desktops,status"]="Active"
	["module_desktops,arch"]=""
	["module_desktops,help_install"]="Install desktop (de=name)"
	["module_desktops,help_remove"]="Remove desktop (de=name)"
	["module_desktops,help_disable"]="Disable display manager"
	["module_desktops,help_enable"]="Enable display manager"
	["module_desktops,help_status"]="Check if installed (de=name)"
	["module_desktops,help_auto"]="Enable auto-login (de=name)"
	["module_desktops,help_manual"]="Disable auto-login (de=name)"
	["module_desktops,help_login"]="Check auto-login status (de=name)"
	["module_desktops,help_supported"]="JSON list or check one (de=name arch=X release=Y)"
	["module_desktops,help_installed"]="Returns 0 if any desktop is installed (no de=)"
)

#
# Check if running inside a container
#
_desktop_in_container() {
	[[ -f /.dockerenv || -f /run/.containerenv || -n "${CI:-}" || -n "${GITHUB_ACTIONS:-}" ]]
}

#
# Module to install and manage desktop environments (YAML-driven)
#
function module_desktops() {

	local de=""
	local query_arch=""
	local query_release=""
	local selected
	for selected in "${@:2}"; do
		IFS='=' read -r -a split <<< "${selected}"
		[[ "${split[0]}" == "de" ]] && de="${split[1]}"
		[[ "${split[0]}" == "arch" ]] && query_arch="${split[1]}"
		[[ "${split[0]}" == "release" ]] && query_release="${split[1]}"
	done

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_desktops,example"]}"

	case "$1" in
		"${commands[0]}")
			# install
			if [[ -z "$de" ]]; then
				local available=$(module_desktop_yamlparse_list | cut -f1 | tr '\n' ', ' | sed 's/,$//')
				echo "Error: specify de=name. Available: ${available}" >&2
				return 1
			fi

			local user
			user=$(module_desktop_getuser) || return 1

			module_desktop_yamlparse "$de" || return 1

			if [[ -z "$DESKTOP_PACKAGES" || -z "$DESKTOP_PRIMARY_PKG" ]]; then
				echo "Error: YAML definition for '${de}' has no packages" >&2
				return 1
			fi

			if [[ "$DESKTOP_SUPPORTED" != "yes" ]]; then
				echo "Warning: '${de}' is not supported on ${DISTROID}/$(dpkg --print-architecture)" >&2
			fi

			# suppress interactive prompts
			echo "encfs encfs/security-information boolean true" | debconf-set-selections 2>/dev/null || true

			# set up custom repo if needed
			if ! module_desktop_repo "$de"; then
				echo "Error: failed to set up repository for '${de}', aborting install" >&2
				return 1
			fi

			# update package list
			pkg_update

			# install packages
			pkg_install -o Dpkg::Options::="--force-confold" ${DESKTOP_PACKAGES}

			# install and register display manager
			if [[ -n "$DESKTOP_DM" && "$DESKTOP_DM" != "none" ]]; then
				pkg_install -o Dpkg::Options::="--force-confold" "$DESKTOP_DM"
				command -v "$DESKTOP_DM" > /etc/X11/default-display-manager 2>/dev/null || true
			fi

			# remove unwanted packages
			if [[ -n "$DESKTOP_PACKAGES_UNINSTALL" ]]; then
				apt-get remove -y --purge ${DESKTOP_PACKAGES_UNINSTALL} 2>/dev/null || true
			fi

			# install branding
			module_desktop_branding "$de"

			# install Armbian Imager AppImage
			module_appimage install app=armbian-imager

			# add user to desktop groups
			for group in sudo netdev audio video dialout plugdev input bluetooth systemd-journal ssh; do
				usermod -aG "$group" "$user" 2>/dev/null || true
			done

			# set up profile sync daemon
			local user_home
			user_home=$(getent passwd "$user" | cut -d: -f6)
			if command -v psd > /dev/null 2>&1; then
				grep -q overlay-helper /etc/sudoers 2>/dev/null || \
					echo "${user} ALL=(ALL) NOPASSWD: /usr/bin/psd-overlay-helper" >> /etc/sudoers
				touch "${user_home}/.activate_psd"
			fi

			# update skel to existing users
			module_update_skel install

			# display manager and auto-login (skip in containers)
			if ! _desktop_in_container; then
				for dm in gdm3 lightdm sddm; do
					systemctl is-active --quiet "$dm" 2>/dev/null && systemctl stop "$dm" 2>/dev/null
				done
				systemctl start display-manager 2>/dev/null || \
					systemctl start "$DESKTOP_DM" 2>/dev/null || true
				module_desktops auto de="$de"
			fi

			unset _DESKTOPS_INSTALLED_CACHE
			echo "${de} installed."
		;;

		"${commands[1]}")
			# remove
			if [[ -z "$de" ]]; then
				echo "Error: specify de=name" >&2
				return 1
			fi

			module_desktop_yamlparse "$de" || return 1

			# disable auto-login
			module_desktops manual de="$de" 2>/dev/null

			# stop display manager
			if ! _desktop_in_container; then
				systemctl stop display-manager 2>/dev/null || true
			fi

			# remove display manager
			if [[ -n "$DESKTOP_DM" && "$DESKTOP_DM" != "none" ]]; then
				pkg_remove "$DESKTOP_DM"
			fi

			# remove primary DE package (autopurge handles dependencies)
			if [[ -n "$DESKTOP_PRIMARY_PKG" ]]; then
				pkg_remove "$DESKTOP_PRIMARY_PKG"
			fi

			# remove AppImages
			module_appimage remove app=armbian-imager

			unset _DESKTOPS_INSTALLED_CACHE
			echo "${de} removed."
		;;

		"${commands[2]}")
			# disable
			systemctl stop display-manager 2>/dev/null || true
			systemctl disable display-manager 2>/dev/null || true
		;;

		"${commands[3]}")
			# enable
			systemctl enable display-manager 2>/dev/null || true
			systemctl start display-manager 2>/dev/null || true
		;;

		"${commands[4]}")
			# status
			if [[ -z "$de" ]]; then
				echo "Error: specify de=name" >&2
				return 1
			fi
			module_desktop_yamlparse "$de" || return 1
			[[ -n "$DESKTOP_PRIMARY_PKG" ]] && dpkg -l "$DESKTOP_PRIMARY_PKG" 2>/dev/null | grep -q "^ii" && return 0
			return 1
		;;

		"${commands[5]}")
			# auto-login
			if [[ -z "$de" ]]; then echo "Error: specify de=name" >&2; return 1; fi
			local user
			user=$(module_desktop_getuser) || return 1
			module_desktop_yamlparse "$de" || return 1

			case "$DESKTOP_DM" in
				gdm3)
					mkdir -p /etc/gdm3
					local gdm_conf="/etc/gdm3/custom.conf"
					[[ "$DISTROID" == "trixie" || "$DISTROID" == "forky" ]] && gdm_conf="/etc/gdm3/daemon.conf"
					cat > "$gdm_conf" <<- EOF
					[daemon]
					AutomaticLoginEnable = true
					AutomaticLogin = ${user}
					EOF
				;;
				sddm)
					mkdir -p /etc/sddm.conf.d
					cat > /etc/sddm.conf.d/autologin.conf <<- EOF
					[Autologin]
					User=${user}
					EOF
				;;
				lightdm)
					# map DE name to actual xsession file in /usr/share/xsessions/
					local session="$de"
					[[ "$session" == "i3-wm" ]] && session="i3"
					mkdir -p /etc/lightdm/lightdm.conf.d
					cat > /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf <<- EOF
					[Seat:*]
					autologin-user=${user}
					autologin-user-timeout=0
					user-session=${session}
					EOF
				;;
			esac
			_desktop_in_container || systemctl restart display-manager 2>/dev/null || true
		;;

		"${commands[6]}")
			# manual login (disable auto-login)
			if [[ -z "$de" ]]; then echo "Error: specify de=name" >&2; return 1; fi
			module_desktop_yamlparse "$de" || return 1

			case "$DESKTOP_DM" in
				gdm3)    sed -i 's/AutomaticLoginEnable = true/AutomaticLoginEnable = false/' /etc/gdm3/custom.conf /etc/gdm3/daemon.conf 2>/dev/null ;;
				sddm)    rm -f /etc/sddm.conf.d/autologin.conf ;;
				lightdm) rm -f /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf ;;
			esac
			_desktop_in_container || systemctl restart display-manager 2>/dev/null || true
		;;

		"${commands[7]}")
			# login status (check auto-login)
			if [[ -z "$de" ]]; then echo "Error: specify de=name" >&2; return 1; fi
			module_desktop_yamlparse "$de" || return 1

			case "$DESKTOP_DM" in
				gdm3)    grep -qE 'AutomaticLoginEnable\s*=\s*true' /etc/gdm3/custom.conf /etc/gdm3/daemon.conf 2>/dev/null && return 0 ;;
				sddm)    [[ -f /etc/sddm.conf.d/autologin.conf ]] && return 0 ;;
				lightdm) [[ -f /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf ]] && return 0 ;;
			esac
			return 1
		;;

		"${commands[8]}")
			# supported
			local use_arch="${query_arch:-$(dpkg --print-architecture)}"
			local use_release="${query_release:-$DISTROID}"

			if [[ -z "$de" ]]; then
				local yaml_dir="${script_dir}/../tools/modules/desktops/yaml"
				local parser="${script_dir}/../tools/modules/desktops/scripts/parse_desktop_yaml.py"
				local result
				result=$(python3 "$parser" "$yaml_dir" "--list-json" "$use_release" "$use_arch")
				echo "$result"
				[[ "$result" == "[]" ]] && return 1
				return 0
			fi

			module_desktop_supported "$de" "$use_arch" "$use_release" && echo "true" && return 0
			echo "false"
			return 1
		;;

		"${commands[9]}")
			# installed — returns 0 if any known desktop is installed.
			# Cached in _DESKTOPS_INSTALLED_CACHE for the lifetime of one armbian-config
			# session so the menu condition can be re-evaluated cheaply per render.
			# Cache is invalidated by `install` and `remove` below.
			if [[ -n "${_DESKTOPS_INSTALLED_CACHE-}" ]]; then
				[[ "$_DESKTOPS_INSTALLED_CACHE" == "yes" ]]
				return $?
			fi
			local yaml_dir="${script_dir}/../tools/modules/desktops/yaml"
			local parser="${script_dir}/../tools/modules/desktops/scripts/parse_desktop_yaml.py"
			local primaries pkgs
			primaries=$(python3 "$parser" "$yaml_dir" --primaries "$DISTROID" "$(dpkg --print-architecture)" 2>/dev/null) || {
				_DESKTOPS_INSTALLED_CACHE=no
				return 1
			}
			# Collapse '<name>\t<pkg>\n...' to a space-separated package list
			pkgs=$(awk -F'\t' '{print $2}' <<< "$primaries" | tr '\n' ' ')
			if [[ -n "${pkgs// /}" ]] && dpkg-query -W -f='${Status}\n' $pkgs 2>/dev/null | grep -q "install ok installed"; then
				_DESKTOPS_INSTALLED_CACHE=yes
				return 0
			fi
			_DESKTOPS_INSTALLED_CACHE=no
			return 1
		;;

		"${commands[10]}")
			show_module_help "module_desktops" "Desktops" \
				"Examples:\n  module_desktops install de=xfce\n  module_desktops supported\n  module_desktops supported arch=arm64 release=trixie\n  module_desktops supported de=gnome" "native"
		;;

		*)
			${module_options["module_desktops,feature"]} help
		;;
	esac
}

module_options+=(
	["module_update_skel,author"]="@igorpecovnik"
	["module_update_skel,feature"]="module_update_skel"
	["module_update_skel,desc"]="Copy /etc/skel files into existing user home directories"
	["module_update_skel,example"]="install help"
	["module_update_skel,status"]="Active"
	["module_update_skel,arch"]=""
)
#
# Module to update skel files in user home directories
#
function module_update_skel() {

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_update_skel,example"]}"

	case "$1" in
		"${commands[0]}")
			# install - copy skel to all regular users
			getent passwd |
				while IFS=: read -r username x uid gid gecos home shell; do
					if [ ! -d "$home" ] || [ "$username" == 'root' ] || [ "$uid" -lt 1000 ] || [ "$uid" -ge 65534 ]; then
						continue
					fi
					# copy new files only, then fix ownership of copied files
					find /etc/skel -mindepth 1 | while read -r src; do
						local dst="$home/${src#/etc/skel/}"
						if [ ! -e "$dst" ]; then
							if [ -d "$src" ]; then
								mkdir -p "$dst"
							else
								mkdir -p "$(dirname "$dst")"
								cp "$src" "$dst"
							fi
							chown "$uid:$gid" "$dst"
						fi
					done
				done
		;;
		"${commands[1]}")
			show_module_help "module_update_skel" "Update Skel" "" "native"
		;;
		*)
			show_module_help "module_update_skel" "Update Skel" "" "native"
		;;
	esac
}

module_options+=(
	["module_desktop_repo,author"]="@igorpecovnik"
	["module_desktop_repo,feature"]="module_desktop_repo"
	["module_desktop_repo,desc"]="Set up custom APT repository for desktop environments"
	["module_desktop_repo,example"]="module_desktop_repo kde-neon"
	["module_desktop_repo,status"]="Active"
	["module_desktop_repo,arch"]="arm64 amd64 armhf riscv64"
)

#
# Set up custom APT repo if desktop requires one
# Usage: module_desktop_repo <de_name>
# Requires DESKTOP_REPO_URL, DESKTOP_REPO_KEY_URL, DESKTOP_REPO_KEYRING
# to be set (via module_desktop_yamlparse)
#
function module_desktop_repo() {
	local de="$1"

	case "$de" in
		help|"")
			echo "Usage: module_desktop_repo <de_name>"
			echo ""
			echo "Set up a custom APT repository for a desktop that requires one."
			echo "Must be called after module_desktop_yamlparse to set repo variables."
			echo ""
			echo "Examples:"
			echo "  module_desktop_yamlparse kde-neon"
			echo "  module_desktop_repo kde-neon"
			return 0
		;;
		*)
			# sanitize de name for safe use in file paths
			if [[ ! "$de" =~ ^[a-zA-Z0-9._-]+$ ]]; then
				echo "Error: invalid desktop name '${de}'" >&2
				return 1
			fi

			if [[ -n "$DESKTOP_REPO_URL" && -n "$DESKTOP_REPO_KEY_URL" && -n "$DESKTOP_REPO_KEYRING" ]]; then
				echo "Setting up repository for ${de}..." >&2

				# download and verify GPG key
				if ! (set -o pipefail; curl -fsSL --retry 3 --retry-connrefused --connect-timeout 10 --max-time 30 "$DESKTOP_REPO_KEY_URL" | gpg --yes --dearmor -o "$DESKTOP_REPO_KEYRING" 2>/dev/null); then
					echo "Error: failed to download GPG key from $DESKTOP_REPO_KEY_URL" >&2
					return 1
				fi

				if [[ ! -s "$DESKTOP_REPO_KEYRING" ]]; then
					echo "Error: GPG keyring is empty at $DESKTOP_REPO_KEYRING" >&2
					rm -f "$DESKTOP_REPO_KEYRING"
					return 1
				fi

				# add source
				cat > "/etc/apt/sources.list.d/${de}.list" <<- EOF
				deb [signed-by=${DESKTOP_REPO_KEYRING}] ${DESKTOP_REPO_URL} ${DISTROID} main
				EOF
			fi
		;;
	esac
}

module_options+=(
	["module_desktop_supported,author"]="@igorpecovnik"
	["module_desktop_supported,feature"]="module_desktop_supported"
	["module_desktop_supported,desc"]="Check if a desktop is supported on this system"
	["module_desktop_supported,example"]="module_desktop_supported xfce"
	["module_desktop_supported,status"]="Active"
	["module_desktop_supported,arch"]="arm64 amd64 armhf riscv64"
)

#
# Check if a desktop is supported on given arch/release
# Usage: module_desktop_supported <de_name> [arch] [release]
# Returns: 0 if supported, 1 if not
#
function module_desktop_supported() {
	local de="$1"
	local arch="${2:-$(dpkg --print-architecture)}"
	local release="${3:-$DISTROID}"

	case "$de" in
		help|"")
			echo "Usage: module_desktop_supported <de_name> [arch] [release]"
			echo ""
			echo "Check if a desktop environment is supported on a given architecture and release."
			echo "Returns exit code 0 if supported, 1 if not."
			echo ""
			echo "Examples:"
			echo "  module_desktop_supported xfce              # check on current host"
			echo "  module_desktop_supported kde-neon arm64 noble  # check specific arch/release"
			return 0
		;;
		*)
			module_desktop_yamlparse "$de" "$arch" "$release" 2>/dev/null || return 1
			[[ "$DESKTOP_SUPPORTED" == "yes" ]]
		;;
	esac
}

module_options+=(
	["module_desktop_yamlparse,author"]="@igorpecovnik"
	["module_desktop_yamlparse,feature"]="module_desktop_yamlparse"
	["module_desktop_yamlparse,desc"]="Parse desktop YAML definitions"
	["module_desktop_yamlparse,example"]="module_desktop_yamlparse xfce"
	["module_desktop_yamlparse,status"]="Active"
	["module_desktop_yamlparse,arch"]="arm64 amd64 armhf riscv64"
)

#
# Parse YAML desktop definition via Python helper
# Usage: module_desktop_yamlparse <de_name> [arch] [release]
# Sets: DESKTOP_PACKAGES, DESKTOP_PACKAGES_UNINSTALL, DESKTOP_PRIMARY_PKG,
#       DESKTOP_DM, DESKTOP_STATUS, DESKTOP_SUPPORTED, DESKTOP_DESC,
#       DESKTOP_REPO_URL, DESKTOP_REPO_KEY_URL, DESKTOP_REPO_KEYRING
#
function module_desktop_yamlparse() {
	local de="$1"
	local yaml_dir="${script_dir}/../tools/modules/desktops/yaml"
	local parser="${script_dir}/../tools/modules/desktops/scripts/parse_desktop_yaml.py"
	local arch="${2:-$(dpkg --print-architecture)}"
	local release="${3:-$DISTROID}"

	case "$de" in
		help|"")
			echo "Usage: module_desktop_yamlparse <de_name> [arch] [release]"
			echo ""
			echo "Parse a desktop YAML definition and set package variables."
			echo "Variables set: DESKTOP_PACKAGES, DESKTOP_PACKAGES_UNINSTALL,"
			echo "  DESKTOP_PRIMARY_PKG, DESKTOP_DM, DESKTOP_STATUS,"
			echo "  DESKTOP_SUPPORTED, DESKTOP_DESC, DESKTOP_REPO_*"
			echo ""
			echo "Examples:"
			echo "  module_desktop_yamlparse xfce"
			echo "  module_desktop_yamlparse kde-neon arm64 noble"
			return 0
		;;
		*)
			if [[ ! -f "$parser" ]]; then
				echo "Error: YAML parser not found at $parser" >&2
				return 1
			fi

			# reset variables
			DESKTOP_PACKAGES=""
			DESKTOP_PACKAGES_UNINSTALL=""
			DESKTOP_PRIMARY_PKG=""
			DESKTOP_DM=""
			DESKTOP_STATUS=""
			DESKTOP_SUPPORTED=""
			DESKTOP_DESC=""
			DESKTOP_REPO_URL=""
			DESKTOP_REPO_KEY_URL=""
			DESKTOP_REPO_KEYRING=""

			local _output
			_output=$(python3 "$parser" "$yaml_dir" "$de" "$release" "$arch" 2>&1) || {
				echo "Error: failed to parse YAML for '${de}': ${_output}" >&2
				return 1
			}
			eval "$_output" || return 1
		;;
	esac
}

#
# List available desktops via Python helper
# Usage: module_desktop_yamlparse_list [arch] [release]
#
function module_desktop_yamlparse_list() {
	local yaml_dir="${script_dir}/../tools/modules/desktops/yaml"
	local parser="${script_dir}/../tools/modules/desktops/scripts/parse_desktop_yaml.py"
	local arch="${1:-$(dpkg --print-architecture)}"
	local release="${2:-$DISTROID}"

	python3 "$parser" "$yaml_dir" "--list" "$release" "$arch"
}

module_options+=(
	["module_appimage,author"]="@igorpecovnik"
	["module_appimage,feature"]="module_appimage"
	["module_appimage,desc"]="Download and manage AppImage applications"
	["module_appimage,example"]="install remove status help"
	["module_appimage,status"]="Active"
	["module_appimage,arch"]=""
	["module_appimage,help_install"]="Download and install an AppImage (app=name)"
	["module_appimage,help_remove"]="Remove an installed AppImage (app=name)"
	["module_appimage,help_status"]="Check if an AppImage is installed (app=name)"
)

# AppImage registry: name -> GitHub repo
declare -A APPIMAGE_REPO=(
	["armbian-imager"]="armbian/imager"
)

# AppImage display names
declare -A APPIMAGE_NAME=(
	["armbian-imager"]="Armbian Imager"
)

# AppImage arch mapping: dpkg arch -> AppImage arch suffix
declare -A APPIMAGE_ARCH=(
	["arm64"]="aarch64"
	["amd64"]="amd64"
	["armhf"]="armhf"
)

#
# Module to download and manage AppImage applications
#
function module_appimage() {

	local APPIMAGE_DIR="/armbian/appimages"
	local APPIMAGE_DESKTOP_DIR="/usr/share/applications"

	# read app name from parameters
	local app=""
	local selected
	for selected in "${@:2}"; do
		IFS='=' read -r -a split <<< "${selected}"
		[[ "${split[0]}" == "app" ]] && app="${split[1]}"
	done

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_appimage,example"]}"

	case "$1" in
		"${commands[0]}")
			# install
			if [[ -z "$app" ]]; then
				echo "Error: specify app=name. Available: ${!APPIMAGE_REPO[*]}" >&2
				return 1
			fi

			local repo="${APPIMAGE_REPO[$app]:-}"
			if [[ -z "$repo" ]]; then
				echo "Error: unknown app '$app'. Available: ${!APPIMAGE_REPO[*]}" >&2
				return 1
			fi

			local arch=$(dpkg --print-architecture)
			local appimage_arch="${APPIMAGE_ARCH[$arch]:-}"
			if [[ -z "$appimage_arch" ]]; then
				echo "Error: architecture '$arch' not supported for AppImages" >&2
				return 1
			fi

			# ensure FUSE support for AppImages
			if ! pkg_install libfuse2 fuse3; then
				echo "Error: failed to install FUSE packages required for AppImages" >&2
				return 1
			fi
			# Resolve fusermount path once
			local fmount=$(command -v fusermount3 2>/dev/null || command -v fusermount 2>/dev/null)
			if [[ -z "$fmount" ]]; then
				echo "Error: no fusermount binary found after installing fuse3" >&2
				return 1
			fi
			# AppImages need fusermount but fuse3 only provides fusermount3
			if ! command -v fusermount > /dev/null 2>&1; then
				ln -sf "$fmount" /usr/local/bin/fusermount
			fi
			# Set FUSERMOUNT_PROG system-wide for AppImage compatibility
			if ! grep -q FUSERMOUNT_PROG /etc/environment 2>/dev/null; then
				echo "FUSERMOUNT_PROG=${fmount}" >> /etc/environment
			fi

			# get latest release download URL
			local download_url
			download_url=$(curl -sL "https://api.github.com/repos/${repo}/releases/latest" | \
				grep -o "https://.*${appimage_arch}\.AppImage" | head -1)

			if [[ -z "$download_url" ]]; then
				echo "Error: no AppImage found for ${app} on ${appimage_arch}" >&2
				return 1
			fi

			local filename=$(basename "$download_url")

			echo "Downloading ${app} for ${appimage_arch}..."
			mkdir -p "$APPIMAGE_DIR"
			curl -sL "$download_url" -o "${APPIMAGE_DIR}/${filename}"
			chmod +x "${APPIMAGE_DIR}/${filename}"

			# create stable symlink
			ln -sf "${APPIMAGE_DIR}/${filename}" "${APPIMAGE_DIR}/${app}"

			# create desktop entry
			local display_name="${APPIMAGE_NAME[$app]:-$app}"
			cat > "${APPIMAGE_DESKTOP_DIR}/${app}.desktop" <<- EOF
			[Desktop Entry]
			Version=1.0
			Type=Application
			Name=${display_name}
			Exec=env FUSERMOUNT_PROG=${fmount} ${APPIMAGE_DIR}/${app}
			Icon=/usr/share/pixmaps/armbian/armbian.png
			Terminal=false
			Categories=Utility;
			EOF

			echo "${app} installed: ${APPIMAGE_DIR}/${filename}"
		;;

		"${commands[1]}")
			# remove
			if [[ -z "$app" ]]; then
				echo "Error: specify app=name" >&2
				return 1
			fi
			rm -f "${APPIMAGE_DIR}/${app}" "${APPIMAGE_DIR}/${app}"_*.AppImage "${APPIMAGE_DIR}/"*"${app}"*.AppImage
			rm -f "${APPIMAGE_DESKTOP_DIR}/${app}.desktop"
			rmdir "${APPIMAGE_DIR}" 2>/dev/null || true
			echo "${app} removed"
		;;

		"${commands[2]}")
			# status
			if [[ -z "$app" ]]; then
				# list all installed
				if [[ -d "$APPIMAGE_DIR" ]]; then
					ls -1 "$APPIMAGE_DIR"/*.AppImage 2>/dev/null | while read f; do
						echo "$(basename "$f")"
					done
				fi
				return 0
			fi
			[[ -x "${APPIMAGE_DIR}/${app}" ]] && return 0 || return 1
		;;

		"${commands[3]}")
			show_module_help "module_appimage" "AppImage" \
				"Available apps: ${!APPIMAGE_REPO[*]}\nInstall dir: ${APPIMAGE_DIR}\nExample: module_appimage install app=armbian-imager" "native"
		;;

		*)
			show_module_help "module_appimage" "AppImage" \
				"Available apps: ${!APPIMAGE_REPO[*]}\nInstall dir: ${APPIMAGE_DIR}\nExample: module_appimage install app=armbian-imager" "native"
		;;
	esac
}

module_options+=(
	["module_desktop_getuser,author"]="@igorpecovnik"
	["module_desktop_getuser,feature"]="module_desktop_getuser"
	["module_desktop_getuser,desc"]="Detect first regular user for desktop setup"
	["module_desktop_getuser,example"]="module_desktop_getuser"
	["module_desktop_getuser,status"]="Active"
	["module_desktop_getuser,arch"]="arm64 amd64 armhf riscv64"
)

#
# Detect first regular user (UID >= 1000) with a login shell
# Usage: module_desktop_getuser
# Returns: username on stdout, exit 1 if none found
#
function module_desktop_getuser() {
	case "$1" in
		help)
			echo "Usage: module_desktop_getuser"
			echo ""
			echo "Detect the first regular user (UID >= 1000) with a login shell."
			echo "Used for desktop auto-login, group membership, and skel setup."
			echo "Prefers SUDO_USER if set and not root."
			return 0
		;;
		*)
			local user=""
			if [[ -n "$SUDO_USER" && "$SUDO_USER" != "root" ]] && id "$SUDO_USER" > /dev/null 2>&1; then
				user="$SUDO_USER"
			else
				user=$(awk -F: '$3 >= 1000 && $3 < 65534 && $7 !~ /nologin|false/ {print $1; exit}' /etc/passwd)
			fi
			if [[ -z "$user" ]]; then
				echo "Error: no regular user found. Create a non-root user first." >&2
				return 1
			fi
			echo "$user"
		;;
	esac
}

module_options+=(
	["module_desktop_branding,author"]="@igorpecovnik"
	["module_desktop_branding,feature"]="module_desktop_branding"
	["module_desktop_branding,desc"]="Install Armbian desktop branding assets"
	["module_desktop_branding,example"]="module_desktop_branding xfce"
	["module_desktop_branding,status"]="Active"
	["module_desktop_branding,arch"]="arm64 amd64 armhf riscv64"
)

#
# Install Armbian desktop branding (wallpapers, icons, greeter config, skel, postinst)
# Usage: module_desktop_branding <de_name>
#
function module_desktop_branding() {
	local de="$1"
	local desktop_dir="${script_dir}/../tools/modules/desktops"

	case "$de" in
		help|"")
			echo "Usage: module_desktop_branding <de_name>"
			echo ""
			echo "Install Armbian branding assets for a desktop environment:"
			echo "  - Greeter configuration (LightDM, SDDM)"
			echo "  - Default user skeleton configs"
			echo "  - Wallpapers and login wallpapers"
			echo "  - Desktop icons and login logo"
			echo "  - GNOME wallpaper properties XML"
			echo "  - DE-specific post-install configuration"
			return 0
		;;
		*)
			if [[ ! -d "$desktop_dir" ]]; then
				echo "Warning: desktops directory not found at $desktop_dir" >&2
				return 0
			fi

			dialog_infobox "Desktop" "Installing Armbian branding for ${de}..."

			# greeter configuration (lightdm)
			if [[ -d "$desktop_dir/greeters/lightdm" ]]; then
				mkdir -p /etc/armbian/lightdm
				cp -R "$desktop_dir/greeters/lightdm/." /etc/armbian/lightdm/
				cp -R /etc/armbian/lightdm/. /etc/lightdm/ 2>/dev/null || true
			fi

			# default user skeleton
			if [[ -d "$desktop_dir/skel" ]]; then
				cp -R "$desktop_dir/skel/." /etc/skel/
			fi

			# wallpapers
			if [[ -d "$desktop_dir/branding/wallpapers" ]]; then
				mkdir -p /usr/share/backgrounds/armbian
				cp "$desktop_dir/branding/wallpapers/"*.jpg /usr/share/backgrounds/armbian/ 2>/dev/null || true
			fi

			# lightdm wallpapers
			if [[ -d "$desktop_dir/branding/wallpapers-lightdm" ]]; then
				mkdir -p /usr/share/backgrounds/armbian-lightdm
				cp "$desktop_dir/branding/wallpapers-lightdm/"*.jpg /usr/share/backgrounds/armbian-lightdm/ 2>/dev/null || true
			fi

			# desktop icons
			if [[ -d "$desktop_dir/branding/icons" ]]; then
				mkdir -p /usr/share/icons/armbian
				cp "$desktop_dir/branding/icons/"* /usr/share/icons/armbian/ 2>/dev/null || true
			fi

			# login logo
			if [[ -d "$desktop_dir/branding/pixmaps" ]]; then
				mkdir -p /usr/share/pixmaps/armbian
				cp "$desktop_dir/branding/pixmaps/"* /usr/share/pixmaps/armbian/ 2>/dev/null || true
			fi

			# GNOME wallpaper properties
			if [[ -f "$desktop_dir/branding/armbian.xml" ]]; then
				mkdir -p /usr/share/gnome-background-properties
				cp "$desktop_dir/branding/armbian.xml" /usr/share/gnome-background-properties/
			fi

			# SDDM theme (for desktops using sddm)
			if [[ -d "$desktop_dir/greeters/sddm/themes" && "$DESKTOP_DM" == "sddm" ]]; then
				mkdir -p /usr/share/sddm/themes
				cp -R "$desktop_dir/greeters/sddm/themes/"* /usr/share/sddm/themes/ 2>/dev/null || true
			fi

			# DE-specific postinst script (skip inside containers / CI)
			if [[ -f "$desktop_dir/postinst/${de}.sh" ]]; then
				if _desktop_in_container 2>/dev/null; then
					echo "Skipping ${de} postinst (running inside container/CI)" >&2
				else
					dialog_infobox "Desktop" "Running ${de} post-install configuration..."
					bash "$desktop_dir/postinst/${de}.sh" || true
				fi
			fi
		;;
	esac
}

