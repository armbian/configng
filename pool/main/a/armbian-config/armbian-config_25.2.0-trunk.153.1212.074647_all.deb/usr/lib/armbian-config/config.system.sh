
module_options+=(
	["update_skel,author"]="@igorpecovnik"
	["update_skel,ref_link"]=""
	["update_skel,feature"]="update_skel"
	["update_skel,desc"]="Update the /etc/skel files in users directories"
	["update_skel,example"]="update_skel"
	["update_skel,status"]="Active"
)
#
# check dpkg status of $1 -- currently only 'not installed at all' case caught
#
function update_skel() {

	getent passwd |
		while IFS=: read -r username x uid gid gecos home shell; do
			if [ ! -d "$home" ] || [ "$username" == 'root' ] || [ "$uid" -lt 1000 ]; then
				continue
			fi
			tar -C /etc/skel/ -cf - . | su - "$username" -c "tar --skip-old-files -xf -"
		done

}



module_options+=(

["adjust_motd,author"]="@igorpecovnik"
["adjust_motd,ref_link"]=""
["adjust_motd,feature"]="about_armbian_configng"
["adjust_motd,desc"]="Adjust welcome screen (motd)"
["adjust_motd,example"]="adjust_motd clear, header, sysinfo, tips, commands"
["adjust_motd,status"]="Active"
)
#
# @description Toggle message of the day items
#
function adjust_motd() {

	# show motd description
	motd_desc() {
		case $1 in
			clear)
				echo "Clear screen on login"
				;;
			header)
				echo "Show header with logo"
				;;
			sysinfo)
				echo "Display system information"
				;;
			tips)
				echo "Show Armbian team tips"
				;;
			commands)
				echo "Show recommended commands"
				;;
			*)
				echo "No description"
				;;
		esac
	}

	# read status
	function motd_status() {
		source /etc/default/armbian-motd
		if [[ $MOTD_DISABLE == *$1* ]]; then
			echo "OFF"
		else
			echo "ON"
		fi
	}

	LIST=()
	for v in $(grep THIS_SCRIPT= /etc/update-motd.d/* | cut -d"=" -f2 | sed "s/\"//g"); do
		LIST+=("$v" "$(motd_desc $v)" "$(motd_status $v)")
	done

	INLIST=($(grep THIS_SCRIPT= /etc/update-motd.d/* | cut -d"=" -f2 | sed "s/\"//g"))
	CHOICES=$($DIALOG --separate-output --nocancel --title "Adjust welcome screen" --checklist "" 11 50 5 "${LIST[@]}" 3>&1 1>&2 2>&3)
	INSERT="$(echo "${INLIST[@]}" "${CHOICES[@]}" | tr ' ' '\n' | sort | uniq -u | tr '\n' ' ' | sed 's/ *$//')"
	# adjust motd config
	sed -i "s/^MOTD_DISABLE=.*/MOTD_DISABLE=\"$INSERT\"/g" /etc/default/armbian-motd
	clear
	find /etc/update-motd.d/. -type f -executable | sort | bash
	echo "Press any key to return to armbian-config"
	read
}

module_options+=(
	["manage_odroid_board,author"]="@GeoffClements"
	["manage_odroid_board,ref_link"]=""
	["manage_odroid_board,feature"]="Odroid board"
	["manage_odroid_board,desc"]="Select optimised Odroid board configuration"
	["manage_odroid_board,example"]="select"
	["manage_odroid_board,status"]="Stable"
)
#
# @description Select optimised board configuration
#
function manage_odroid_board() {

	local board_list=("Odroid XU4" "Odroid XU3" "Odroid XU3 Lite" "Odroid HC1/HC2")
	local board_id=("xu4" "xu3" "xu3l" "hc1")
	local -a list
	local state

	local env_file=/boot/armbianEnv.txt
	local current_board=$(grep -oP '^board_name=\K.*' ${env_file})
	local target_board=${current_board}

	for board_num in $(seq 0 $((${#board_list[@]} - 1))); do
		if [[ "${board_id[${board_num}]}" == "${current_board}" ]]; then
			state=on
		else
			state=off
		fi
	list+=("${board_id[${board_num}]}" "${board_list[${board_num}]}" "${state}")
	done

	if target_board=$($DIALOG --notags --title "Select optimised board configuration" \
	--radiolist "" 10 42 4 "${list[@]}" 3>&1 1>&2 2>&3); then
		sed -i "s/^board_name=.*/board_name=${target_board}/" ${env_file} 2> /dev/null && \
		grep -q "^board_name=${target_board}" ${env_file} 2>/dev/null || \
		echo "board_name=${target_board}" >> ${env_file}
		sed -i "s/^BOARD_NAME.*/BOARD_NAME=\"Odroid ${target_board^^}\"/" /etc/armbian-release

		if $DIALOG --title " Reboot required " --yes-button "Reboot" --no-button "Cancel" --yesno \
		"A reboot is required to apply the changes. Shall we reboot now?" 7 34; then
		reboot
		fi
	fi
}


module_options+=(
["manage_dtoverlays,author"]="@viraniac"
["manage_dtoverlays,ref_link"]=""
["manage_dtoverlays,feature"]="manage_dtoverlays"
["manage_dtoverlays,desc"]="Enable/disable device tree overlays"
["manage_dtoverlays,example"]="manage_dtoverlays"
["manage_dtoverlays,status"]="Active"
)
#
# @description Enable/disable device tree overlays
#
function manage_dtoverlays () {
	# check if user agree to enter this area
	local changes="false"
	local overlayconf="/boot/armbianEnv.txt"
	local overlaydir="/boot/dtb/overlay";
	[[ "$LINUXFAMILY" == "sunxi64" ]] && overlaydir="/boot/dtb/allwinner/overlay";
	[[ "$LINUXFAMILY" == "meson64" ]] && overlaydir="/boot/dtb/amlogic/overlay";
	[[ "$LINUXFAMILY" == "rockchip64" || "$LINUXFAMILY" == "rk3399" || "$LINUXFAMILY" == "rockchip-rk3588" || "$LINUXFAMILY" == "rk35xx" ]] && overlaydir="/boot/dtb/rockchip/overlay";

	[[ -f "${overlayconf}" ]] && source "${overlayconf}"
	while true; do
		local options=()
		j=0
		if [[ -n "${BOOT_SOC}" ]]; then
		available_overlays=$(ls -1 ${overlaydir}/*.dtbo | sed "s#^${overlaydir}/##" | sed 's/.dtbo//g' | grep -E "$BOOT_SOC|$BOARD" | tr '\n' ' ')
		else
		available_overlays=$(ls -1 ${overlaydir}/*.dtbo | sed "s#^${overlaydir}/##" | sed 's/.dtbo//g' | tr '\n' ' ')
		fi
		for overlay in ${available_overlays}; do
			local status="OFF"
			grep '^overlays' ${overlayconf} | grep -qw ${overlay} && status=ON
			options+=( "$overlay" "" "$status")
		done
		selection=$($DIALOG --title "Manage devicetree overlays" --cancel-button "Back" \
			--ok-button "Save" --checklist "\nUse <space> to toggle functions and save them.\nExit when you are done.\n " \
			0 0 0 "${options[@]}" 3>&1 1>&2 2>&3)
		exit_status=$?
		case $exit_status in
			0)
				changes="true"
				newoverlays=$(echo $selection | sed 's/"//g')
				sed -i "s/^overlays=.*/overlays=$newoverlays/" ${overlayconf}
				if ! grep -q "^overlays" ${overlayconf}; then echo "overlays=$newoverlays" >> ${overlayconf}; fi
				sync
				;;
			1)
				if [[ "$changes" == "true" ]]; then
					$DIALOG --title " Reboot required " --yes-button "Reboot" \
						--no-button "Cancel" --yesno "A reboot is required to apply the changes. Shall we reboot now?" 7 34
					if [[ $? = 0 ]]; then
						reboot
					fi
				fi
				break
				;;
			255)
				;;
		esac
	done
}


module_options+=(
	["release_upgrade,author"]="@igorpecovnik"
	["release_upgrade,ref_link"]=""
	["release_upgrade,feature"]="Upgrade upstream distribution release"
	["release_upgrade,desc"]="Upgrade to next stable or rolling release"
	["release_upgrade,example"]="release_upgrade stable verify"
	["release_upgrade,status"]="Active"
)
#
# Upgrade distribution
#
release_upgrade(){

	local upgrade_type=$1
	local verify=$2

	local distroid=${DISTROID}

	if [[ "${upgrade_type}" == stable ]]; then
		local filter=$(grep "supported" /etc/armbian-distribution-status | cut -d"=" -f1)
	elif [[ "${upgrade_type}" == rolling ]]; then
		local filter=$(grep "eos\|csc" /etc/armbian-distribution-status | cut -d"=" -f1 | sed "s/sid/testing/g")
	else
		local filter=$(cat /etc/armbian-distribution-status | cut -d"=" -f1)
	fi

	local upgrade=$(for j in $filter; do
		for i in $(grep "^${distroid}" /etc/armbian-distribution-status | cut -d";" -f2 | cut -d"=" -f2 | sed "s/,/ /g"); do
			if [[ $i == $j ]]; then
				echo $i
			fi
		done
	done | tail -1)

	if [[ -z "${upgrade}" ]]; then
		return 1;
	elif [[ -z "${verify}" ]]; then
		[[ -f /etc/apt/sources.list.d/ubuntu.sources ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/ubuntu.sources
		[[ -f /etc/apt/sources.list.d/debian.sources ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/debian.sources
		[[ -f /etc/apt/sources.list ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list
		[[ "${upgrade}" == "testing" ]] && upgrade="sid" # our repo and everything is tied to sid
		[[ -f /etc/apt/sources.list.d/armbian.list ]] && sed -i "s/$distroid/$upgrade/g" /etc/apt/sources.list.d/armbian.list
		apt_install_wrapper apt-get -y update
		apt_install_wrapper DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a apt-get -y -o Dpkg::Options::="--force-confold" upgrade --without-new-pkgs
		apt_install_wrapper DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a apt-get -y -o Dpkg::Options::="--force-confold" full-upgrade
		apt_install_wrapper apt-get -y --purge autoremove
	fi
}


module_options+=(
["store_netplan_config,author"]="@igorpecovnik"
["store_netplan_config,ref_link"]=""
["store_netplan_config,feature"]="Storing netplan config to tmp"
["store_netplan_config,desc"]=""
["store_netplan_config,example"]=""
["store_netplan_config,status"]="Active"
)
#
# @description Restoring Netplan configuration from temp folder
#
function restore_netplan_config() {

	echo "Restoring NetPlan configs" | show_infobox
	# just in case
	if [[ -n ${restore_netplan_config_folder} ]]; then
		rm -f /etc/netplan/*
		rsync -ar ${restore_netplan_config_folder}/. /etc/netplan
	fi

}


module_options+=(
	["module_armbian_firmware,author"]="@igorpecovnik"
	["module_armbian_firmware,feature"]="module_armbian_firmware"
	["module_armbian_firmware,example"]="select install show hold unhold repository headers help"
	["module_armbian_firmware,desc"]="Module for Armbian firmware manipulating."
	["module_armbian_firmware,status"]="review"
)

function module_armbian_firmware() {
	local title="Armbian FW"
	local condition=$(which "$title" 2>/dev/null)

	# Convert the example string to an array
	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_armbian_firmware,example"]}"

	case "$1" in
		"${commands[0]}") # choose kernel from the list

			# make sure to proceed if this variable is not defined. This can surface on some old builds
			[[ -z "${KERNEL_TEST_TARGET}" ]] && KERNEL_TEST_TARGET="legacy,vendor,current,edge"

			# show warning when packages are put on hold and ask to release it
			if ${module_options["module_armbian_firmware,feature"]} ${commands[3]} "status"; then
				if $DIALOG --title "Warning!" --yesno "Firmware upgrade is disabled. Release hold and proceed?" 7 60; then
					${module_options["module_armbian_firmware,feature"]} ${commands[4]}
				else
					exit 0
				fi
			fi

			# by default we define which kernels are suitable
			if ! $DIALOG --title "Advanced options" --yesno "Show only mainstream kernels on the list?" 7 60; then
				KERNEL_TEST_TARGET="legacy,vendor,current,edge"
			fi

			# read what is possible to install
			local kernel_test_target=$(\
				for kernel_test_target in ${KERNEL_TEST_TARGET//,/ }
				do
					echo "linux-image-${kernel_test_target}-${LINUXFAMILY}"
				done
				)
			local installed_kernel_version=$(dpkg -l | grep '^ii' | grep linux-image | awk '{print $2"="$3}' | head -1)

			# workaroun in case current is not installed
			[[ -n ${installed_kernel_version} ]] && local grep_current_kernel=" | grep -v ${installed_kernel_version}"

			# main search command
			local search_exec="apt-cache show ${kernel_test_target} \
			| grep -E \"Package:|Version:|version:|family\" \
			| grep -v \"Config-Version\" \
			| sed -n -e 's/^.*: //p' \
			| sed 's/\.$//g' \
			| xargs -n3 -d'\n' \
			| sed \"s/ /=/\" $grep_current_kernel"

			# construct a list of kernels with their Armbian release versions and kernel version
			IFS=$'\n'
			local LIST=()
			for line in $(eval ${search_exec}); do
				LIST+=($(echo $line | awk -F ' ' '{print $1 "      "}') $(echo $line | awk -F ' ' '{print "v"$2}'))
			done
			unset IFS

			# generate selection menu
			local list_length=$((${#LIST[@]} / 2))
			if [ "$list_length" -eq 0 ]; then
				$DIALOG --backtitle "$BACKTITLE" --title " Warning " --msgbox "No other kernels available!" 7 31
			else
				if target_version=$(\
						$DIALOG \
						--separate-output \
						--title "Select kernel" \
						--menu "" \
						$((${list_length} + 7)) 80 $((${list_length})) "${LIST[@]}" \
						3>&1 1>&2 2>&3)
				then
					# extract branch
					local branch=${target_version##*image-}
					# call install function
					${module_options["module_armbian_firmware,feature"]} ${commands[1]} "${branch%%-*}" "${target_version/*=/}"
				fi
			fi

		;;

		"${commands[1]}") # purge old and install new packages from desired branch and version

			# input parameters
			local branch=$2
			local version=$3
			local hide=$3
			local headers=$5

			# generate list
			${module_options["module_armbian_firmware,feature"]} ${commands[2]} "${branch}" "${version}" "hide" "" "$headers"

			# purge and install
			for pkg in ${packages[@]}; do
				purge_pkg=$(echo $pkg | sed -e 's/linux-image.*/linux-image*/;s/linux-dtb.*/linux-dtb*/;s/linux-headers.*/linux-headers*/;s/armbian-firmware.*/armbian-firmware*/')
				# if test install is succesfull, proceed
				apt_install_wrapper apt-get -y --simulate --download-only --allow-downgrades install "${pkg}"
				if [[ $? == 0 ]]; then
					apt_install_wrapper	apt-get -y purge "${purge_pkg}"
					apt_install_wrapper apt-get --allow-downgrades -y install "${pkg}"
				fi
			done
			if [[ -z "${headers}" ]]; then
				if $DIALOG --title " Reboot required " --yes-button "Reboot" --no-button "Cancel" --yesno \
					"A reboot is required to apply the changes. Shall we reboot now?" 7 34; then
					reboot
				fi
			fi


		;;
		"${commands[2]}") # generate a list of possible packages to install

			# input parameters
			local branch="$2"
			local version="$3"
			local hide="$4"
			local repository="$5"
			local headers="$6"

			# if branch is not defined, we use the one that is currently installed
			[[ -z $branch ]] && local branch=$BRANCH
			[[ -z $BRANCH ]] && local branch="current"

			# if repository is not defined, we use stable one
			[[ -z $repository ]] && local repository="apt.armbian.com"

			# select Armbian packages we want to searching for
			armbian_packages=(
				"linux-image-${branch}-${LINUXFAMILY}"
				"linux-dtb-${branch}-${LINUXFAMILY}"
			)

			# install full firmware if it was installed previously
			if dpkg -l | grep -E "armbian-firmware-full" >/dev/null; then
				armbian_packages+=("armbian-firmware-full")
				else
				armbian_packages+=("armbian-firmware")
			fi

			# install headers only if they were previously installed
			if dpkg -l | grep -E "linux-headers" >/dev/null; then
				armbian_packages+=("linux-headers-${branch}-${LINUXFAMILY}")
			fi

			# only install headers if parameter headers == true
			if  [[ "${headers}" == true ]]; then
				armbian_packages=("linux-headers-${branch}-${LINUXFAMILY}")
				armbian_packages+=(
									"build-essential"
									"git"
									)
			fi

			# when we select a specific version of Armbian, we need to make sure that version exists
			# for each package we want to install. In case desired version does not exists, it installs
			# package without specifying version. This prevent breaking install in case some
			# package version was removed from repository. Just in case.
			packages=""
			for pkg in ${armbian_packages[@]}; do
				# use package + version if found else use package if found
				if apt-cache show "$pkg" 2> /dev/null \
					| grep -E "Package:|^Version:|family" \
					| sed -n -e 's/^.*: //p' \
					| sed 's/\.$//g' \
					| xargs -n2 -d'\n' \
					| grep ${pkg} | grep -e ${version} >/dev/null 2>&1; then
					packages+="${pkg}=${version} ";
				elif
					apt-cache show "$pkg" 2> /dev/null \
					| grep -E "Package:|^Version:|family" \
					| sed -n -e 's/^.*: //p' \
					| sed 's/\.$//g' \
					| xargs -n2 -d'\n' \
					| grep "${pkg}" >/dev/null 2>&1 ; then
					packages+="${pkg} ";
				fi
			done

			# if this is called with a parameter hide, we only prepare this list but don't show its content
			[[ "$4" != "hide" ]] && echo ${packages[@]}

		;;
		"${commands[3]}") # holds Armbian firmware packages or provides status

			# input parameter
			local status=$2

			# generate a list of packages
			${module_options["module_armbian_firmware,feature"]} ${commands[2]} "" "" hide

			# we are only interested in which Armbian packages are put on hold
			if [[ "$status" == "status" ]]; then
				local get_hold=($(apt-mark showhold))
				local test_hold=($(for all_packages in ${packages[@]}; do
					for hold_packages in ${get_hold[@]}; do
					echo $all_packages | grep $hold_packages
					done
				done))
			[[ -z ${test_hold[@]} ]] && return 1 || return 0
			else
				# put Armbian packages on hold
				apt-mark hold ${packages[@]} >/dev/null 2>&1
			fi

		;;
		"${commands[4]}") # unhold Armbian firmware packages

			# generate a list of packages
			${module_options["module_armbian_firmware,feature"]} ${commands[2]} "" "" hide

			# release Armbian packages from hold
			apt-mark unhold ${packages[@]} >/dev/null 2>&1

		;;
		"${commands[5]}") # switches repository to rolling / stable and performs update or provides status

			# input parameters

			local repository=$2
			local status=$3

			if grep -q 'apt.armbian.com' /etc/apt/sources.list.d/armbian.list; then
				if [[ "$repository" == "rolling" && "$status" == "status" ]]; then
					return 1
				elif [[ "$status" == "status" ]]; then
					return 0
				fi
				# performs list change & update if this is needed
				if [[ "$repository" == "rolling" ]]; then
					sed -i "s/http:\/\/[^ ]*/http:\/\/beta.armbian.com/" /etc/apt/sources.list.d/armbian.list
					apt_install_wrapper	apt-get update
				fi
			else
				if [[ "$repository" == "stable" && "$status" == "status" ]]; then
					return 1
				elif [[ "$status" == "status" ]]; then
					return 0
				fi
				# performs list change & update if this is needed
				if [[ "$repository" == "stable" ]]; then
					sed -i "s/http:\/\/[^ ]*/http:\/\/apt.armbian.com/" /etc/apt/sources.list.d/armbian.list
					apt_install_wrapper	apt-get update
				fi
			fi

			# if we are not only checking status, it reinstall firmware automatically
			[[ "$status" != "status" ]] && ${module_options["module_armbian_firmware,feature"]} ${commands[1]}
		;;

		"${commands[6]}") # installs kernel headers

			# input parameters
			local command=$2
			local version=$3

			# if version is not set, use the one from installed kernel
			if [[ "${command}" == "install" ]]; then
				if [[ -f /etc/armbian-release ]]; then
					[[ -z "${version}" ]] && version=$(dpkg -l | grep '^ii' | grep linux-image | awk '{print $3}')
					${module_options["module_armbian_firmware,feature"]} ${commands[1]} "" "${version}" "" "true"
				else
					# for non armbian builds
					apt_install_wrapper apt-get install "linux-headers-$(uname -r | sed 's/'-$(dpkg --print-architecture)'//')"
				fi
			elif [[ "${command}" == "remove" ]]; then
				${module_options["module_armbian_firmware,feature"]} ${commands[2]} "" "${version}" "hide" "" "true"
				apt_install_wrapper apt-get -y autopurge ${packages[@]}
			else
				${module_options["module_armbian_firmware,feature"]} ${commands[2]} "" "${version}" "hide" "" "true"
				if check_if_installed ${packages[@]}; then
					return 0
				else
					return 1
				fi
			fi

		;;


		"${commands[7]}")
			echo -e "\nUsage: ${module_options["module_armbian_firmware,feature"]} <command> <switches>"
			echo -e "Commands:  ${module_options["module_armbian_firmware,example"]}"
			echo "Available commands:"
			echo -e "\tselect    \t- TUI to select $title.              \t switches: [ stable | rolling ]"
			echo -e "\tinstall   \t- Install $title.                    \t switches: [ \$branch | \$version ]"
			echo -e "\tshow      \t- Show $title packages.              \t switches: [ \$branch | \$version | hide ]"
			echo -e "\thold      \t- Mark $title packages as held back. \t switches: [status] returns true or false"
			echo -e "\tunhold    \t- Unset $title packages set as held back."
			echo -e "\trepository\t- Selects repository and performs update. \t switches: [ stable | rolling ]"
			echo -e "\theaders   \t- Kernel headers management.         \t switches: [ install | remove | status ]"
			echo
		;;
		*)
		${module_options["module_armbian_firmware,feature"]} ${commands[7]}
		;;
	esac
}


module_options+=(
["about_armbian_configng,author"]="@igorpecovnik"
["about_armbian_configng,ref_link"]=""
["about_armbian_configng,feature"]="about_armbian_configng"
["about_armbian_configng,desc"]="Show general information about this tool"
["about_armbian_configng,example"]="about_armbian_configng"
["about_armbian_configng,status"]="Active"
)
#
# @description Show general information about this tool
#
function about_armbian_configng() {

	echo "Armbian Config: The Next Generation"
	echo ""
	echo "How to make this tool even better?"
	echo ""
	echo "- propose new features or software titles"
	echo "  https://github.com/armbian/configng/issues/new?template=feature-reqests.yml"
	echo ""
	echo "- report bugs"
	echo "  https://github.com/armbian/configng/issues/new?template=bug-reports.yml"
	echo ""
	echo "- support developers with a small donation"
	echo "  https://github.com/sponsors/armbian"
	echo ""

}

module_options+=(
	["module_headers,author"]="@armbian"
	["module_headers,feature"]="module_headers"
	["module_headers,desc"]="Install headers container"
	["module_headers,example"]="install remove status help"
	["module_headers,port"]=""
	["module_headers,status"]="Active"
	["module_headers,arch"]=""
)
#
# Mmodule_headers
#
function module_headers () {
	local title="headers"
	local condition=$(which "$title" 2>/dev/null)

	if [[ -f /etc/armbian-release ]]; then
		source /etc/armbian-release
		# branch information is stored in armbian-release at boot time. When we change kernel branches, we need to re-read this and add it
		if [[ -z "${BRANCH}" ]]; then
			BRANCH=$(dpkg -l | grep -E "linux-image" | grep -E "current|vendor|legacy|edge" | awk '{print $2}' | cut -d"-" -f3 | head -1)
			if grep -q BRANCH /etc/armbian-release; then
				[[ -n ${BRANCH} ]] && sed -i "s/BRANCH=.*/BRANCH=$BRANCH/g" /etc/armbian-release
				else
				[[ -n ${BRANCH} ]] && echo "BRANCH=$BRANCH" >> /etc/armbian-release
			fi
		fi
		local install_pkg="linux-headers-${BRANCH}-${LINUXFAMILY}"
	else
		local install_pkg="linux-headers-$(uname -r | sed 's/'-$(dpkg --print-architecture)'//')"
	fi

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_headers,example"]}"

	case "$1" in
		"${commands[0]}")
			apt_install_wrapper apt-get -y install ${install_pkg} build-essential git || exit 1
		;;
		"${commands[1]}")
			apt_install_wrapper apt-get -y autopurge ${install_pkg} build-essential || exit 1
			rm -rf /usr/src/linux-headers*
		;;
		"${commands[2]}")
			if check_if_installed ${install_pkg}; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo -e "\nUsage: ${module_options["module_headers,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_headers,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\tremove\t- Remove $title."
			echo
		;;
		*)
		${module_options["module_headers,feature"]} ${commands[3]}
		;;
	esac
}

module_options+=(
	["toggle_ssh_lastlog,author"]="@Tearran"
	["toggle_ssh_lastlog,ref_link"]=""
	["toggle_ssh_lastlog,feature"]="toggle_ssh_lastlog"
	["toggle_ssh_lastlog,desc"]="Toggle SSH lastlog"
	["toggle_ssh_lastlog,example"]="toggle_ssh_lastlog"
	["toggle_ssh_lastlog,status"]="Active"
)
#
# @description Toggle SSH lastlog
#
function toggle_ssh_lastlog() {

	if ! grep -q '^#\?PrintLastLog ' "${SDCARD}/etc/ssh/sshd_config"; then
		# If PrintLastLog is not found, append it with the value 'yes'
		echo 'PrintLastLog no' >> "${SDCARD}/etc/ssh/sshd_config"
		sudo service ssh restart
	else
		# If PrintLastLog is found, toggle between 'yes' and 'no'
		sed -i '/^#\?PrintLastLog /
{
	s/PrintLastLog yes/PrintLastLog no/;
	t;
	s/PrintLastLog no/PrintLastLog yes/
}' "${SDCARD}/etc/ssh/sshd_config"
		sudo service ssh restart
	fi

}



module_options+=(
["store_netplan_config,author"]="@igorpecovnik"
["store_netplan_config,ref_link"]="store_netplan_config"
["store_netplan_config,feature"]="store_netplan_config"
["store_netplan_config,desc"]="Storing netplan config to tmp"
["store_netplan_config,example"]="store_netplan_config"
["store_netplan_config,status"]="Active"
)
#
# @description Storing Netplan configuration to temp folder
#
function store_netplan_config () {

	# store current configs to temporal folder
	restore_netplan_config_folder=$(mktemp -d /tmp/XXXXXXXXXX)
	rsync --quiet /etc/netplan/* ${restore_netplan_config_folder}/ 2>/dev/null
	trap restore_netplan_config 1 2 3 6

}


module_options+=(
	["module_zfs,author"]="@igorpecovnik"
	["module_zfs,feature"]="module_zfs"
	["module_zfs,desc"]="Install zfs filesystem support"
	["module_zfs,example"]="install remove status kernel_max zfs_version zfs_installed_version help"
	["module_zfs,port"]=""
	["module_zfs,status"]="Active"
	["module_zfs,arch"]=""
)
#
# Module OpenZFS
#
function module_zfs () {
	local title="zfs"
	local condition=$(which "$title" 2>/dev/null)

	local commands
	IFS=' ' read -r -a commands <<< "${module_options["module_zfs,example"]}"

	case "$1" in
		"${commands[0]}")
			# headers are needed, lets install then if they are not there already
			if ! module_armbian_firmware headers status; then
				module_armbian_firmware headers install
			fi
			DEBIAN_FRONTEND=noninteractive apt-get -y install zfsutils-linux zfs-dkms
		;;
		"${commands[1]}")
			module_armbian_firmware headers remove
			apt_install_wrapper apt-get -y autopurge zfsutils-linux zfs-dkms
		;;
		"${commands[2]}")
			if check_if_installed zfsutils-linux; then
				return 0
			else
				return 1
			fi
		;;
		"${commands[3]}")
			echo "${ZFS_KERNEL_MAX}"
		;;
		"${commands[4]}")
			echo "v${ZFS_DKMS_VERSION}"
		;;
		"${commands[5]}")
			if check_if_installed zfsutils-linux; then
				zfs --version 2>/dev/null| head -1 | cut -d"-" -f2
			fi
		;;
		"${commands[6]}")
			echo -e "\nUsage: ${module_options["module_zfs,feature"]} <command>"
			echo -e "Commands:  ${module_options["module_zfs,example"]}"
			echo "Available commands:"
			echo -e "\tinstall\t- Install $title."
			echo -e "\tremove\t- Remove $title."
			echo -e "\tstatus\t- Installation status $title."
			echo -e "\kernel_max\t- Determine maximum version of kernel to support $title."
			echo -e "\zfs_version\t- Gets $title version from Git."
			echo -e "\zfs_installed_version\t- Read $title module info."
			echo
		;;
		*)
		${module_options["module_zfs,feature"]} ${commands[6]}
		;;
	esac
}


module_options+=(
	["apt_install_wrapper,author"]="@igorpecovnik"
	["apt_install_wrapper,ref_link"]=""
	["apt_install_wrapper,feature"]="apt_install_wrapper"
	["apt_install_wrapper,desc"]="Install wrapper"
	["apt_install_wrapper,example"]="apt_install_wrapper apt-get -y purge armbian-zsh"
	["apt_install_wrapper,status"]="Active"
)
#
# @description Use TUI / GUI for apt install if exists
#
function apt_install_wrapper() {

	if [ -t 0 ]; then
		debconf-apt-progress -- "$@"
	else
		# Terminal not defined - proceed without TUI
		"$@"
	fi
}


module_options+=(
	["change_system_hostname,author"]="@igorpecovnik"
	["change_system_hostname,ref_link"]=""
	["change_system_hostname,feature"]="Change hostname"
	["change_system_hostname,desc"]="change_system_hostname"
	["change_system_hostname,example"]="change_system_hostname"
	["change_system_hostname,status"]="Active"
)
#
# @description Change system hostname
#
function change_system_hostname() {
	local new_hostname=$($DIALOG --title "Enter new hostnane" --inputbox "" 7 50 3>&1 1>&2 2>&3)
	[ $? -eq 0 ] && [ -n "${new_hostname}" ] && hostnamectl set-hostname "${new_hostname}"
}


module_options+=(
	["manage_zsh,author"]="@igorpecovnik"
	["manage_zsh,ref_link"]=""
	["manage_zsh,feature"]="manage_zsh"
	["manage_zsh,desc"]="Set system shell to BASH"
	["manage_zsh,example"]="manage_zsh enable|disable"
	["manage_zsh,status"]="Active"
)
#
# @description Set system shell to ZSH
#
function manage_zsh() {

	local bash_location=$(grep /bash$ /etc/shells | tail -1)
	local zsh_location=$(grep /zsh$ /etc/shells | tail -1)

	if [[ "$1" == "enable" ]]; then

		sed -i "s|^SHELL=.*|SHELL=/bin/zsh|" /etc/default/useradd
		sed -i -E "s|(^\|#)DSHELL=.*|DSHELL=/bin/zsh|" /etc/adduser.conf

		# install
		apt_install_wrapper apt-get -y install armbian-zsh zsh-common zsh tmux

		update_skel

		# change shell for root
		usermod --shell "/bin/zsh" root
		# change shell for others
		sed -i 's/bash$/zsh/g' /etc/passwd

	else

		sed -i "s|^SHELL=.*|SHELL=/bin/bash|" /etc/default/useradd
		sed -i -E "s|(^\|#)DSHELL=.*|DSHELL=/bin/bash|" /etc/adduser.conf

		# remove
		apt_install_wrapper apt-get -y remove armbian-zsh zsh-common zsh tmux

		# change shell for root
		usermod --shell "/bin/bash" root
		# change shell for others
		sed -i 's/zsh$/bash/g' /etc/passwd

	fi

}

module_options+=(
	["manage_desktops,author"]="@igorpecovnik"
	["manage_desktops,ref_link"]=""
	["manage_desktops,feature"]="manage_desktops"
	["manage_desktops,desc"]="Install Desktop environment"
	["manage_desktops,example"]="manage_desktops xfce install"
	["manage_desktops,status"]="Active"
)
#
# Install desktop
#
function manage_desktops() {

	local desktop=$1
	local command=$2

	# get user who executed this script
	if [ $SUDO_USER ]; then local user=$SUDO_USER; else local user=$(whoami); fi

	case "$command" in
		install)

			# desktops has different default login managers
			case "$desktop" in
				gnome)
					echo "/usr/sbin/gdm3" > /etc/X11/default-display-manager
					#apt_install_wrapper DEBIAN_FRONTEND=noninteractive DEBCONF_NONINTERACTIVE_SEEN=true apt-get -y install gdm3
				;;
				kde-neon)
					echo "/usr/sbin/sddm" > /etc/X11/default-display-manager
					#apt_install_wrapper DEBIAN_FRONTEND=noninteractive DEBCONF_NONINTERACTIVE_SEEN=true apt-get -y install sddm
				;;
				*)
					echo "/usr/sbin/lightdm" > /etc/X11/default-display-manager
					#apt_install_wrapper DEBIAN_FRONTEND=noninteractive DEBCONF_NONINTERACTIVE_SEEN=true apt-get -y install lightdm
				;;
			esac

			# just make sure we have everything in order
			apt_install_wrapper dpkg --configure -a

			# install desktop
			export DEBIAN_FRONTEND=noninteractive DEBCONF_NONINTERACTIVE_SEEN=true
			apt_install_wrapper apt-get -o Dpkg::Options::="--force-confold" -y --install-recommends install armbian-${DISTROID}-desktop-${desktop}

			# add user to groups
			for additionalgroup in sudo netdev audio video dialout plugdev input bluetooth systemd-journal ssh; do
				usermod -aG ${additionalgroup} ${user} 2> /dev/null
			done

			# set up profile sync daemon on desktop systems
			which psd > /dev/null 2>&1
			if [[ $? -eq 0 && -z $(grep overlay-helper /etc/sudoers) ]]; then
				echo "${user} ALL=(ALL) NOPASSWD: /usr/bin/psd-overlay-helper" >> /etc/sudoers
				touch /home/${user}/.activate_psd
			fi
			# update skel
			update_skel

			# enable auto login
			manage_desktops "$desktop" "auto"

			# stop display managers in case we are switching them
			service gdm3 stop
			service lightdm stop
			service sddm stop

			# start new default display manager
			service display-manager restart
		;;
		uninstall)
			# we are uninstalling all variants until build time packages are fixed to prevent installing one over another
			service display-manager stop
			apt_install_wrapper apt-get -o Dpkg::Options::="--force-confold" -y --install-recommends purge armbian-${DISTROID}-desktop-$1 \
			xfce4-session gnome-session slick-greeter lightdm gdm3 sddm cinnamon-session i3-wm
			apt_install_wrapper apt-get -y autoremove
			# disable autologins
			rm -f /etc/gdm3/custom.conf
			rm -f /etc/sddm.conf.d/autologin.conf
			rm -f /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf
		;;
		auto)
			# desktops has different login managers and autologin methods
			case "$desktop" in
				gnome)
					# gdm3 autologin
					mkdir -p /etc/gdm3
					cat <<- EOF > /etc/gdm3/custom.conf
					[daemon]
					AutomaticLoginEnable = true
					AutomaticLogin = ${user}
					EOF
				;;
				kde-neon)
					# sddm autologin
					cat <<- EOF > "/etc/sddm.conf.d/autologin.conf"
					[Autologin]
					User=${user}
					EOF
				;;
				*)
					# lightdm autologin
					mkdir -p /etc/lightdm/lightdm.conf.d
					cat <<- EOF > "/etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf"
					[Seat:*]
					autologin-user=${user}
					autologin-user-timeout=0
					user-session=xfce
					EOF

				;;
			esac
			# restart after selection
			service display-manager restart
		;;
		manual)
			case "$desktop" in
				gnome)    rm -f  /etc/gdm3/custom.conf ;;
				kde-neon) rm -f /etc/sddm.conf.d/autologin.conf ;;
				*)        rm -f /etc/lightdm/lightdm.conf.d/22-armbian-autologin.conf ;;
			esac
			# restart after selection
			service display-manager restart
		;;
	esac

}


module_options+=(
	["manage_overlayfs,author"]="@igorpecovnik"
	["manage_overlayfs,ref_link"]=""
	["manage_overlayfs,feature"]="manage_overlayfs"
	["manage_overlayfs,desc"]="Set Armbian root filesystem to read only"
	["manage_overlayfs,example"]="manage_overlayfs enable/disable"
	["manage_overlayfs,status"]="Active"
)
#
# @description set/unset Armbian root filesystem to read only
#
function manage_overlayfs() {

	if [[ "$1" == "enable" ]]; then
		debconf-apt-progress -- apt-get -o Dpkg::Options::="--force-confold" -y install overlayroot cryptsetup cryptsetup-bin
		[[ ! -f /etc/overlayroot.conf ]] && cp /etc/overlayroot.conf.dpkg-new /etc/overlayroot.conf
		sed -i "s/^overlayroot=.*/overlayroot=\"tmpfs\"/" /etc/overlayroot.conf
		sed -i "s/^overlayroot_cfgdisk=.*/overlayroot_cfgdisk=\"enabled\"/" /etc/overlayroot.conf
	else
		overlayroot-chroot rm /etc/overlayroot.conf > /dev/null 2>&1
		debconf-apt-progress -- apt-get -y purge overlayroot cryptsetup cryptsetup-bin
	fi
	# reboot is mandatory
	reboot
}


